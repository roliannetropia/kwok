--
-- Upgrading to 2.7.9
--
-- ----------
-- Start upgrade
-- ----------
update system_config set config_value = '2.7.9.work' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists attribute_view;
drop view if exists asset_software_view;
drop view if exists asset_hardware_view;
drop view if exists blog_post_view;
drop view if exists blog_post_comment_view;
drop view if exists category_view;
drop view if exists company_view;
drop view if exists contact_view;
drop view if exists contract_view;
drop view if exists group_view;
drop view if exists issue_view;
drop view if exists kb_article_view;
drop view if exists site_view;
drop view if exists user_view;
DROP FUNCTION if exists sp_software_add(character varying, text, integer, integer, character varying, character varying, integer, integer, integer);
DROP FUNCTION if exists sp_software_update(integer, character varying, text, integer, integer, character varying, character varying, integer, integer, integer);

-- ----------
-- Upgrades for this release
-- ----------
-- Minimum password length, <x> characters
insert into system_config (config_key, config_value) values ('System.Security.UserPasswordLength', '0');
insert into system_config (config_key, config_value) values ('Users.NameDisplay', 'user_display_name');
insert into system_config (config_key, config_value) values ('Files.MaxUploadByteSize', '536870912'); -- 512MB
insert into system_config (config_key, config_value) values ('Files.KilobyteUnits', '1024');

alter table asset_software add column software_owner integer;

alter table issue alter column issue_name type character varying(120);

alter table issue_change alter column issue_change_varchar_old type character varying(120);
alter table issue_change alter column issue_change_varchar_new type character varying(120);

update asset_hardware set hardware_cost=null where hardware_cost=0;

alter table kb_article_archive alter column article_name type character varying(225);

delete from kb_article_archive;

update kb_article set modifier = null where modification_date is null;

-- Add is_required column
alter table attribute add is_required smallint DEFAULT (-1)::smallint;
update attribute set is_required = 0 where attribute_id in (-18, -15, -14, -12, -10, -8, -7, -6);

-- Rename software_os to software_platform
update attribute set attribute_key='software_platform' where attribute_id=-7;

-- Rename attribute add/edit pages
update access_page set page_name='/admin/attribute-field-edit.dll' where page_id=87 and page_name='/admin/attribute-edit.dll';
update access_page set page_name='/admin/attribute-field-edit-2.dll' where page_id=88 and page_name='/admin/attribute-edit-2.dll';
update access_page set page_name='/admin/attribute-field-add.dll' where page_id=89 and page_name='/admin/attribute-add.dll';
update access_page set page_name='/admin/attribute-field-add-2.dll' where page_id=90 and page_name='/admin/attribute-add-2.dll';

insert into access_page (page_id, page_name, module_id) values (289, '/admin/attribute-edit.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 289);

insert into access_page (page_id, page_name, module_id) values (290, '/admin/attribute-edit-2.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 290);

-- system_cache table
CREATE TABLE system_cache (
  cache_key character varying(50) NOT NULL,
  cache_time bigint,
  CONSTRAINT pk_system_cache_key PRIMARY KEY (cache_key)
);

ALTER TABLE object_map ADD COLUMN relationship_name character varying(50);

-- Software contacts tab
insert into access_page (page_id, page_name, module_id) values (291, '/software/contacts.dll', 2);
insert into access_perm_page_map(perm_id, page_id) values (8, 291);

insert into access_page (page_id, page_name, module_id) values (292, '/software/contact-add.dll', 2);
insert into access_perm_page_map(perm_id, page_id) values (23, 292);

insert into access_page (page_id, page_name, module_id) values (293, '/software/contact-add-2.dll', 2);
insert into access_perm_page_map(perm_id, page_id) values (23, 293);

insert into access_page (page_id, page_name, module_id) values (294, '/software/contact-remove-2.dll', 2);
insert into access_perm_page_map(perm_id, page_id) values (23, 294);

-- Contract contacts tab
insert into access_page (page_id, page_name, module_id) values (295, '/contracts/contacts.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (12, 295);

insert into access_page (page_id, page_name, module_id) values (296, '/contracts/contact-add.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 296);

insert into access_page (page_id, page_name, module_id) values (297, '/contracts/contact-add-2.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 297);

insert into access_page (page_id, page_name, module_id) values (298, '/contracts/contact-remove-2.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 298);

insert into attribute (attribute_id, object_type_id, attribute_key, is_editable, is_custom_attr, attribute_type, attribute_convert_url, is_required) values (-20, 7, 'issue_assignee', 1, 0, 5, 0, 0);
   
update access_group_user_map set creator=1 where creator=0;

-- ----------
-- End upgrade
-- ----------
update system_config set config_value = '2.7.9' where config_key = 'schema.version';