--
-- Upgrading to 2.7.3
--
update system_config set config_value = '2.7.3' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists file_view;
DROP FUNCTION if exists sp_file_add_update(p_file_id integer, p_file_name character varying, p_file_friendly_name character varying, p_file_description text, p_file_mime_type character varying, p_file_byte_size double precision, p_file_uploaded_file_name character varying, p_object_type_id integer, p_object_id integer, p_creator integer);
DROP FUNCTION if exists sp_kb_article_update(p_article_id bigint, p_article_name character varying, p_article_text text, p_category_id integer, p_modifier integer);
DROP FUNCTION if exists sp_kb_article_add(OUT o_article_id bigint, IN p_article_name character varying, IN p_article_text text, IN p_category_id integer, IN p_creator integer);
DROP FUNCTION if exists sp_kb_article_archive(p_article_id integer, p_modifier integer);

-- ----------
-- Upgrades for this release.
-- ----------
update access_group set group_description=null where group_description='';
update asset_hardware set hardware_description=null where hardware_description='';
update asset_hardware set hardware_serial_number=null where hardware_serial_number='';
update asset_hardware set hardware_model_name=null where hardware_model_name='';
update asset_hardware set hardware_model_number=null where hardware_model_number='';
update asset_hardware_component set comp_description=null where comp_description='';
update asset_software set software_description=null where software_description='';
update asset_software set quoted_retail_price=null where quoted_retail_price='';
update asset_software set quoted_oem_price=null where quoted_oem_price='';
update asset_software_licenses set license_note=null where license_note='';
update attribute set attribute_url=null where attribute_url='';
update attribute_field set field_key=null where field_key='';
update attribute_field set attribute_field_description=null where attribute_field_description='';
update blog_post set post_description=null where post_description='';
update blog_post set post_ip=null where post_ip='';
update blog_post_comment set comment_ip=null where comment_ip='';
update bookmark set bookmark_description=null where bookmark_description='';
update category set category_description=null where category_description='';
update company set company_description=null where company_description='';
update company_note set note_description=null where note_description='';
update contact set contact_description=null where contact_description='';
update contact set contact_title=null where contact_title='';
update contact set contact_phone_home=null where contact_phone_home='';
update contact set contact_phone_mobile=null where contact_phone_mobile='';
update contact set contact_phone_work=null where contact_phone_work='';
update contact set contact_fax=null where contact_fax='';
update contact set contact_email_secondary=null where contact_email_secondary='';
update contact set contact_homepage_url=null where contact_homepage_url='';
update contact set address_street_primary=null where address_street_primary='';
update contact set address_city_primary=null where address_city_primary='';
update contact set address_state_primary=null where address_state_primary='';
update contact set address_zipcode_primary=null where address_zipcode_primary='';
update contact set address_country_primary=null where address_country_primary='';
update contact set address_street_secondary=null where address_street_secondary='';
update contact set address_city_secondary=null where address_city_secondary='';
update contact set address_state_secondary=null where address_state_secondary='';
update contact set address_zipcode_secondary=null where address_zipcode_secondary='';
update contact set address_country_secondary=null where address_country_secondary='';
update contact set messenger_1_id=null where messenger_1_id='';
update contact set messenger_2_id=null where messenger_2_id='';
update contract set contract_description=null where contract_description='';
update file set file_friendly_name=null where file_friendly_name='';
update file set file_description=null where file_description='';
update issue set issue_url=null where issue_url='';
update kb_article set article_text=null where article_text='';
update kb_article_archive set article_text=null where article_text='';
update portal_site set site_description=null where site_description='';
update user_session set session_key=null where session_key='';

-- KB file upload
insert into access_page (page_id, page_name, module_id) values (264, '/kb/article-file-download.dll', 14);
insert into access_page (page_id, page_name, module_id) values (265, '/kb/article-file-add.dll', 14);
insert into access_page (page_id, page_name, module_id) values (266, '/kb/article-file-add-2.dll', 14);
insert into access_page (page_id, page_name, module_id) values (267, '/kb/article-file-delete.dll', 14);
insert into access_page (page_id, page_name, module_id) values (268, '/kb/article-file-delete-2.dll', 14);

insert into access_perm_page_map(perm_id, page_id) values (26, 264);

insert into access_perm_page_map(perm_id, page_id) values (27, 265);
insert into access_perm_page_map(perm_id, page_id) values (27, 266);
insert into access_perm_page_map(perm_id, page_id) values (27, 267);
insert into access_perm_page_map(perm_id, page_id) values (27, 268);

insert into system_config (config_key, config_value) values ('file.kb.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\kb');
insert into system_config (config_key, config_value) values ('file.kb.uploadFilePrefix', 'KB-');

alter table file rename column file_uploaded_file_name to file_physical_name;

insert into system_config (config_key, config_value) values ('hardware.warrantyExpireCountdown', '0');

update system_config set config_key = 'expirationCountdown.options' where config_key='contracts.expirationCountdown.options';

update system_object set object_key = 'contract' where object_type_id=9;

alter table kb_article_archive drop CONSTRAINT fk_kb_article_archive_article_id;

-- User search page
insert into access_page (page_id, page_name, module_id) values (269, '/admin/user-index.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (3, 269);

-- KB search results page
insert into access_page (page_id, page_name, module_id) values (270, '/kb/article-search.dll', 14);
insert into access_perm_page_map(perm_id, page_id) values (26, 270);

insert into access_page (page_id, page_name, module_id) values (271, '/reports/report-issue.dll', 15);
insert into access_perm_page_map(perm_id, page_id) values (13, 271);

insert into access_page (page_id, page_name, module_id) values (272, '/reports/report-hardware.dll', 15);
insert into access_perm_page_map(perm_id, page_id) values (13, 272);

insert into system_config (config_key, config_value) values ('software.numberOfRowsToShow', '10');
insert into system_config (config_key, config_value) values ('contracts.numberOfRowsToShow', '10');

ALTER TABLE user_login_history RENAME TO system_event;

CREATE TABLE kb_article_history (
  article_history_id bigint not null,
  article_id bigint NOT NULL,
  article_name character varying(100) NOT NULL,
  article_text text,
  category_id integer NOT NULL,
  creator integer,
  creation_date timestamp(1) without time zone,
  event_type_id int,
  CONSTRAINT pk_kb_article_history_id PRIMARY KEY (article_history_id),
  CONSTRAINT fk_kb_article_history_category_id FOREIGN KEY (category_id) REFERENCES category (category_id)
);

CREATE SEQUENCE seq_kb_article_history_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

update system_config set config_key='mail.smtp.from' where config_key='smtp.from';
update system_config set config_key='mail.smtp.host' where config_key='smtp.host';
update system_config set config_key='mail.smtp.password' where config_key='smtp.password';
update system_config set config_key='mail.smtp.port' where config_key='smtp.port';
update system_config set config_key='mail.smtp.starttls' where config_key='smtp.starttls';
update system_config set config_key='mail.smtp.to' where config_key='smtp.to';
update system_config set config_key='mail.smtp.username' where config_key='smtp.username';

insert into system_config (config_key, config_value) values ('mail.pop.ssl.enable', 'false');
