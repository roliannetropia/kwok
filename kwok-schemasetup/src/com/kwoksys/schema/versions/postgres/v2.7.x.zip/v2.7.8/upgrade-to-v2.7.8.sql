--
-- Upgrading to 2.7.8
--
-- ----------
-- Start upgrade
-- ----------
update system_config set config_value = '2.7.8.work' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists user_view;
drop view if exists attribute_value_view;

-- ----------
-- Upgrades for this release
-- ----------
-- Postgres 8.3 has a problem with renaming table and not updating constraint automatically
ALTER TABLE ONLY attribute
    DROP CONSTRAINT fk_attribute_object_type_id;

ALTER TABLE ONLY attribute
    ADD CONSTRAINT fk_attribute_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object_type(object_type_id);

update system_config set config_value='10,20,50,100,500' where config_key='module.numberOfRowsToShow.options';

-- Fix wrong permission mapping
insert into access_perm_page_map(perm_id, page_id) values (30, 286);
insert into access_perm_page_map(perm_id, page_id) values (30, 287);

-- Cleanup util_read perm
delete from access_perm_page_map where perm_id=17;
delete from access_user_perm_map where perm_id=17;
delete from access_group_perm_map where perm_id=17;
delete from access_page where page_id in (147, 148);
delete from access_permission where perm_id=17;

-- merge access_user_session table into access_user
alter table access_user add last_logon timestamp(1) without time zone;
alter table access_user add last_visit timestamp(1) without time zone;
alter table access_user add session_key character varying(50);

update access_user set last_logon = (select last_logon from access_user_session where user_id=access_user.user_id);
update access_user set last_visit = (select last_visit from access_user_session where user_id=access_user.user_id);
update access_user set session_key = (select session_key from access_user_session where user_id=access_user.user_id);

alter table access_user_archive add last_logon timestamp(1) without time zone;
alter table access_user_archive add last_visit timestamp(1) without time zone;
alter table access_user_archive add session_key character varying(50);

update access_user_archive set last_logon = (select last_logon from access_user_session where user_id=access_user_archive.user_id);
update access_user_archive set last_visit = (select last_visit from access_user_session where user_id=access_user_archive.user_id);
update access_user_archive set session_key = (select session_key from access_user_session where user_id=access_user_archive.user_id);

drop table access_user_session;

-- Reuse attribute, attribute_field tables for user status
update attribute_field set attribute_field_id=-1, field_key='user_status_enabled', attribute_field_name='user_status_enabled' where attribute_id=-13 and field_key='enabled';
update attribute_field set attribute_field_id=-2, field_key='user_status_disabled', attribute_field_name='user_status_disabled' where attribute_id=-13 and field_key='disabled';
update access_user set status=-1 where status=1;
update access_user set status=-2 where status=0;

-- Company type attributes
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, is_editable, default_attribute_field_id, is_custom_attr, attribute_url, attribute_type, attribute_convert_url) VALUES (-18, 5, 'company_type', 0, NULL, 0, NULL, 1, 0);

insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-3, -18, 'company_type_hardware_manufacturer', 'company_type_hardware_manufacturer');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-4, -18, 'company_type_hardware_vendor', 'company_type_hardware_vendor');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-5, -18, 'company_type_software_maker', 'company_type_software_maker');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-6, -18, 'company_type_software_vendor', 'company_type_software_vendor');

-- Reuse attribute, attribute_field tables for kb article syntax type
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, is_editable, default_attribute_field_id, is_custom_attr, attribute_url, attribute_type, attribute_convert_url) VALUES (-19, 14, 'kb_article_syntax_type', 0, NULL, 0, NULL, 1, 0);
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-7, -19, 'kb_article_syntax_type_html', 'kb_article_syntax_type_html');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-8, -19, 'kb_article_syntax_type_mediawiki', 'kb_article_syntax_type_mediawiki');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (-9, -19, 'kb_article_syntax_type_twiki', 'kb_article_syntax_type_twiki');

update kb_article set article_syntax_type =-7;
update kb_article_archive set article_syntax_type =-7;

-- Updating attribute_value table to support attribute_field_id mapping
alter table attribute_value rename to object_attribute_value;

alter table object_attribute_value add column attribute_field_id integer;
alter table object_attribute_value add CONSTRAINT fk_object_att_value_field_id FOREIGN KEY (attribute_field_id) REFERENCES attribute_field (attribute_field_id);

alter table object_attribute_value drop CONSTRAINT uk_attribute_value_attr_obj_id;

alter table object_attribute_value add CONSTRAINT uk_object_attribute_value UNIQUE (attribute_id, attribute_field_id, object_id);

alter table system_object_type rename to object_type;

ALTER TABLE object_attribute_value ALTER COLUMN attr_value DROP NOT NULL;

insert into object_attribute_value (attribute_id, attribute_field_id, attr_value, object_id) select -18, -3, null, company_id from company;
insert into object_attribute_value (attribute_id, attribute_field_id, attr_value, object_id) select -18, -4, null, company_id from company;
insert into object_attribute_value (attribute_id, attribute_field_id, attr_value, object_id) select -18, -5, null, company_id from company;
insert into object_attribute_value (attribute_id, attribute_field_id, attr_value, object_id) select -18, -6, null, company_id from company;

-- Company contracts tab
insert into access_page (page_id, page_name, module_id) values (288, '/contact-mgmt/company-contracts.dll', 5);
insert into access_perm_page_map(perm_id, page_id) values (10, 288);

-- ----------
-- End upgrade
-- ----------
update system_config set config_value = '2.7.8' where config_key = 'schema.version';
