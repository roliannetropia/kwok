--
-- Upgrading to 2.7.6
--
-- ----------
-- Start upgrade
-- ----------
update system_config set config_value = '2.7.6.work' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------

-- ----------
-- Upgrades for this release
-- ----------
alter table kb_article_history rename to kb_article_archive;

-- Alter table syntax works for altering sequence too
alter table seq_kb_article_history_id rename to seq_kb_article_archive_id;

insert into system_config (config_key, config_value) values ('logging.database.level', 'FINE');
insert into system_config (config_key, config_value) values ('logging.ldap.level', 'FINE');

-- Hardware Members page
insert into access_page (page_id, page_name, module_id) values (280, '/hardware/hardware-member.dll', 1);
insert into access_perm_page_map(perm_id, page_id) values (6, 280);

insert into access_page (page_id, page_name, module_id) values (281, '/hardware/hardware-member-add.dll', 1);
insert into access_perm_page_map(perm_id, page_id) values (22, 281);

insert into access_page (page_id, page_name, module_id) values (282, '/hardware/hardware-member-add-2.dll', 1);
insert into access_perm_page_map(perm_id, page_id) values (22, 282);

insert into access_page (page_id, page_name, module_id) values (283, '/hardware/hardware-member-remove.dll', 1);
insert into access_perm_page_map(perm_id, page_id) values (22, 283);

alter table system_object rename to system_object_type;

alter table asset_software_licenses alter license_note TYPE text;

insert into system_config(config_key, config_value) values ('File.RestrictRepositoryUpdate','false');
insert into system_config(config_key, config_value) values ('Issues.ReportIssueEnabled','true');

update system_config set config_value='rownum,company_name' where config_key='contacts.companyColumnList';
update system_config set config_value='rownum,contact_first_name,contact_last_name,contact_title,company_name' where config_key='contacts.columnList';
update system_config set config_value='rownum,site_name,site_path,site_placement,site_support_iframe' where config_key='portal.columnList';

-- ----------
-- End upgrade
-- ----------
update system_config set config_value = '2.7.6' where config_key = 'schema.version';
