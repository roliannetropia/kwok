--
-- Upgrading to 2.7.4
--
update system_config set config_value = '2.7.4' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop table if exists kb_article_archive;
drop view if exists kb_article_view;
drop view if exists contact_view;
drop view if exists user_view;
drop view if exists attribute_field_view;

-- ----------
-- Upgrades for this release.
-- ----------
alter table kb_article add column view_count bigint DEFAULT 0;
alter table kb_article_history add column view_count bigint DEFAULT 0;

update kb_article set view_count = 1;

insert into system_config (config_key, config_value) values ('system.licenseKey','');
insert into system_config (config_key, config_value) values ('system.cacheKey','');

ALTER TABLE contact ALTER contact_homepage_url TYPE character varying(256);

insert into access_page (page_id, page_name, module_id) values (273, '/contracts/software-remove-2.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 273);

insert into access_page (page_id, page_name, module_id) values (274, '/contracts/software-add.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 274);

insert into access_page (page_id, page_name, module_id) values (275, '/contracts/software-add-2.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (9, 275);

insert into system_config (config_key, config_value) values ('kb.article.columns','article_name,view_count');

update access_page set page_name='/contracts/item-list.dll' where page_id='206';

CREATE TABLE access_user_archive (
  user_archive_id integer NOT NULL,
  user_id integer NOT NULL,
  username character varying(50) NOT NULL,
  "password" character varying(32) NOT NULL,
  display_name character varying(50) NOT NULL,
  first_name character varying(50),
  last_name character varying(50),
  email character varying(255),
  creator integer,
  creation_date timestamp(1) without time zone,
  archiver integer,
  archive_date timestamp(1) without time zone,
  status smallint DEFAULT (1)::smallint,
  hardware_count integer DEFAULT 0,
  CONSTRAINT pk_user_archive_id PRIMARY KEY (user_archive_id)
);

CREATE SEQUENCE seq_user_archive_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

insert into access_page (page_id, page_name, module_id) values (276, '/admin/user-delete.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 276);

insert into access_page (page_id, page_name, module_id) values (277, '/admin/user-delete-2.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 277);

ALTER TABLE access_user ADD COLUMN is_default_user smallint DEFAULT 0;

update access_user set is_default_user = 1 where user_id in (1, -1001);

alter table user_session rename to access_user_session;

alter table attribute_field drop column field_key_id;
