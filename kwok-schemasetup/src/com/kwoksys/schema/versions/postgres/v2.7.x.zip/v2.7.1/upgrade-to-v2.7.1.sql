--
-- Upgrading to 2.7.1
--
update system_config set config_value = '2.7.1' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists issue_view;

-- ----------
-- Upgrades for this release.
-- ----------
update access_page set page_name='/admin/config.dll' where page_id=11;

update system_config set config_value = 'app,ldap,mixed' where config_key = 'auth.authenticationMethod.options';