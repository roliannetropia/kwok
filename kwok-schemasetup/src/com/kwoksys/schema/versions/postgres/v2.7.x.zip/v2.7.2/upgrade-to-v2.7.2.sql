--
-- Upgrading to 2.7.2
--
update system_config set config_value = '2.7.2' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
DROP FUNCTION if exists sp_issue_add(OUT o_issue_id integer, IN p_issue_name character varying, IN p_issue_description text, IN p_url text, IN p_type integer, IN p_status integer, IN p_priority integer, IN p_resolution integer, IN p_assignee integer, IN p_issue_due_date character varying, IN p_creator_ip character varying, IN p_creator integer);
DROP FUNCTION if exists sp_issue_update(p_issue_id integer, p_issue_name character varying, p_issue_description text, p_issue_type integer, p_issue_status integer, p_issue_priority integer, p_issue_resolution integer, p_issue_assignee integer, p_issue_due_date character varying, p_user_id integer);
drop view if exists issue_view;

-- ----------
-- Upgrades for this release.
-- ----------
insert into system_config (config_key, config_value) values ('mail.pop.host','');
insert into system_config (config_key, config_value) values ('mail.pop.port','');
insert into system_config (config_key, config_value) values ('mail.pop.username','');
insert into system_config (config_key, config_value) values ('mail.pop.password','');
insert into system_config (config_key, config_value) values ('mail.pop.messages.limit','10');
insert into system_config (config_key, config_value) values ('mail.pop.senderIgnoreList','');
insert into system_config (config_key, config_value) values ('mail.pop.repeatInterval','300000');

delete from system_config where config_key='ad.display';
delete from system_config where config_key='usage.survey';

update access_page set page_name='/admin/config-write.dll' where page_id=83;

update access_permission set perm_name='report', perm_is_enabled=1, order_num=149 where perm_id=13;
update access_page set page_name='/reports/report-step1.dll' where page_id=67;
update access_page set page_name='/reports/report-step2.dll' where page_id=68;
update access_page set page_name='/reports/report-step3.dll' where page_id=69;
update access_page set page_name='/reports/report-step4.dll' where page_id=70;

update system_config set config_value='13,1,2,4,14,5,3,6,8,7,15' where config_key='template.moduleTabs';

alter table issue add column issue_created_from_email character varying(225);
alter table issue add column issue_modified_from_email character varying(225);

ALTER TABLE asset_hardware ALTER COLUMN hardware_serial_number DROP NOT NULL;
ALTER TABLE contact ALTER COLUMN contact_first_name DROP NOT NULL;
ALTER TABLE contact ALTER COLUMN contact_last_name DROP NOT NULL;

ALTER TABLE access_user ALTER COLUMN first_name DROP DEFAULT;
ALTER TABLE access_user ALTER COLUMN last_name DROP DEFAULT;
ALTER TABLE access_user ALTER COLUMN email DROP DEFAULT;
ALTER TABLE asset_hardware ALTER COLUMN hardware_model_name DROP DEFAULT;
ALTER TABLE asset_hardware ALTER COLUMN hardware_model_number DROP DEFAULT;
ALTER TABLE asset_software ALTER COLUMN quoted_retail_price DROP DEFAULT;
ALTER TABLE asset_software ALTER COLUMN quoted_oem_price DROP DEFAULT;
ALTER TABLE asset_software_licenses ALTER COLUMN license_note DROP DEFAULT;
ALTER TABLE attribute_field ALTER COLUMN field_key DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_title DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_phone_home DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_phone_mobile DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_phone_work DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_fax DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_email_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_email_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN contact_homepage_url DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_street_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_street_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_city_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_state_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_zipcode_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_country_primary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_street_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_city_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_state_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_zipcode_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN address_country_secondary DROP DEFAULT;
ALTER TABLE contact ALTER COLUMN messenger_1_id DROP DEFAULT; 
ALTER TABLE contact ALTER COLUMN messenger_2_id DROP DEFAULT;
ALTER TABLE content_locale ALTER COLUMN "language" DROP DEFAULT;
ALTER TABLE content_locale ALTER COLUMN country DROP DEFAULT;
ALTER TABLE file ALTER COLUMN file_friendly_name DROP DEFAULT;
ALTER TABLE file ALTER COLUMN file_mime_type DROP DEFAULT;
ALTER TABLE file ALTER COLUMN file_uploaded_file_name DROP DEFAULT;
ALTER TABLE user_session ALTER COLUMN session_key DROP DEFAULT;

update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,nl_NL,pl_PL,pt_BR,sr_YU,zh_CN' where config_key='locale.options';

alter table issue_change add column issue_created_from_email character varying(225);
 
update system_config set config_value=(select config_value from system_config where config_key='smtp.from') where config_key='mail.pop.senderIgnoreList';
