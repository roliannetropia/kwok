--
-- Upgrading to 2.7.7
--
-- ----------
-- Start upgrade
-- ----------
update system_config set config_value = '2.7.7.work' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists kb_article_view;
DROP FUNCTION if exists sp_kb_article_add(OUT o_article_id integer, IN p_article_name character varying, IN p_article_text text, IN p_category_id integer, IN p_event_type_id integer, IN p_creator integer);
DROP FUNCTION if exists sp_kb_article_update(p_article_id integer, p_article_name character varying, p_article_text text, p_category_id integer, p_event_type_id integer, p_modifier integer);

-- ----------
-- Upgrades for this release
-- ----------
alter table kb_article alter column article_name type character varying(225);
alter table kb_article add column article_wiki_namespace character varying(225);

CREATE UNIQUE INDEX uk_kb_article_wiki_namespace ON kb_article (lower(article_wiki_namespace));

alter table kb_article add column article_syntax_type smallint;
update kb_article set article_syntax_type=1;

alter table kb_article_archive add column article_syntax_type smallint;
alter table kb_article_archive add article_wiki_namespace character varying(225);

update kb_article_archive set article_syntax_type=1;

insert into access_page (page_id, page_name, module_id) values (284, '/issues/issue-relationship.dll', 4);
insert into access_perm_page_map(perm_id, page_id) values (1, 284);
insert into access_perm_page_map(perm_id, page_id) values (29, 284);

insert into access_page (page_id, page_name, module_id) values (285, '/reports/report-software-usage.dll', 15);
insert into access_perm_page_map(perm_id, page_id) values (13, 285);

insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (30, 'issue_delete', 1, 23);

insert into access_page (page_id, page_name, module_id) values (286, '/issues/issue-delete.dll', 4);
insert into access_perm_page_map(perm_id, page_id) values (17, 286);

insert into access_page (page_id, page_name, module_id) values (287, '/issues/issue-delete-2.dll', 4);
insert into access_perm_page_map(perm_id, page_id) values (17, 287);

update system_config set config_value='article_name,article_view_count' where config_key='kb.article.columns' and config_value='article_name,view_count';

update system_config set config_key = 'System.MultiAppsInstance' where config_key = 'File.RestrictRepositoryUpdate';

update system_config set config_value='Etc/GMT+12,Etc/GMT+11,US/Hawaii,US/Alaska,PST,MST,US/Central,EST,Canada/Atlantic,America/Montevideo,Atlantic/South_Georgia,Atlantic/Cape_Verde,Etc/Greenwich,Europe/London,Europe/Amsterdam,Asia/Jerusalem,Europe/Moscow,Asia/Tehran,Asia/Baku,Asia/Kabul,Asia/Karachi,Asia/Calcutta,Asia/Dhaka,Asia/Bangkok,Asia/Hong_Kong,Asia/Seoul,Australia/Brisbane,Australia/Canberra,Asia/Magadan,Pacific/Auckland' where config_key='timezone.local.options';

update system_config set config_value = 'en_US,de_DE,es_ES,hu_HU,it_IT,nl_NL,pl_PL,pt_BR,sr_YU,zh_CN' where config_key='locale.options';

insert into system_config (config_key, config_value) values ('software.numberLicenseNotesChars', 0);

update access_permission set order_num =143 where perm_id=25;

-- ----------
-- End upgrade
-- ----------
update system_config set config_value = '2.7.7' where config_key = 'schema.version';
