--
-- Upgrading to 2.7.5
--
-- ----------
-- Start upgrade
-- ----------
update system_config set config_value = '2.7.5.work' where config_key = 'schema.version';

-- ----------
-- Drop views, stored procedures, functions (be sure to use "if exists" as these are also copied to 
-- create-schema script, which doesn't have the views, stored procedures, function exist yet).
-- ----------
drop view if exists contract_view;
drop view if exists attribute_view;
drop view if exists attribute_value_view;
DROP FUNCTION if exists sp_contract_add(OUT o_contract_id integer, IN p_contract_name character varying, IN p_contract_description text, IN p_contract_type integer, IN p_contract_effective_date character varying, IN p_contract_expiration_date character varying, IN p_contract_renewal_date character varying, IN p_contract_renewal_type integer, IN p_contract_provider_id integer, IN p_creator integer);
DROP FUNCTION if exists sp_contract_update(p_contract_id integer, p_contract_name character varying, p_contract_description text, p_contract_type integer, p_contract_effective_date character varying, p_contract_expiration_date character varying, p_contract_renewal_date character varying, p_contract_renewal_type integer, p_contract_provider_id integer, p_modifier integer);
DROP FUNCTION if exists sp_user_archive(p_user_id integer, p_archiver integer);
DROP FUNCTION if exists sp_attribute_update(p_attribute_id integer, p_attribute_name character varying, p_attribute_url text);
DROP FUNCTION if exists sp_attribute_add(OUT o_attribute_id integer, IN p_object_type_id integer, IN p_attribute_name character varying, IN p_attribute_url text, IN p_is_optional integer, IN p_default_attribute_field_id integer);

-- ----------
-- Upgrades for this release
-- ----------
update system_config set config_value=100000 where config_key='kb.article.charLimit';

alter table contract add column contract_provider_contact integer;
alter table contract add column contract_owner integer;
alter table contract rename column company_id to contract_provider;

ALTER TABLE attribute ADD COLUMN attribute_type smallint;
update attribute set attribute_type=1;

ALTER TABLE attribute ADD COLUMN attribute_option text;

ALTER TABLE attribute ADD COLUMN attribute_convert_url smallint;
update attribute set attribute_convert_url=0;

insert into access_page (page_id, page_name, module_id) values (278, '/reports/report-software.dll', 15);
insert into access_perm_page_map(perm_id, page_id) values (13, 278);

insert into access_page (page_id, page_name, module_id) values (279, '/reports/report-contract.dll', 15);
insert into access_perm_page_map(perm_id, page_id) values (13, 279);

update system_config set config_value=config_value||',license_purchased,license_installed,license_available' where config_key='software.columnList';

alter table attribute drop column is_optional;

CREATE TABLE attribute_type_field_map (
  attribute_field_id integer NOT NULL,
  attribute_id integer NOT NULL,
  linked_attribute_id integer NOT NULL,	
  CONSTRAINT fk_attribute_type_field_id FOREIGN KEY (attribute_field_id) REFERENCES attribute_field (attribute_field_id),
  CONSTRAINT fk_attribute_type_attr_id FOREIGN KEY (attribute_id) REFERENCES attribute (attribute_id),
  CONSTRAINT fk_attribute_type_linked_attr_id FOREIGN KEY (linked_attribute_id) REFERENCES attribute (attribute_id),
  CONSTRAINT uk_attribute_type_field_map UNIQUE (attribute_field_id, attribute_id, linked_attribute_id)
);

-- Populate default data for hardware type
insert into attribute_type_field_map (attribute_field_id, attribute_id, linked_attribute_id)
select af.attribute_field_id, af.attribute_id, la.attribute_id
from attribute a, attribute_field af, attribute la 
where a.attribute_id=-10
and a.attribute_id=af.attribute_id
and la.object_type_id=2 and la.attribute_id>0
order by attribute_field_id;

-- Populate default data for issue type
insert into attribute_type_field_map (attribute_field_id, attribute_id, linked_attribute_id)
select af.attribute_field_id, af.attribute_id, la.attribute_id
from attribute a, attribute_field af, attribute la 
where a.attribute_id=-1
and a.attribute_id=af.attribute_id
and la.object_type_id=7 and la.attribute_id>0
order by attribute_field_id;

-- Populate default data for software type
insert into attribute_type_field_map (attribute_field_id, attribute_id, linked_attribute_id)
select af.attribute_field_id, af.attribute_id, la.attribute_id
from attribute a, attribute_field af, attribute la 
where a.attribute_id=-8
and a.attribute_id=af.attribute_id
and la.object_type_id=3 and la.attribute_id>0
order by attribute_field_id;

-- Populate default data for contract type
insert into attribute_type_field_map (attribute_field_id, attribute_id, linked_attribute_id)
select af.attribute_field_id, af.attribute_id, la.attribute_id
from attribute a, attribute_field af, attribute la 
where a.attribute_id=-14
and a.attribute_id=af.attribute_id
and la.object_type_id=9 and la.attribute_id>0
order by attribute_field_id;

insert into system_config(config_key, config_value) values ('auth.ldap.securityPrincipal', null);

-- ----------
-- End upgrade
-- ----------
update system_config set config_value = '2.7.5' where config_key = 'schema.version';
