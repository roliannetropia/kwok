--
-- Upgrading to 2.7.0
--
update system_config set config_value = '2.7.0' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

drop view if exists attribute_view;
DROP FUNCTION if exists sp_attribute_add(OUT o_attribute_id integer, IN p_object_type_id integer, IN p_attribute_name character varying, IN p_is_optional integer, IN p_default_attribute_field_id integer);
DROP FUNCTION if exists sp_attribute_update(p_attribute_id integer, p_attribute_name character varying);

INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/windows.gif', 1, -7);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/mac.png', 1, -7);

INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/phone_fax.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/computer_laptop.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/computer_laptop_vaio.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/monitor_mac.gif', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/monitor_pc.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/network_card.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/phone_mobile.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/phone.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/scanner.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/camera.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/television.png', 1, -10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (nextval('seq_icon_id'), '/common/default/images/icons/headset.png', 1, -10);

update system_config set config_value='Etc/GMT+12,Etc/GMT+11,US/Hawaii,US/Alaska,PST,MST,US/Central,EST,Canada/Atlantic,America/Montevideo,Atlantic/South_Georgia,Atlantic/Cape_Verde,Etc/Greenwich,Europe/Amsterdam,Asia/Jerusalem,Europe/Moscow,Asia/Tehran,Asia/Baku,Asia/Kabul,Asia/Karachi,Asia/Calcutta,Asia/Dhaka,Asia/Bangkok,Asia/Hong_Kong,Asia/Seoul,Australia/Brisbane,Australia/Canberra,Asia/Magadan,Pacific/Auckland' where config_key='timezone.local.options';

insert into system_config (config_key, config_value) values ('contracts.expirationCountdown', '90');
insert into system_config (config_key, config_value) values ('contracts.expirationCountdown.options', '0,30,90,120,365');

insert into system_config (config_key, config_value) values ('kb.article.charLimit', '8000');

insert into system_config (config_key, config_value) values ('file.db.backup.repositoryPath', 'C:\Kwok\Server\FileRepo\backup');
insert into system_config (config_key, config_value) values ('db.postgresProgramPath', 'C:\Program Files\PostgreSQL\8.3\bin\pg_dump.exe');

alter table attribute add column attribute_url text;

insert into system_config (config_key, config_value) values ('smtp.starttls', 'false');

insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (29, 'issue_read_limited', 1, 20);
insert into access_perm_page_map(perm_id, page_id) values (29, 1);
insert into access_perm_page_map(perm_id, page_id) values (29, 2);
insert into access_perm_page_map(perm_id, page_id) values (29, 3);
insert into access_perm_page_map(perm_id, page_id) values (29, 115);
insert into access_perm_page_map(perm_id, page_id) values (29, 258);

update access_page set module_id=4 where module_id=9;