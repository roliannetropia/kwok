--
-- Upgrading to 2.6.1
--
update system_config set config_value = '2.6.1' where config_key = 'schema.version';

drop view if exists portal_site_view;

DROP FUNCTION if exists sp_site_add(out o_site_id int, in p_site_name varchar(100), in p_site_path varchar(225), in p_site_description text, in p_site_is_public int, in p_site_support_iframe int, in p_creator int);
DROP FUNCTION if exists sp_site_update(p_site_id integer, p_site_name character varying, p_site_path character varying, p_site_description text, p_site_is_public integer, p_site_support_iframe integer, p_modifier integer);

ALTER TABLE portal_site rename COLUMN site_is_public to site_placement;

insert into access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (24, 'blog_comment', '', 1, 45);

insert into access_perm_page_map(perm_id, page_id) values (24, 139);

INSERT INTO system_config (config_key, config_value) VALUES ('file.contract.repositoryPath', 'C:\\KwokServer\\FileRepo\\contract');
INSERT INTO system_config (config_key, config_value) VALUES ('file.contract.uploadFilePrefix', 'CONTRACT-');

insert into access_page values (201, '/IT/contract-file-download.dll', '');
insert into access_page values (202, '/IT/contract-file-add.dll', '');
insert into access_page values (203, '/IT/contract-file-add-2.dll', '');
insert into access_page values (204, '/IT/contract-file-delete.dll', '');
insert into access_page values (205, '/IT/contract-file-delete-2.dll', '');

insert into access_perm_page_map(perm_id, page_id) values (12, 201);
insert into access_perm_page_map(perm_id, page_id) values (9, 202);
insert into access_perm_page_map(perm_id, page_id) values (9, 203);
insert into access_perm_page_map(perm_id, page_id) values (9, 204);
insert into access_perm_page_map(perm_id, page_id) values (9, 205);
