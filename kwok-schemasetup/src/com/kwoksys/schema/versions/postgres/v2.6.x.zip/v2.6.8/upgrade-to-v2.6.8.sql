--
-- Upgrading to 2.6.8
--
update system_config set config_value = '2.6.8' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

drop view if exists asset_hardware_view;
drop view if exists asset_software_view;
drop view if exists company_view;
drop view if exists category_view;
drop view if exists blog_post_view;
drop view if exists contract_view;

DROP FUNCTION if exists sp_contract_add(OUT o_contract_id integer, IN p_contract_name character varying, IN p_contract_description text, IN p_contract_type integer, IN p_contract_effective_date character varying, IN p_contract_expiration_date character varying, IN p_contract_renewal_date character varying, IN p_contract_renewal_type integer, IN p_creator integer);
DROP FUNCTION if exists sp_contract_update(p_contract_id integer, p_contract_name character varying, p_contract_description text, p_contract_type integer, p_contract_effective_date character varying, p_contract_expiration_date character varying, p_contract_renewal_date character varying, p_contract_renewal_type integer, p_modifier integer);

drop sequence if exists seq_blog_post_category_id;

-- Adding access_page.module_id column
ALTER TABLE access_page ADD COLUMN module_id integer;

-- Populating module_id value
update access_page set module_id=10 where page_id in (select page_id from access_perm_page_map where perm_id in (3,4));
update access_page set module_id=6 where page_id in (select page_id from access_perm_page_map where perm_id in (19,24,21,16));
update access_page set module_id=5 where page_id in (select page_id from access_perm_page_map where perm_id in (10,11));
update access_page set module_id=3 where page_id in (select page_id from access_perm_page_map where perm_id in (12,9));
update access_page set module_id=1 where page_id in (select page_id from access_perm_page_map where perm_id in (6,22));
update access_page set module_id=15 where page_id in (select page_id from access_perm_page_map where perm_id in (13));
update access_page set module_id=4 where page_id in (select page_id from access_perm_page_map where perm_id in (1,2));
update access_page set module_id=14 where page_id in (select page_id from access_perm_page_map where perm_id in (26,27,28));
update access_page set module_id=7 where page_id in (select page_id from access_perm_page_map where perm_id in (15,25));
update access_page set module_id=8 where page_id in (select page_id from access_perm_page_map where perm_id in (18,20));
update access_page set module_id=2 where page_id in (select page_id from access_perm_page_map where perm_id in (8,23));
update access_page set module_id=11 where page_id in (select page_id from access_perm_page_map where perm_id in (14));
update access_page set module_id=16 where page_id in (select page_id from access_perm_page_map where perm_id in (17));
update access_page set module_id=9 where page_id in (12,13,14);

insert into access_page (page_id, page_name, page_description, module_id) values (257, '/home/index.dll', '', 13);

insert into access_page (page_id, page_name, page_description, module_id) values (258, '/issue-tracker/issue-list-export.dll', '', 4);
insert into access_perm_page_map(perm_id, page_id) values (1, 258);

-- Description columns has never been used in the past
alter table access_page drop column page_description;
alter table access_permission drop column perm_description;

-- Rename category.count_post column
alter table category rename column count_post to object_count;

-- Renaming count_ columns
alter table asset_hardware rename column count_software to software_count;
alter table asset_hardware rename column count_file to file_count;
alter table asset_hardware rename column count_component to component_count;
alter table asset_software rename column count_file to file_count;
alter table asset_software rename column count_license to license_count;
alter table asset_software rename column count_bookmark to bookmark_count;
alter table company rename column count_file to file_count;
alter table company rename column count_bookmark to bookmark_count;
alter table company rename column count_main_contact to main_contact_count;
alter table company rename column count_employee_contact to employee_contact_count;
alter table company rename column count_note to note_count;
alter table blog_post rename column count_comment to comment_count;

-- Need reset password pages
insert into access_page (page_id, page_name, module_id) values (259, '/admin/user-pw-reset.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 259);

insert into access_page (page_id, page_name, module_id) values (260, '/admin/user-pw-reset-2.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 260);

insert into system_config (config_key, config_value) values ('admin.allowBlankUserPassword', 0);

-- Need KB article print view page
insert into access_page (page_id, page_name, module_id) values (261, '/kb/article-print.dll', 14);
insert into access_perm_page_map(perm_id, page_id) values (26, 261);

-- Contract index page
insert into access_page (page_id, page_name, module_id) values (262, '/IT/contract-index.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (12, 262);

CREATE SEQUENCE seq_category_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

select setval('seq_category_id', max(category_id)) from category;

update system_config set config_value='Etc/GMT+12,Etc/GMT+11,US/Hawaii,US/Alaska,PST,MST,US/Central,EST,Canada/Atlantic,America/Montevideo,Atlantic/South_Georgia,Atlantic/Cape_Verde,Etc/Greenwich,Europe/Amsterdam,Asia/Jerusalem,Europe/Moscow,Asia/Tehran,Asia/Baku,Asia/Kabul,Asia/Karachi,Asia/Calcutta,Asia/Dhaka,Asia/Bangkok,Asia/Hong_Kong,Asia/Seoul,Australia/Canberra,Asia/Magadan,Pacific/Auckland' where config_key='timezone.local.options';
