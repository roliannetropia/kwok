--
-- Upgrading to 2.6.0
--
update system_config set config_value = '2.6.0' where config_key = 'schema.version';

delete from system_config where config_key = 'rp.authPackages';

delete from system_config where config_key = 'rp.packages';

update system_config set config_value = '13,1,2,4,5,3,6,8,7' where config_key = 'template.showModules';

update system_config set config_key = 'template.moduleTabs' where config_key = 'template.showModules';

drop function if exists  sp_user_logout(in p_user_id int);

alter table attribute_field add attribute_field_name character varying(50);

update attribute_field set attribute_field_name = content_local from content_local where content_local.content_id=attribute_field.content_id;

drop view if exists attribute_field_view;

alter table attribute_field drop column content_id;

drop table content_local;

drop sequence seq_content_local_id;

update access_permission set perm_name='rss_write', order_num=47 where perm_id=18;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (20, 'rss_read', '', 1, 46);

insert into access_perm_page_map(perm_id, page_id) values (20, 188);
insert into access_perm_page_map(perm_id, page_id) values (20, 187);
insert into access_perm_page_map(perm_id, page_id) values (20, 186);
insert into access_perm_page_map(perm_id, page_id) values (20, 179);

update access_permission set perm_name='blog_write', order_num=44 where perm_id=16;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (21, 'blog_read', '', 1, 43);

insert into access_perm_page_map(perm_id, page_id) values (21, 134);
insert into access_perm_page_map(perm_id, page_id) values (21, 140);
insert into access_perm_page_map(perm_id, page_id) values (21, 133);
insert into access_perm_page_map(perm_id, page_id) values (21, 118);

update access_permission set perm_name='blog_admin', order_num=45 where perm_id=19;

delete from access_perm_page_map where perm_id=15;
insert into access_perm_page_map(perm_id, page_id) values (15, 119);
insert into access_perm_page_map(perm_id, page_id) values (15, 132);

delete from access_perm_page_map where perm_id=5;
delete from access_user_perm_map where perm_id=5;
delete from access_permission where perm_id=5;

delete from access_perm_page_map where perm_id=7;
delete from access_user_perm_map where perm_id=7;
delete from access_permission where perm_id=7;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (22, 'hardware_write', '', 1, 34);
insert into access_perm_page_map(perm_id, page_id) values (22, 20);
insert into access_perm_page_map(perm_id, page_id) values (22, 21);
insert into access_perm_page_map(perm_id, page_id) values (22, 22);
insert into access_perm_page_map(perm_id, page_id) values (22, 23);
insert into access_perm_page_map(perm_id, page_id) values (22, 24);
insert into access_perm_page_map(perm_id, page_id) values (22, 25);
insert into access_perm_page_map(perm_id, page_id) values (22, 27);

insert into access_perm_page_map(perm_id, page_id) values (22, 45);
insert into access_perm_page_map(perm_id, page_id) values (22, 46);
insert into access_perm_page_map(perm_id, page_id) values (22, 47);
insert into access_perm_page_map(perm_id, page_id) values (22, 141);
insert into access_perm_page_map(perm_id, page_id) values (22, 142);
insert into access_perm_page_map(perm_id, page_id) values (22, 145);
insert into access_perm_page_map(perm_id, page_id) values (22, 146);

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (23, 'software_write', '', 1, 36);

insert into access_perm_page_map(perm_id, page_id) values (23, 31);
insert into access_perm_page_map(perm_id, page_id) values (23, 30);
insert into access_perm_page_map(perm_id, page_id) values (23, 94);
insert into access_perm_page_map(perm_id, page_id) values (23, 93);
insert into access_perm_page_map(perm_id, page_id) values (23, 98);
insert into access_perm_page_map(perm_id, page_id) values (23, 97);
insert into access_perm_page_map(perm_id, page_id) values (23, 96);
insert into access_perm_page_map(perm_id, page_id) values (23, 95);
insert into access_perm_page_map(perm_id, page_id) values (23, 32);
insert into access_perm_page_map(perm_id, page_id) values (23, 38);
insert into access_perm_page_map(perm_id, page_id) values (23, 37);
insert into access_perm_page_map(perm_id, page_id) values (23, 36);
insert into access_perm_page_map(perm_id, page_id) values (23, 110);
insert into access_perm_page_map(perm_id, page_id) values (23, 109);
insert into access_perm_page_map(perm_id, page_id) values (23, 114);
insert into access_perm_page_map(perm_id, page_id) values (23, 113);
insert into access_perm_page_map(perm_id, page_id) values (23, 33);
insert into access_perm_page_map(perm_id, page_id) values (23, 39);
insert into access_perm_page_map(perm_id, page_id) values (23, 35);
insert into access_perm_page_map(perm_id, page_id) values (23, 44);
insert into access_perm_page_map(perm_id, page_id) values (23, 34);
insert into access_perm_page_map(perm_id, page_id) values (23, 40);

update access_permission set perm_name='hardware_read' where perm_id=6;
update access_permission set perm_name='software_read' where perm_id=8;

insert into access_page (page_id, page_name, page_description) values (200, '/IT/software-index.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (8, 200);

delete from access_perm_page_map where perm_id=9 and page_id not in (170,171,172,173,174,175);
delete from access_perm_page_map where perm_id=12 and page_id not in(168,169);

update access_permission set perm_name='contract_read', order_num=37 where perm_id=12;
update access_permission set perm_name='contract_write', order_num=38 where perm_id=9;

update access_page set page_name = '/IT/hardware-index.dll' where page_id=17;

insert into system_config (config_key, config_value) values ('company.footerNotes', '');

update system_config set config_key='blogs.numberOfPostCharsToShow' where config_key='portal.numberOfBlogPostCharactersOnList';
update system_config set config_key='blogs.numberOfPostsToShow' where config_key='portal.numberOfBlogPostsToShowOnList';
delete from system_config where config_key='portal.numberOfBlogPostCharactersOnMain';
delete from system_config where config_key='portal.numberOfBlogPostsToShowOnMain';

insert into system_config (config_key, config_value) values ('home.customDescription', '');
