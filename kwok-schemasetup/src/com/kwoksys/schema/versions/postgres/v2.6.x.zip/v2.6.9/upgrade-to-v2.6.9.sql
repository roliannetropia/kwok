--
-- Upgrading to 2.6.9
--
update system_config set config_value = '2.6.9' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

drop view if exists user_view;

-- Added new Portuguese locale
update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,nl_NL,pt_BR,sr_YU,zh_CN' where config_key='locale.options';

update system_config set config_key='ad.display', config_value = 1 where config_key='license.key';

insert into system_config(config_key, config_value) values ('auth.type', 'form');
insert into system_config(config_key, config_value) values ('auth.type.options', 'form,basic');

alter table company drop column company_stock_symbol;

insert into access_page (page_id, page_name, module_id) values (263, '/admin/user-hardware.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (3, 263);

alter table access_user add hardware_count integer DEFAULT 0;
update access_user set hardware_count = (select count(hardware_id) from asset_hardware where hardware_owner = access_user.user_id);