--
-- Upgrading to 2.6.3
--
update system_config set config_value = '2.6.3' where config_key = 'schema.version';

insert into system_config (config_key, config_value) values ('datetime.numberOfPastYears',4);
insert into system_config (config_key, config_value) values ('datetime.numberOfUpcomingYears',4);

insert into system_config (config_key, config_value) values ('portal.columnList','site_name,site_path,site_placement,site_support_iframe');
insert into system_config (config_key, config_value) values ('contacts.companyColumnList','company_name');
insert into system_config (config_key, config_value) values ('contacts.columnList','contact_first_name,contact_last_name,contact_title,company_name');
insert into system_config (config_key, config_value) values ('issues.columnList','issue_id,issue_name,issue_status,issue_priority,assignee_name,creation_date');
insert into system_config (config_key, config_value) values ('hardware.columnList','hardware_name,hardware_model_name,hardware_last_service_date,hardware_owner_name');
insert into system_config (config_key, config_value) values ('software.columnList','software_name,software_manufacturer');
insert into system_config (config_key, config_value) values ('contracts.columnList','contract_name,contract_expiration_date,contract_effective_date');

alter table attribute_field add column is_disabled smallint;

drop view if exists attribute_field_view;

DROP FUNCTION if exists sp_attribute_field_add(OUT o_attribute_field_id integer, IN p_attribute_id integer, IN p_attribute_field_name character varying, IN p_attribute_field_description text, IN p_icon_id integer);
DROP FUNCTION if exists sp_attribute_field_update(p_attribute_id integer, p_attribute_field_id integer, p_attribute_field_name character varying, p_attribute_field_description text, p_icon_id integer);

