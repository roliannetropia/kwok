--
-- Upgrading to 2.6.5
--
-- Chnage access_user column type to make it work for Postgres 8.3.0
drop view if exists user_view;

alter table access_user add column new_status smallint DEFAULT 1::smallint;
update access_user set new_status=to_number(status, text(99999999));
alter table access_user drop column status;

alter table access_user add column status smallint DEFAULT 1::smallint;
update access_user set status=new_status;
alter table access_user drop column new_status;

update system_config set config_value = '2.6.5' where config_key = 'schema.version';

drop view if exists attribute_view;

-- 1 means custom attribute, 0 means non custom attribute.
alter table attribute add column is_custom_attr smallint DEFAULT 1::smallint;
update attribute set is_custom_attr=0;

CREATE TABLE attribute_value (
    attribute_id integer NOT NULL,
	attr_value text NOT NULL,
    object_id integer NOT NULL
);

ALTER TABLE attribute_value ADD CONSTRAINT fk_attr_value_attr_id FOREIGN KEY (attribute_id) REFERENCES attribute(attribute_id);

-- Updating system attribute_id to negative numbers
alter table icon drop CONSTRAINT fk_icon_attribute_id;
alter table attribute_field drop CONSTRAINT fk_attribute_field_attribute_id;

update attribute set attribute_id=-1 where attribute_id=1;
update attribute set attribute_id=-2 where attribute_id=2;
update attribute set attribute_id=-3 where attribute_id=3;
update attribute set attribute_id=-4 where attribute_id=4;
update attribute set attribute_id=-5 where attribute_id=5;
update attribute set attribute_id=-6 where attribute_id=6;
update attribute set attribute_id=-7 where attribute_id=7;
update attribute set attribute_id=-8 where attribute_id=8;
update attribute set attribute_id=-10 where attribute_id=10;
update attribute set attribute_id=-11 where attribute_id=11;
update attribute set attribute_id=-12 where attribute_id=12;
update attribute set attribute_id=-13 where attribute_id=13;
update attribute set attribute_id=-14 where attribute_id=14;
update attribute set attribute_id=-15 where attribute_id=15;
update attribute set attribute_id=-16 where attribute_id=16;

update attribute_field set attribute_id=-1 where attribute_id=1;
update attribute_field set attribute_id=-2 where attribute_id=2;
update attribute_field set attribute_id=-3 where attribute_id=3;
update attribute_field set attribute_id=-4 where attribute_id=4;
update attribute_field set attribute_id=-5 where attribute_id=5;
update attribute_field set attribute_id=-6 where attribute_id=6;
update attribute_field set attribute_id=-7 where attribute_id=7;
update attribute_field set attribute_id=-8 where attribute_id=8;
update attribute_field set attribute_id=-10 where attribute_id=10;
update attribute_field set attribute_id=-11 where attribute_id=11;
update attribute_field set attribute_id=-12 where attribute_id=12;
update attribute_field set attribute_id=-13 where attribute_id=13;
update attribute_field set attribute_id=-14 where attribute_id=14;
update attribute_field set attribute_id=-15 where attribute_id=15;
update attribute_field set attribute_id=-16 where attribute_id=16;

update icon set attribute_id=-1 where attribute_id=1;
update icon set attribute_id=-2 where attribute_id=2;
update icon set attribute_id=-3 where attribute_id=3;
update icon set attribute_id=-4 where attribute_id=4;
update icon set attribute_id=-5 where attribute_id=5;
update icon set attribute_id=-6 where attribute_id=6;
update icon set attribute_id=-7 where attribute_id=7;
update icon set attribute_id=-8 where attribute_id=8;
update icon set attribute_id=-10 where attribute_id=10;
update icon set attribute_id=-11 where attribute_id=11;
update icon set attribute_id=-12 where attribute_id=12;
update icon set attribute_id=-13 where attribute_id=13;
update icon set attribute_id=-14 where attribute_id=14;
update icon set attribute_id=-15 where attribute_id=15;
update icon set attribute_id=-16 where attribute_id=16;

alter table icon add CONSTRAINT fk_icon_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute (attribute_id);
alter table attribute_field add CONSTRAINT fk_attribute_field_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute (attribute_id);

insert into access_page (page_id, page_name, page_description) values (216, '/admin/usage-survey.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 216);

-- Add unique constraint to attribute_value table
alter table attribute_value add CONSTRAINT uk_attribute_value_attr_obj_id UNIQUE (attribute_id, object_id);

-- For custom fields
insert into access_page (page_id, page_name, page_description) values (217, '/admin/cust-attr.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (3, 217);

insert into access_page (page_id, page_name, page_description) values (218, '/admin/cust-attr-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 218);

insert into access_page (page_id, page_name, page_description) values (219, '/admin/cust-attr-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 219);

insert into access_page (page_id, page_name, page_description) values (220, '/admin/cust-attr-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 220);

insert into access_page (page_id, page_name, page_description) values (221, '/admin/cust-attr-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 221);

insert into access_page (page_id, page_name, page_description) values (222, '/admin/cust-attr-delete.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 222);

insert into access_page (page_id, page_name, page_description) values (223, '/admin/cust-attr-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 223);

insert into access_page (page_id, page_name, page_description) values (224, '/admin/cust-attr-detail.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (3, 224);

CREATE SEQUENCE seq_attribute_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

delete from system_config where config_key='default.serviceName';
insert into system_config (config_key, config_value) values ('usage.survey', 0);