--
-- pk_ for primary keys
-- fk_ for foreign keys
-- uk_ for unique keys

-- sp_ for functions

-- idx_ for indexes
-- seq_ for sequences

-- p_ prefix is for input parameters 
-- o_ for output parameters
-- v_ for variables

-- Keywords: _add, _update, _delete

-- -------------------------------------------------------------------
-- For Views
-- -------------------------------------------------------------------
--
-- View: asset_hardware_view
--
create or replace view asset_hardware_view as 
	select ah.hardware_id, ah.hardware_number, ah.hardware_name, ah.hardware_description, ah.hardware_type, ah.hardware_status, ho.display_name as hardware_owner_name, ho.user_id as hardware_owner_id, ah.hardware_model_name, ah.hardware_model_number, ah.hardware_serial_number, ah.hardware_cost, ah.hardware_last_service_date, ah.hardware_purchase_date, ah.hardware_warranty_expire_date, ah.hardware_location, ah.manufacturer_company_id, ah.vendor_company_id, ah.count_software, ah.count_file,
	ah.creator, ah.creation_date, hc.display_name as creator_name, ah.modifier, ah.modification_date, hm.display_name as modifier_name
	from asset_hardware ah 
    left outer join access_user ho on ah.hardware_owner = ho.user_id 
	left outer join access_user hc on ah.creator = hc.user_id 
	left outer join access_user hm on ah.modifier = hm.user_id; 

--
-- View: asset_software_view
--
create or replace view asset_software_view as 
	select	s.software_id, s.software_name, s.software_description, s.software_type, s.operating_system, 
			s.quoted_retail_price, s.quoted_oem_price, s.manufacturer_company_id, s.vendor_company_id, 
			s.count_license, s.count_file, s.count_bookmark,
			s.creator, s.creation_date, sc.display_name as creator_name, s.modifier, s.modification_date, sm.display_name as modifier_name
    from	asset_software s
	left outer join access_user sc on s.creator = sc.user_id 
	left outer join access_user sm on s.modifier = sm.user_id; 

--
-- View: attribute_field_view
--
create or replace view attribute_field_view as 
	select af.attribute_field_id, af.attribute_field_name, af.attribute_id, af.field_key, af.field_key_id, af.attribute_field_description, af.icon_id
	from attribute_field af;

--
-- View: attribute_view
--
create or replace view attribute_view as 
	select a.attribute_id, a.object_type_id, so.object_key, a.attribute_key, a.type, a.default_attribute_field_id, a.is_optional, a.is_editable
	from attribute a, system_object so
	where a.object_type_id = so.object_type_id;

--
-- View: bookmark_view
--
create or replace view bookmark_view as 
	select b.bookmark_id, b.bookmark_name, b.bookmark_description, b.bookmark_path, bm.object_type_id, bm.object_id
	from bookmark b, bookmark_map bm 
	where b.bookmark_id=bm.bookmark_id; 

--
-- View: contract_view
--
create or replace view contract_view as 
	select c.contract_id, c.contract_name, c.contract_description, c.contract_type, c.contract_effective_date, 
		c.contract_expiration_date, c.contract_renewal_type, c.contract_renewal_date, c.company_id, 
		c.creator, c.creation_date, cc.display_name as creator_name, c.modifier, c.modification_date, cm.display_name as modifier_name
	from contract c
	left outer join access_user cc on c.creator = cc.user_id 
	left outer join access_user cm on c.modifier = cm.user_id; 

--
-- View: company_view
--
create or replace view company_view as 
	select c.company_id, c.company_name, c.company_description, c.company_stock_symbol, 
	c.count_main_contact, c.count_employee_contact, c.count_file, c.count_bookmark, c.count_note, 
	c.creator, c.creation_date, cc.display_name as creator_name, c.modifier, c.modification_date, cm.display_name as modifier_name
	from company c
	left outer join access_user cc on c.creator = cc.user_id 
	left outer join access_user cm on c.modifier = cm.user_id; 

--
-- View: company_tag_map_view
--
create or replace view company_tag_map_view as 
	select ct.tag_id, ct.tag_name, ctm.company_id
	from company_tag ct, company_tag_map ctm
	where ct.tag_id = ctm.tag_id; 

--
-- View: contact_view
--
create or replace view contact_view as 
	select c.contact_id, c.contact_first_name, c.contact_last_name, c.contact_title, c.contact_phone_home, c.contact_phone_mobile, c.contact_phone_work, c.contact_description, 
    c.contact_fax, c.contact_email_primary, c.contact_email_secondary, c.contact_homepage_url, co.company_name, c.company_id, c.company_contact_type,
    c.address_street_primary, c.address_city_primary, c.address_state_primary, c.address_zipcode_primary, c.address_country_primary,
	c.messenger_1_type, c.messenger_1_id, c.messenger_2_type, c.messenger_2_id,
	c.user_id, c.creator, c.creation_date, cc.display_name as creator_name, c.modifier, c.modification_date, cm.display_name as modifier_name
	from contact c 
	left outer join company co on c.company_id = co.company_id
	left outer join access_user cc on c.creator = cc.user_id 
	left outer join access_user cm on c.modifier = cm.user_id; 

--
-- View: file_view
--
create or replace view file_view as 
	select	f.file_id, f.file_name, f.file_friendly_name, f.file_description, f.file_mime_type, f.file_byte_size, f.file_uploaded_file_name, f.creator, f.creation_date,
			fm.object_type_id, fm.object_id
	from	file f, file_map fm 
	where	f.file_id=fm.file_id; 

--
-- View: issue_view
--
create or replace view issue_view as 
	select	i.issue_id, i.issue_name, i.issue_description, ua.display_name as assignee_name, ua.user_id as assignee_id, 
			i.issue_url, i.issue_type, i.issue_status, i.issue_priority, i.issue_resolution, i.duplicate_id, 
			i.issue_due_date, i.creator, i.creator_ip, i.creation_date, i.modifier, i.modification_date
	from	issue i
	left outer join access_user ua on i.issue_assignee = ua.user_id;

--
-- View: blog_post_view
--
create or replace view blog_post_view as 
	select bp.post_id, bp.post_name, bp.post_description, bp.post_type, bp.post_ip, bp.post_allow_comment, bp.count_comment, bp.category_id, bpc.category_name,
		bp.creator, bp.creation_date, uc.display_name as creator_name,
		bp.modifier, bp.modification_date, um.display_name as modifier_name
	from blog_post bp
	left outer join access_user uc on bp.creator = uc.user_id 
	left outer join access_user um on bp.modifier = um.user_id
	left outer join blog_post_category bpc on bp.category_id = bpc.category_id; 

--
-- View: blog_post_comment_view
--
create or replace view blog_post_comment_view as 
	select pc.comment_id, pc.comment_description, pc.comment_ip, pc.post_id, 
		pc.creator, pc.creation_date, uc.display_name as creator_name
	from blog_post_comment pc
	left outer join access_user uc on pc.creator = uc.user_id; 

--
-- View: blog_post_category_view
--
create or replace view blog_post_category_view as 
	select pca.category_id, pca.category_name, pca.category_description, pca.count_post, 
		pca.creator, pca.creation_date, uc.display_name as creator_name
	from blog_post_category pca
	left outer join access_user uc on pca.creator = uc.user_id; 

--
-- View: portal_site_view
--
create or replace view portal_site_view as 
	select ps.site_id, ps.site_name, ps.site_path, ps.site_description, ps.site_placement, ps.site_support_iframe, 
		ps.creator, ps.creation_date, uc.display_name as creator_name,
		ps.modifier, ps.modification_date, um.display_name as modifier_name
	from portal_site ps
	left outer join access_user uc on ps.creator = uc.user_id 
	left outer join access_user um on ps.modifier = um.user_id; 

--
-- View: user_view
--
create or replace view user_view as 
	select u.user_id, u.username, u.password, u.display_name, u.status, u.first_name, u.last_name, u.email, u.creator, u.creation_date, uc.display_name as creator_name,
		u.modifier, u.modification_date, um.display_name as modifier_name, c.contact_id
	from access_user u
	left outer join access_user uc on u.creator = uc.user_id 
	left outer join access_user um on u.modifier = um.user_id
	left outer join contact c on u.user_id = c.user_id;  

--
-- View: group_view
--
create or replace view group_view as 
	select g.group_id, g.group_name, g.group_description, g.creator, g.creation_date, gc.display_name as creator_name,
		g.modifier, g.modification_date, gm.display_name as modifier_name
	from access_group g
	left outer join access_user gc on g.creator = gc.user_id 
	left outer join access_user gm on g.modifier = gm.user_id;

--
-- Stored Procedures Creation SQL Scripts
--

-- 
-- This is for adding attribute field.
-- 
create or replace function sp_attribute_field_add(out o_attribute_field_id int, in p_attribute_id int, in p_attribute_field_name varchar(50), in p_attribute_field_description text, in p_icon_id int)
RETURNS integer AS $$
declare v_attr_icon_count integer;
begin
	insert into attribute_field (attribute_field_id, attribute_field_name, attribute_id, attribute_field_description) values (nextval('seq_attribute_field_id'), p_attribute_field_name, p_attribute_id, p_attribute_field_description);

	select count(*) into v_attr_icon_count from icon where attribute_id = p_attribute_id;

	select currval('seq_attribute_field_id') into o_attribute_field_id;

	if v_attr_icon_count > 0 then 
		update attribute_field set icon_id = p_icon_id where attribute_field_id = o_attribute_field_id;		
	end if;
end;
$$ LANGUAGE 'plpgsql';

-- 
-- This is for updating attribute field.
-- 
create or replace function sp_attribute_field_update(in p_attribute_id int, in p_attribute_field_id int, in p_attribute_field_name varchar(50), in p_attribute_field_description text, in p_icon_id int)
RETURNS void AS $$
declare v_attr_icon_count integer;
begin
	update attribute_field set attribute_field_name = p_attribute_field_name, attribute_field_description = p_attribute_field_description where attribute_field_id = p_attribute_field_id;

	select count(*) into v_attr_icon_count from icon where attribute_id = p_attribute_id;

	if v_attr_icon_count > 0 then 
		update attribute_field set icon_id = p_icon_id where attribute_field_id = p_attribute_field_id;		
	end if;
end; 
$$ LANGUAGE 'plpgsql';

-- This is for deleting files associated with an object
create or replace function sp_file_delete(in p_object_type_id int, in p_object_id int)
RETURNS void AS $$
	declare _record record;
	declare v_file_id integer;
begin

	FOR _record IN select distinct file_id from file_map where object_type_id = p_object_type_id and object_id = p_object_id

	-- Now let's work on the File cursor.
	LOOP 
		v_file_id := _record.file_id; 

		delete from file_map where file_id = v_file_id;
		delete from file where file_id = v_file_id;
	end loop;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for inserting a new User.
--
create or replace function sp_user_add(out o_user_id int, in p_contact_id int, in p_username varchar(50), in p_first_name varchar(50), in p_last_name varchar(50), in p_display_name varchar(50), in p_email varchar(255), in p_status int, in p_password varchar(32), in p_contact_title varchar(100), in p_company_id int, in p_company_contact_type int, in p_contact_phone_home varchar(50), in p_contact_phone_mobile varchar(50), in p_contact_phone_work varchar(50), in p_contact_fax varchar(50), in p_contact_email_secondary varchar(50), in p_messenger_1_type int, in p_messenger_1_id varchar(50), in p_messenger_2_type int, in p_messenger_2_id varchar(50), in p_contact_homepage_url varchar(50), in p_contact_description text, in p_address_street_primary varchar(50), in p_address_city_primary varchar(50), in p_address_state_primary varchar(50), in p_address_zipcode_primary varchar(50), in p_address_country_primary varchar(50), in p_creator int)
RETURNS integer AS $$
	declare v_company_id integer;
begin 

	-- Insert a record into access_user table.
	insert into access_user (user_id, username, first_name, last_name, display_name, email, status, password, creator, creation_date)
		values (nextval('seq_user_id'), p_username, p_first_name, p_last_name, p_display_name, p_email, p_status, p_password, p_creator, now());

	select currval('seq_user_id') into o_user_id;

	-- insert a record into user_session table so that the user can logon.
	insert into user_session (user_id) values (o_user_id);

	-- Update user contact.
	PERFORM sp_user_contact_update(o_user_id, p_contact_id, p_first_name, p_last_name, p_email, p_contact_title, p_company_id, p_company_contact_type, p_contact_phone_home, p_contact_phone_mobile, p_contact_phone_work, p_contact_fax, p_contact_email_secondary, p_messenger_1_type, p_messenger_1_id, p_messenger_2_type, p_messenger_2_id, p_contact_homepage_url, p_contact_description, p_address_street_primary, p_address_city_primary, p_address_state_primary, p_address_zipcode_primary, p_address_country_primary, p_creator);
	
end;
$$ LANGUAGE 'plpgsql';

-- 
-- This is for updating user contact.
--
create or replace function sp_user_contact_update(in p_user_id int, in p_contact_id int, in p_first_name varchar(50), in p_last_name varchar(50), in p_email varchar(255), in p_contact_title varchar(100), in p_company_id int, in p_company_contact_type int, in p_contact_phone_home varchar(50), in p_contact_phone_mobile varchar(50), in p_contact_phone_work varchar(50), in p_contact_fax varchar(50), in p_contact_email_secondary varchar(50), in p_messenger_1_type int, in p_messenger_1_id varchar(50), in p_messenger_2_type int, in p_messenger_2_id varchar(50), in p_contact_homepage_url varchar(50), in p_contact_description text, in p_address_street_primary varchar(50), in p_address_city_primary varchar(50), in p_address_state_primary varchar(50), in p_address_zipcode_primary varchar(50), in p_address_country_primary varchar(50), in p_creator int)
RETURNS void AS $$
	declare v_company_id integer;
begin

	if p_contact_id = 0 then 
		-- insert a record into contact table.
		insert into contact (contact_id, user_id, contact_first_name, contact_last_name, contact_title, company_id, company_contact_type, contact_phone_home, contact_phone_mobile, contact_phone_work, contact_fax, contact_email_primary, contact_email_secondary, messenger_1_type, messenger_1_id, messenger_2_type, messenger_2_id, contact_homepage_url, contact_description, address_street_primary, address_city_primary, address_state_primary, address_zipcode_primary, address_country_primary, creator, creation_date) 
			values (nextval('seq_contact_id'), p_user_id, p_first_name, p_last_name, p_contact_title, p_company_id, p_company_contact_type, p_contact_phone_home, p_contact_phone_mobile, p_contact_phone_work, p_contact_fax, p_email, p_contact_email_secondary, p_messenger_1_type, p_messenger_1_id, p_messenger_2_type, p_messenger_2_id, p_contact_homepage_url, p_contact_description, p_address_street_primary, p_address_city_primary, p_address_state_primary, p_address_zipcode_primary, p_address_country_primary, p_creator, now());
	else 
		-- Need to do the select into first.
		select company_id into v_company_id from contact where user_id = p_user_id;

		update contact set contact_first_name = p_first_name, contact_last_name = p_last_name, contact_title=p_contact_title, company_id=p_company_id, contact_phone_home=p_contact_phone_home, contact_phone_mobile = p_contact_phone_mobile, contact_phone_work = p_contact_phone_work,
			contact_fax=p_contact_fax, contact_email_primary = p_email, contact_email_secondary = p_contact_email_secondary, 
			messenger_1_type = p_messenger_1_type, messenger_1_id = p_messenger_1_id, messenger_2_type = p_messenger_2_type, messenger_2_id = p_messenger_2_id,
			contact_homepage_url = p_contact_homepage_url, contact_description = p_contact_description,
	        address_street_primary = p_address_street_primary, address_city_primary=p_address_city_primary, address_state_primary=p_address_state_primary, address_zipcode_primary=p_address_zipcode_primary, address_country_primary=p_address_country_primary,
			user_id = p_user_id, modifier=p_creator, modification_date=now()
	        where contact_id = p_contact_id;

		if v_company_id is not null then
			-- Update contact count for old company_id
			perform sp_company_count_contact_update(v_company_id, p_company_contact_type);
		end if;
	end if;

	-- Update contact count.
	perform sp_company_count_contact_update(p_company_id, p_company_contact_type);
end;
$$ LANGUAGE 'plpgsql';
	

--
-- This is for updating User password.
--
create or replace function sp_user_password_update(in p_password varchar(32), in p_user_id int)
RETURNS void AS $$
begin
	update access_user set password=p_password where user_id =p_user_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating User access.
--
create or replace function sp_user_perm_map_update(in p_user_id int, in p_perm_id int, in p_cmd int)
RETURNS void AS $$
	declare map_count integer;
begin
    -- p_cmd: 1 means adding access, 2 means removing access.
	select	count(*) into map_count
	from	access_user_perm_map
	where	user_id = p_user_id
	and		perm_id = p_perm_id;

	-- We're going to grant access.
	if p_cmd=1 then
		if map_count=0 then
			insert into access_user_perm_map (user_id, perm_id) values (p_user_id, p_perm_id);
		end if;
	end if;

	if p_cmd=0 then
		if map_count!=0 then
			delete from access_user_perm_map where user_id = p_user_id and perm_id = p_perm_id;
		end if;
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating User detail.
--
create or replace function sp_user_update(in p_user_id int, in p_username varchar(50), in p_first_name varchar(50), in p_last_name varchar(50), in p_display_name varchar(50), in p_email varchar(255), in p_status int, in p_contact_title varchar(100), in p_company_id int, in p_company_contact_type int, in p_contact_phone_home varchar(50), in p_contact_phone_mobile varchar(50), in p_contact_phone_work varchar(50), in p_contact_fax varchar(50), in p_contact_email_secondary varchar(50), in p_messenger_1_type int, in p_messenger_1_id varchar(50), in p_messenger_2_type int, in p_messenger_2_id varchar(50), in p_contact_homepage_url varchar(50), in p_contact_description text, in p_address_street_primary varchar(50), in p_address_city_primary varchar(50), in p_address_state_primary varchar(50), in p_address_zipcode_primary varchar(50), in p_address_country_primary varchar(50), in p_modifier int)
RETURNS void AS $$
	declare v_contact_id integer;
begin

	update access_user set username = p_username, first_name = p_first_name, last_name = p_last_name, display_name=p_display_name, email=p_email, status=p_status, modifier=p_modifier, modification_date=now() 
		where user_id=p_user_id;

	-- Need to do the select into first.
	select contact_id into v_contact_id from contact where user_id = p_user_id;

	-- Update user contact.
	perform sp_user_contact_update(p_user_id, v_contact_id, p_first_name, p_last_name, p_email, p_contact_title, p_company_id, p_company_contact_type, p_contact_phone_home, p_contact_phone_mobile, p_contact_phone_work, p_contact_fax, p_contact_email_secondary, p_messenger_1_type, p_messenger_1_id, p_messenger_2_type, p_messenger_2_id, p_contact_homepage_url, p_contact_description, p_address_street_primary, p_address_city_primary, p_address_state_primary, p_address_zipcode_primary, p_address_country_primary, p_modifier);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for inserting a new group.
--
create or replace function sp_group_add(out o_group_id int, in p_group_name varchar(50), in p_group_description text, in p_creator int)
RETURNS integer AS $$
	declare v_company_id integer;
begin 

	-- Insert a record into access_user table.
	insert into access_group (group_id, group_name, group_description, creator, creation_date)
		values (nextval('seq_group_id'), p_group_name, p_group_description, p_creator, now());

	select currval('seq_group_id') into o_group_id;	
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating group detail.
--
create or replace function sp_group_update(in p_group_id int, in p_group_name varchar(50), in p_group_description text, in p_modifier int)
RETURNS void AS $$
begin

	update access_group set group_name = p_group_name, group_description = p_group_description, modifier=p_modifier, modification_date=now() 
		where group_id = p_group_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating group access.
--
create or replace function sp_group_perm_map_update(in p_group_id int, in p_perm_id int, in p_cmd int)
RETURNS void AS $$
	declare map_count integer;
begin
    -- p_cmd: 1 means adding access, 2 means removing access.
	select	count(*) into map_count
	from	access_group_perm_map
	where	group_id = p_group_id
	and		perm_id = p_perm_id;

	-- We're going to grant access.
	if p_cmd=1 then
		if map_count=0 then
			insert into access_group_perm_map (group_id, perm_id) values (p_group_id, p_perm_id);
		end if;
	end if;

	if p_cmd=0 then
		if map_count!=0 then
			delete from access_group_perm_map where group_id = p_group_id and perm_id = p_perm_id;
		end if;
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating group members.
--
create or replace function sp_group_members_add(in p_group_id int, in p_user_id int, p_creator int)
RETURNS void AS $$
begin
	insert into access_group_user_map (group_id, user_id, creator, creation_date) 
		values (p_group_id, p_user_id, p_creator, now());
end;
$$ LANGUAGE 'plpgsql';

create or replace function sp_group_members_remove(in p_group_id int, in p_user_id int)
RETURNS void AS $$
begin
	delete from access_group_user_map where group_id=p_group_id and user_id=p_user_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating application configuration.
--
create or replace function sp_system_config_update(in p_config_key varchar(50), in p_config_value varchar(200))
RETURNS void AS $$
begin
	update system_config set config_value=p_config_value where config_key=p_config_key;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Hardware.
--
create or replace function sp_hardware_add(out o_hardware_id int, in p_hardware_name varchar(100), in p_hardware_number varchar(100), in p_hardware_description text, in p_manufacturer_company_id int, in p_vendor_company_id int, in p_hardware_type int, in p_hardware_status int, in p_hardware_owner int, in p_hardware_location int, in p_hardware_model_name varchar(50), in p_hardware_model_number varchar(50), in p_hardware_serial_number varchar(50), in p_hardware_cost double precision, in p_hardware_reset_last_service_date int, in p_hardware_purchase_date varchar, in p_hardware_warranty_expire_date varchar, in p_creator int)
RETURNS integer AS $$
	declare v_hardware_last_service_date timestamp(1);
begin

	if p_hardware_reset_last_service_date=1 then
		v_hardware_last_service_date=now();
	else 
		v_hardware_last_service_date=null;
	end if;

	insert into asset_hardware(hardware_id, hardware_name, hardware_number, hardware_description, manufacturer_company_id, vendor_company_id, hardware_type, hardware_status, hardware_owner, hardware_location, hardware_model_name, hardware_model_number, hardware_serial_number, hardware_cost, hardware_last_service_date, hardware_purchase_date, hardware_warranty_expire_date, creator, creation_date)
		values (nextval('seq_asset_hardware_id'), p_hardware_name, p_hardware_number, p_hardware_description, p_manufacturer_company_id, p_vendor_company_id, p_hardware_type, p_hardware_status, p_hardware_owner, p_hardware_location, p_hardware_model_name, p_hardware_model_number, p_hardware_serial_number, p_hardware_cost, v_hardware_last_service_date, to_timestamp(p_hardware_purchase_date, 'YYYY/MM/DD HH:MI'), to_timestamp(p_hardware_warranty_expire_date, 'YYYY/MM/DD HH:MI'), p_creator, now());

	select currval('seq_asset_hardware_id') into o_hardware_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating an existing Hardware.
--
create or replace function sp_hardware_update(in p_hardware_id int, in p_hardware_name varchar(100), in p_hardware_number varchar(100), in p_hardware_description text, in p_manufacturer_company_id int, in p_vendor_company_id int, in p_hardware_type int, in p_hardware_status int, in p_hardware_owner int, in p_hardware_location int, in p_hardware_model_name varchar(50), in p_hardware_model_number varchar(50), in p_hardware_serial_number varchar(50), in p_hardware_cost double precision, in p_hardware_reset_last_service_date int, in p_hardware_purchase_date varchar, in p_hardware_warranty_expire_date varchar, in p_modifier int)
RETURNS void AS $$
begin
	update asset_hardware set hardware_name = p_hardware_name, hardware_number = p_hardware_number, 
		hardware_description = p_hardware_description, manufacturer_company_id = p_manufacturer_company_id, vendor_company_id = p_vendor_company_id, hardware_type = p_hardware_type, hardware_status = p_hardware_status,
		hardware_owner = p_hardware_owner, hardware_location = p_hardware_location, hardware_model_name = p_hardware_model_name, 
		hardware_model_number = p_hardware_model_number, hardware_serial_number = p_hardware_serial_number, hardware_cost = p_hardware_cost,
		hardware_purchase_date = to_timestamp(p_hardware_purchase_date, 'YYYY/MM/DD HH:MI'), hardware_warranty_expire_date = to_timestamp(p_hardware_warranty_expire_date, 'YYYY/MM/DD HH:MI'),
		modifier = p_modifier, modification_date = now()
        where hardware_id =p_hardware_id;

	-- We need to reset last service date.
	if p_hardware_reset_last_service_date=1 then
		update asset_hardware set hardware_last_service_date=now() where hardware_id =p_hardware_id;
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting a hardware.
--
create or replace function sp_hardware_delete(in p_object_type_id int, in p_hardware_id int)
RETURNS void AS $$
begin
	-- Call a function to delete files
	perform sp_file_delete(p_object_type_id, p_hardware_id);

    delete from contract_hardware_map where hardware_id = p_hardware_id;
    delete from asset_map where hardware_id = p_hardware_id;
    delete from asset_hardware where hardware_id = p_hardware_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for assigning a Software license to a Hardware.
--
create or replace function sp_software_license_assign(out o_map_id int, in p_hardware_id int, in p_software_id int, in p_license_id int, in p_license_entitlement int)
RETURNS integer AS $$
begin
	insert into asset_map(map_id, hardware_id, software_id, license_id, license_entitlement) 
		values (nextval('seq_asset_map_id'), p_hardware_id, p_software_id, p_license_id, p_license_entitlement);

	select currval('seq_asset_map_id') into o_map_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Hardware File count.
--
create or replace function sp_hardware_count_file_update(in p_object_type_id int, in p_hardware_id int)
RETURNS void AS $$
begin
	update asset_hardware set count_file = (select count(file_map_id) from file_map where object_type_id=p_object_type_id and object_id = p_hardware_id)
		where hardware_id = p_hardware_id;
end;
$$ LANGUAGE 'plpgsql';	



--
-- This is for resetting Hardware assigned Software count.
--
create or replace function sp_hardware_count_software_update(in p_hardware_id int)
RETURNS void AS $$
begin
	update asset_hardware set count_software = (select count(software_id) from asset_map where hardware_id = p_hardware_id)
		where hardware_id = p_hardware_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding software.
--
create or replace function sp_software_add(out o_software_id int, in p_software_name varchar(100), in p_software_description text, in p_software_type int, in p_operating_system int, in p_quoted_retail_price varchar(50), in p_quoted_oem_price varchar(50), in p_manufacturer_company_id int, in p_vendor_company_id int, in p_creator int)
RETURNS integer AS $$
begin
	insert into asset_software(software_id, software_name, software_description, software_type, operating_system, quoted_retail_price, quoted_oem_price, manufacturer_company_id, vendor_company_id, creator, creation_date) 
		values (nextval('seq_asset_software_id'), p_software_name, p_software_description, p_software_type, p_operating_system, p_quoted_retail_price, p_quoted_oem_price, p_manufacturer_company_id, p_vendor_company_id, p_creator, now());

	select currval('seq_asset_software_id') into o_software_id;
end; 
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Software detail.
--
create or replace function sp_software_update(in p_software_id int, in p_software_name varchar(100), in p_software_description text, in p_software_type int, in p_operating_system int, in p_quoted_retail_price varchar(50), in p_quoted_oem_price varchar(50), in p_manufacturer_company_id int, in p_vendor_company_id int, in p_modifier int)
RETURNS void AS $$
begin
	update asset_software set software_name=p_software_name, software_description=p_software_description, 
		software_type=p_software_type, operating_system=p_operating_system, quoted_retail_price=p_quoted_retail_price, 
		quoted_oem_price=p_quoted_oem_price, manufacturer_company_id=p_manufacturer_company_id, vendor_company_id=p_vendor_company_id,
		modifier=p_modifier, modification_date=now()
		where software_id = p_software_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting software.
--
create or replace function sp_software_delete(in p_object_type_id int, in p_software_id int)
RETURNS void AS $$
	declare bookmark_record record;
	declare v_bookmar_id integer;
	declare hardware_record record;
	declare v_hardware_id integer;
begin

	-- Now let's work on the Bookmark cursor.
	FOR bookmark_record IN select distinct bookmark_id from bookmark_map where object_type_id=p_object_type_id and object_id = p_software_id
	
	loop
		v_bookmar_id := bookmark_record.bookmark_id; 
		delete from bookmark_map where bookmark_id=v_bookmar_id;
		delete from bookmark where bookmark_id=v_bookmar_id;
	end loop;

	-- Call a function to delete files
	perform sp_file_delete(p_object_type_id, p_software_id);

	-- Now let's work on the Hardware cursor.
	FOR hardware_record IN select distinct hardware_id from asset_map where software_id = p_software_id

	loop
		v_hardware_id := hardware_record.hardware_id; 
		delete from asset_map where hardware_id = v_hardware_id and software_id = p_software_id;
		perform sp_hardwareCountSoftwareUpdate(v_hardware_id);
	end loop;

	delete from asset_software_licenses where software_id = p_software_id;
    delete from asset_software where software_id = p_software_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding a Software license.
--
create or replace function sp_software_license_add(out o_license_id int, in p_software_id int, in p_license_key varchar(100), in p_license_note varchar(50), in p_license_entitlement int, in p_creator int)
RETURNS integer AS $$
begin
	insert into asset_software_licenses(license_id, software_id, license_key, license_note, license_entitlement, creator, creation_date) 
		values (nextval('seq_asset_software_license_id'), p_software_id, p_license_key, p_license_note, p_license_entitlement, p_creator, now());
	select currval('seq_asset_software_license_id') into o_license_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Software license detail.
--
create or replace function sp_software_license_update(in p_software_id int, in p_license_id int, in p_license_key varchar(100), in p_license_note varchar(50), in p_license_entitlement int, in p_modifier int)
RETURNS void AS $$
begin
	update asset_software_licenses set license_key=p_license_key, license_note = p_license_note, license_entitlement=p_license_entitlement,
		modifier=p_modifier, modification_date=now()
		where software_id=p_software_id and license_id=p_license_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting a license from a software.
--
create or replace function sp_software_license_delete(in p_software_id int, in p_license_id int)
RETURNS void AS $$
begin
    delete from asset_map where software_id = p_software_id and license_id = p_license_id;
	delete from asset_software_licenses where software_id = p_software_id and license_id = p_license_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Software License count.
--
create or replace function sp_software_count_license_update(in p_software_id int)
RETURNS void AS $$
begin
	update asset_software set count_license=(select count(license_id) from asset_software_licenses where software_id=p_software_id) where software_id=p_software_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Software Bookmark count.
--
create or replace function sp_software_count_bookmark_update(in p_object_type_id int, in p_software_id int)
RETURNS void AS $$
begin
	update asset_software set count_bookmark=(select count(bookmark_map_id) from bookmark_map where object_type_id=p_object_type_id and object_id = p_software_id)
		where software_id = p_software_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Software File count.
--
create or replace function sp_software_count_file_update(in p_object_type_id int, in p_software_id int)
RETURNS void AS $$
begin
	update asset_software set count_file=(select count(file_map_id) from file_map where object_type_id=p_object_type_id and object_id = p_software_id)
		where software_id = p_software_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting an association between hardware and software license.
--
create or replace function sp_asset_map_delete(in p_map_id int)
RETURNS void AS $$
begin
	delete from asset_map where map_id = p_map_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding contract.
--
create or replace function sp_contract_add(out o_contract_id int, in p_contract_name varchar(100), in p_contract_description text, in p_contract_type int, in p_contract_effective_date varchar, in p_contract_expiration_date varchar, in p_contract_renewal_date varchar, in p_contract_renewal_type int, in p_creator int)
RETURNS integer AS $$
begin
	insert into contract(contract_id, contract_name, contract_description, contract_type, contract_effective_date, contract_expiration_date, contract_renewal_date, contract_renewal_type, creator, creation_date) 
		values (nextval('seq_contract_id'), p_contract_name, p_contract_description, p_contract_type, to_timestamp(p_contract_effective_date, 'YYYY/MM/DD HH:MI'), to_timestamp(p_contract_expiration_date, 'YYYY/MM/DD HH:MI'), to_timestamp(p_contract_renewal_date, 'YYYY/MM/DD HH:MI'), p_contract_renewal_type, p_creator, now());

	select currval('seq_contract_id') into o_contract_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating contract.
--
create or replace function sp_contract_update(in p_contract_id int, in p_contract_name varchar(100), in p_contract_description text, in p_contract_type int, in p_contract_effective_date varchar, in p_contract_expiration_date varchar, in p_contract_renewal_date varchar, in p_contract_renewal_type int, in p_modifier int)
RETURNS void AS $$
begin
	update contract set contract_name=p_contract_name, contract_description=p_contract_description, contract_type=p_contract_type, contract_effective_date=to_timestamp(p_contract_effective_date, 'YYYY/MM/DD HH:MI'),
		contract_expiration_date=to_timestamp(p_contract_expiration_date, 'YYYY/MM/DD HH:MI'), contract_renewal_date=to_timestamp(p_contract_renewal_date, 'YYYY/MM/DD HH:MI'), contract_renewal_type=p_contract_renewal_type, modifier=p_modifier, modification_date=now()
		where contract_id=p_contract_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting contract.
--
create or replace function sp_contract_delete(in p_contract_id int)
RETURNS void AS $$
begin
    delete from contract_hardware_map where contract_id = p_contract_id;
	delete from contract where contract_id = p_contract_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding contract hardware.
--
create or replace function sp_contract_hardware_add(in p_contract_id int, in p_hardware_id int, in p_creator int)
RETURNS void AS $$
declare v_count int;
begin
	select count(contract_id) into v_count
	from contract_hardware_map
	where contract_id = p_contract_id
	and hardware_id = p_hardware_id;
	
	if (v_count = 0) then
		insert into contract_hardware_map (contract_id, hardware_id, creator, creation_date) 
			values (p_contract_id, p_hardware_id, p_creator, now());
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting contract hardware.
--
create or replace function sp_contract_hardware_delete(in p_contract_id int, in p_hardware_id int)
RETURNS void AS $$
begin
	delete from contract_hardware_map where contract_id = p_contract_id and hardware_id = p_hardware_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for authentication.
--
create or replace function sp_user_login(in p_session_key varchar(50), in p_user_id int)
RETURNS void AS $$
begin
	update user_session set session_key=p_session_key, last_logon=now(), last_visit=now() 
		where user_id = p_user_id;

	insert into user_login_history (user_id, login_date) values (p_user_id, now());
end;
$$ LANGUAGE 'plpgsql';

create or replace function sp_user_logout(in p_user_id int)
RETURNS void AS $$
begin
	update user_session set session_key =null, last_visit=now() 
		where user_id = p_user_id;
end;
$$ LANGUAGE 'plpgsql';


create or replace function sp_user_session_validate(out match_count int, in p_user_id int, in p_session_key varchar(50), in p_session_timeout int)
RETURNS integer AS $$
begin
	-- The purpose of validating is to see if the user_id and session_id 
	-- match our records. 
	select	count(user_id) into match_count
	from	user_session
	where	user_id = p_user_id
	and		session_key = p_session_key
	and     extract(epoch from (now() - last_visit)) < p_session_timeout;

	-- If the combination matches, we update the last_visit field.
    if match_count=1 then
	    update user_session set last_visit=now() where user_id = p_user_id;
    end if;
	
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding bookmark.
--
create or replace function sp_bookmark_add(out o_bookmark_id int, in p_bookmark_name varchar(100), in p_bookmark_path varchar(225), in p_bookmark_description text, in p_object_type_id int, in p_object_id int, in p_creator int)
RETURNS integer AS $$
begin
	-- Insert an entry into bookmark table
	insert into bookmark(bookmark_id, bookmark_name, bookmark_path, bookmark_description, creator, creation_date) 
		values (nextval('seq_bookmark_id'), p_bookmark_name, p_bookmark_path, p_bookmark_description, p_creator, now());

	select currval('seq_bookmark_id') into o_bookmark_id;

	-- Insert the corresponding entry in bookmark_map table.
	insert into bookmark_map(bookmark_map_id, bookmark_id, object_type_id, object_id, creator, creation_date) 
		values (nextval('seq_bookmark_map_id'), o_bookmark_id, p_object_type_id, p_object_id, p_creator, now());
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating bookmark.
--
create or replace function sp_bookmark_update(in p_bookmark_id int, in p_bookmark_name varchar(100), in p_bookmark_path varchar(225), in p_bookmark_description text, in p_object_type_id int, in p_object_id int, in p_modifier int)
RETURNS void AS $$
begin
	update bookmark set bookmark_name=p_bookmark_name, bookmark_path=p_bookmark_path, bookmark_description=p_bookmark_description, 
		modifier=p_modifier, modification_date=now()
		where bookmark_id=(select bookmark_id from bookmark_map where object_type_id=p_object_type_id and object_id=p_object_id and bookmark_id=p_bookmark_id);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting bookmark.
--
create or replace function sp_bookmark_delete(in p_object_type_id int, in p_object_id int, in p_bookmark_id int)
RETURNS void AS $$
	declare v_bookmark_id integer;
begin

	select bookmark_id into v_bookmark_id from bookmark_map where object_type_id=p_object_type_id and object_id=p_object_id and bookmark_id=p_bookmark_id;
	delete from bookmark_map where bookmark_id=v_bookmark_id;
	delete from bookmark where bookmark_id=v_bookmark_id;
end;
$$ LANGUAGE 'plpgsql';



--
-- This is for adding company.
--
create or replace function sp_company_add(out o_company_id int, in p_company_name varchar(100), in p_company_description text, in p_creator int)
RETURNS integer AS $$
begin
    insert into company (company_id, company_name, company_description, creator, creation_date) 
		values (nextval('seq_company_id'), p_company_name, p_company_description, p_creator, now());
    select currval('seq_company_id') into o_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding a company_note record.
--
create or replace function sp_company_note_add(out o_note_id int, in p_note_name varchar(100), in p_note_description text, in p_note_type int, in p_company_id int, in p_creator int)
RETURNS integer AS $$
begin
	insert into company_note(note_id, note_name, note_description, note_type, company_id, creator, creation_date) 
		values (nextval('seq_company_note_id'), p_note_name, p_note_description, p_note_type, p_company_id, p_creator, now());
	select currval('seq_company_note_id') into o_note_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding a company_tag record.
--
create or replace function sp_company_tag_add(out o_tag_id int, in p_company_id int, in p_tag_name varchar(50), in p_creator int)
RETURNS integer AS $$
declare v_tag_count int;
begin
	o_tag_id = 0;
	
	-- Given a tag_name, company_id, insert a record into company_tag table if not exist.
	select count(tag_id) into v_tag_count
	from company_tag
	where tag_name = p_tag_name;
	
	if (v_tag_count = 0) then
		insert into company_tag (tag_id, tag_name, creator, creation_date) 
			values (nextval('seq_company_tag_id'), p_tag_name, p_creator, now());
			
		select currval('seq_company_tag_id') into o_tag_id;
	end if;	
	
	if o_tag_id = 0 then
		-- This means the tag already exists, we'll do a select tag_id.
		select tag_id into o_tag_id from company_tag where tag_name=p_tag_name;
    end if;

	select count(company_id) into v_tag_count
	from company_tag_map
	where company_id = p_company_id
	and tag_id = o_tag_id;
	
	-- Now, we have a o_tag_id we can use.
	if (v_tag_count = 0) then
		insert into company_tag_map (company_id, tag_id, creator, creation_date) values 
			(p_company_id, o_tag_id, p_creator, now());
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for removing a company_tag_map record.
--
create or replace function sp_company_tag_delete(in p_company_id int, in p_tag_name varchar(50))
RETURNS void AS $$
begin
	delete from company_tag_map where company_id = p_company_id 
		and tag_id = (select tag_id from company_tag where tag_name = p_tag_name);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Company detail.
--
create or replace function sp_company_update(in p_company_id int, in p_company_name varchar(100), in p_company_description text, in p_modifier int)
RETURNS void AS $$
begin
	update company set company_name=p_company_name, company_description=p_company_description, 
		modifier=p_modifier, modification_date=now()
		where company_id=p_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Company contact count.
--
create or replace function sp_company_count_contact_update(in p_company_id int, in p_company_contact_type int)
RETURNS void AS $$
begin
	if p_company_contact_type = '10' then 
		update company set count_main_contact=(select count(contact_id) from contact where company_id=p_company_id and company_contact_type=p_company_contact_type)
		where company_id=p_company_id;
	else 
		update company set count_employee_contact=(select count(contact_id) from contact where company_id = p_company_id and company_contact_type=p_company_contact_type)
		where company_id=p_company_id;	
	end if;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Company file count.
--
create or replace function sp_company_count_file_update(in p_object_type_id int, in p_company_id int)
RETURNS void AS $$
begin
	update company set count_file = (select count(file_map_id) from file_map where object_type_id = p_object_type_id and object_id = p_company_id)
		where company_id = p_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Company Bookmark count.
--
create or replace function sp_company_count_bookmark_update(in p_object_type_id int, in p_company_id int)
RETURNS void AS $$
begin
	update company set count_bookmark =(select count(bookmark_map_id) from bookmark_map where object_type_id = p_object_type_id and object_id = p_company_id)
	where company_id = p_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for resetting Company Note count.
--
create or replace function sp_company_count_note_update(in p_company_id int)
RETURNS void AS $$
begin
	update company set count_note =(select count(note_id) from company_note where company_id = p_company_id) 
	where company_id = p_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Contact.
--
create or replace function sp_contact_add(out o_contact_id int, in p_company_contact_type int, in p_contact_first_name varchar(50), in p_contact_last_name varchar(50), in p_contact_title varchar(100), in p_company_id int, in p_contact_phone_home varchar(50), in p_contact_phone_mobile varchar(50), in p_contact_phone_work varchar(50), in p_contact_fax varchar(50), in p_contact_email_primary varchar(50), in p_contact_email_secondary varchar(50), in p_messenger_1_type int, in p_messenger_1_id varchar(50), in p_messenger_2_type int, in p_messenger_2_id varchar(50), in p_contact_homepage_url varchar(50), in p_contact_description text, in p_address_street_primary varchar(50), in p_address_city_primary varchar(50), in p_address_state_primary varchar(50), in p_address_zipcode_primary varchar(50), in p_address_country_primary varchar(50), in p_creator int)
RETURNS integer AS $$
begin
    insert into contact (contact_id, contact_first_name, contact_last_name, contact_title, company_id, company_contact_type, contact_phone_home, contact_phone_mobile, contact_phone_work, contact_fax, contact_email_primary, contact_email_secondary, messenger_1_type, messenger_1_id, messenger_2_type, messenger_2_id, contact_homepage_url, contact_description, address_street_primary, address_city_primary, address_state_primary, address_zipcode_primary, address_country_primary, creator, creation_date) 
		values (nextval('seq_contact_id'), p_contact_first_name, p_contact_last_name, p_contact_title, p_company_id, p_company_contact_type, p_contact_phone_home, p_contact_phone_mobile, p_contact_phone_work, p_contact_fax, p_contact_email_primary, p_contact_email_secondary, p_messenger_1_type, p_messenger_1_id, p_messenger_2_type, p_messenger_2_id, p_contact_homepage_url, p_contact_description, p_address_street_primary, p_address_city_primary, p_address_state_primary, p_address_zipcode_primary, p_address_country_primary, p_creator, now());

	select currval('seq_contact_id') into o_contact_id;

	-- Update contact count.
	perform sp_company_count_contact_update(p_company_id, p_company_contact_type);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating a Contact.
--
create or replace function sp_contact_update(in p_contact_id int, in p_company_id int, in p_company_contact_type int, in p_contact_first_name varchar(50), in p_contact_last_name varchar(50), in p_contact_title varchar(100), in p_contact_phone_home varchar(50), in p_contact_phone_mobile varchar(50), in p_contact_phone_work varchar(50), in p_contact_fax varchar(50), in p_contact_email_primary varchar(50), in p_contact_email_secondary varchar(50), in p_messenger_1_type int, in p_messenger_1_id varchar(50), in p_messenger_2_type int, in p_messenger_2_id varchar(50), in p_contact_homepage_url varchar(50), in p_contact_description text, in p_address_street_primary varchar(50), in p_address_city_primary varchar(50), in p_address_state_primary varchar(50), in p_address_zipcode_primary varchar(50), in p_address_country_primary varchar(50), in p_modifier int)
RETURNS void AS $$
	declare v_company_id integer;
begin

	-- Need to do the select into first.
	select company_id into v_company_id from contact where contact_id = p_contact_id;

	update contact set contact_first_name=p_contact_first_name, contact_last_name=p_contact_last_name, contact_title=p_contact_title, company_id=p_company_id, contact_phone_home=p_contact_phone_home, contact_phone_mobile=p_contact_phone_mobile, contact_phone_work=p_contact_phone_work,
		contact_fax=p_contact_fax, contact_email_primary=p_contact_email_primary, contact_email_secondary=p_contact_email_secondary, 
		messenger_1_type = p_messenger_1_type, messenger_1_id = p_messenger_1_id, messenger_2_type = p_messenger_2_type, messenger_2_id = p_messenger_2_id, contact_homepage_url = p_contact_homepage_url, contact_description=p_contact_description,
        address_street_primary=p_address_street_primary, address_city_primary=p_address_city_primary, address_state_primary=p_address_state_primary, address_zipcode_primary=p_address_zipcode_primary, address_country_primary=p_address_country_primary,
		modifier=p_modifier, modification_date=now()
        where contact_id=p_contact_id
		and user_id is null;

	if v_company_id is not null then
		-- Update contact count for old company_id
		perform sp_company_count_contact_update(v_company_id, p_company_contact_type);
	end if;

	-- Update contact count for new company_id
	perform sp_company_count_contact_update(p_company_id, p_company_contact_type);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting a Contact.
--
create or replace function sp_contact_delete(in p_contact_id int, in p_company_id int, in p_company_contact_type int)
RETURNS void AS $$
begin
    delete from contact where contact_id = p_contact_id;
	
	-- Update contact count.
	perform sp_company_count_contact_update(p_company_id, p_company_contact_type);
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting company.
--
create or replace function sp_company_delete(in p_object_type_id int, in p_company_id int)
RETURNS void AS $$
	-- We'll need to delete bookmarks, contacts, tags, and company record.
	declare bookmark_record record;
	declare v_bookmark_id integer;
begin

	FOR bookmark_record IN select distinct bookmark_id from bookmark_map where object_type_id = p_object_type_id and object_id = p_company_id
	
	LOOP 	
		v_bookmark_id := bookmark_record.bookmark_id; 
		delete from bookmark_map where bookmark_id = v_bookmark_id;
		delete from bookmark where bookmark_id = v_bookmark_id;
	end loop;
	
	-- Call a function to delete files
	perform sp_file_delete(p_object_type_id, p_company_id);

	-- Update company_id to null or foreign key constraint would fail.
	update contact set company_id = null where company_id = p_company_id and user_id is not null;
    delete from contact where company_id = p_company_id;

	delete from company_tag_map where company_id = p_company_id;
	delete from company_note where company_id = p_company_id;

	delete from company where company_id = p_company_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding file.
--
create or replace function sp_file_add(out o_file_id int, in p_file_name varchar(100), in p_creator int)
RETURNS integer AS $$
begin
	-- Insert an entry into file table
	insert into file(file_id, file_name, creator, creation_date) 
		values (nextval('seq_file_id'), p_file_name, p_creator, now());

	select currval('seq_file_id') into o_file_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating file.
--
create or replace function sp_file_add_update(in p_file_id int, in p_file_name varchar(100), in p_file_friendly_name varchar(100), in p_file_description text, in p_file_mime_type varchar(100), in p_file_byte_size double precision, in p_file_uploaded_file_name varchar(100), in p_object_type_id int, in p_object_id int, p_creator int)
RETURNS void AS $$
begin
	update file set file_name=p_file_name, file_friendly_name=p_file_friendly_name, file_description=p_file_description, file_mime_type=p_file_mime_type, file_byte_size=p_file_byte_size, file_uploaded_file_name=p_file_uploaded_file_name
		where file_id=p_file_id;

	-- Insert the corresponding entry in file_map table.
	insert into file_map(file_map_id, file_id, object_type_id, object_id, creator, creation_date) 
		values (nextval('seq_file_map_id'), p_file_id, p_object_type_id, p_object_id, p_creator, now());
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting a File.
--
create or replace function sp_file_delete(in p_object_type_id int, in p_object_id int, in p_file_id int)
RETURNS void AS $$
	declare v_file_id integer;
begin
	select file_id into v_file_id from file_map where object_type_id = p_object_type_id and object_id = p_object_id and file_id = p_file_id;
	delete from file_map where file_id = v_file_id;
	delete from file where file_id = v_file_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting a dummy File, probably created during failed file upload.
--
create or replace function sp_file_delete_dummy(in p_file_id int)
RETURNS void AS $$
begin
    delete from file where file_id = p_file_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding a new Issue.
-- 
create or replace function sp_issue_add(out o_issue_id int, in p_issue_name varchar(100), in p_issue_description text, in p_url text, in p_type int, in p_status int, in p_priority int, in p_resolution int, in p_assignee int, in p_issue_due_date varchar, in p_creator_ip varchar(15), p_creator int)
RETURNS integer AS $$
begin
	insert into issue (issue_id, issue_name, issue_description, issue_url, issue_type, issue_status, issue_priority, issue_resolution, issue_assignee, issue_due_date, creator_ip, creator, creation_date)
		values (nextval('seq_issue_id'), p_issue_name, p_issue_description, p_url, p_type, p_status, p_priority, p_resolution, p_assignee, to_timestamp(p_issue_due_date, 'YYYY/MM/DD HH:MI'), p_creator_ip, p_creator, now());

	select currval('seq_issue_id') into o_issue_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating an Issue.
--
create or replace function sp_issue_update(in p_issue_id int, in p_issue_name varchar(100), in p_issue_description text, in p_issue_type int, in p_issue_status int, in p_issue_priority int, in p_issue_resolution int, in p_issue_assignee int, in p_issue_due_date varchar, in p_user_id int)
RETURNS void AS $$
	declare v_now timestamp(1);
	declare v_issue_name varchar(100);
	declare v_issue_type integer;
    declare v_issue_status integer;
    declare v_issue_priority integer;
    declare v_issue_resolution integer;
    declare v_issue_assignee integer;
begin

	select now() into v_now;

	-- Query the existing Issue for comparison.
	select	issue_name, issue_type, issue_status, issue_priority, issue_resolution, issue_assignee 
	into	v_issue_name, v_issue_type, v_issue_status, v_issue_priority, v_issue_resolution, v_issue_assignee 
	from	issue
	where	issue_id = p_issue_id;

	-- Update the corresponding Issue.
	update issue set issue_name=p_issue_name, issue_type = p_issue_type, issue_status = p_issue_status, issue_priority = p_issue_priority,
		issue_resolution = p_issue_resolution, issue_assignee = p_issue_assignee, issue_due_date = to_timestamp(p_issue_due_date, 'YYYY/MM/DD HH:MI'), modifier = p_user_id, modification_date= v_now
		where issue_id = p_issue_id;
	
	-- Always insert a new record for issue_description.
	insert into issue_comment (issue_comment_id, issue_id, issue_comment_description) values (nextval('seq_issue_comment_id'), p_issue_id, p_issue_description);
	insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_comment_id, creator, creation_date) values 
		(nextval('seq_issue_change_id'), p_issue_id, 'comment', currval('seq_issue_comment_id'), p_user_id, v_now);

	-- Check changes in issue_name.
	if v_issue_name != p_issue_name then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_varchar_old, issue_change_varchar_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'subject', v_issue_name, p_issue_name, p_user_id, v_now);
	end if;

	-- Check changes in issue_type.
	if v_issue_type != p_issue_type then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_int_old, issue_change_int_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'type', v_issue_type, p_issue_type, p_user_id, v_now);
	end if;

	-- Check changes in issue_status.
	if v_issue_status != p_issue_status then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_int_old, issue_change_int_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'status', v_issue_status, p_issue_status, p_user_id, v_now);
	end if;

	-- Check changes in issue_priority.
	if v_issue_priority != p_issue_priority then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_int_old, issue_change_int_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'priority', v_issue_priority, p_issue_priority, p_user_id, v_now);
	end if;

	-- Check changes in issue_resolution.
	if (v_issue_resolution is null and p_issue_resolution is not null) or (v_issue_resolution != p_issue_resolution) then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_int_old, issue_change_int_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'resolution', v_issue_resolution, p_issue_resolution, p_user_id, v_now);
	end if;

	-- Check changes in p_issue_assignee.
	if (v_issue_assignee is null and p_issue_assignee is not null) or (v_issue_assignee != p_issue_assignee) then
		insert into issue_change (issue_change_id, issue_id, issue_change_field, issue_change_int_old, issue_change_int_new, creator, creation_date) values 
			(nextval('seq_issue_change_id'), p_issue_id, 'assignee', v_issue_assignee, p_issue_assignee, p_user_id, v_now);
	end if;

	-- Last but now least, clean up issue_subscription table.
	delete from issue_subscription where issue_id = p_issue_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Issue subscription table with new users.
--
create or replace function sp_issue_subscribers_update(in p_issue_id int, in p_user_id int, p_modifier int)
RETURNS void AS $$
begin
	insert into issue_subscription (issue_id, user_id, modifier, modification_date) 
		values (p_issue_id, p_user_id, p_modifier, now());
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Issue File.
--
create or replace function sp_issue_file_add(in p_issue_id int, in p_file_id int, in p_user_id int)
RETURNS void AS $$
begin	
	insert into issue_change (issue_change_id, issue_id, issue_change_field, file_id, creator, creation_date) values 
		(nextval('seq_issue_change_id'), p_issue_id, 'file', p_file_id, p_user_id, now());
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Blog Post.
--
create or replace function sp_blog_post_add(out o_post_id int, in p_post_name varchar(100), in p_post_description text, in p_post_type int, in p_post_ip varchar(100), in p_post_allow_comment int, in p_category_id int, in p_creator int)
RETURNS integer AS $$
begin
	insert into blog_post (post_id, post_name, post_description, post_type, post_ip, post_allow_comment, category_id, creator, creation_date)
		values (nextval('seq_blog_post_id'), p_post_name, p_post_description, p_post_type, p_post_ip, p_post_allow_comment, p_category_id, p_creator, now());
	select currval('seq_blog_post_id') into o_post_id;

	update blog_post_category set count_post = (select count(post_id) from blog_post where category_id = p_category_id)
		where category_id = p_category_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Blog Post Category.
--
create or replace function sp_blog_post_category_add(out o_category_id int, in p_category_name varchar(100), in p_category_description text, in p_creator int)
RETURNS integer AS $$
begin
	insert into blog_post_category (category_id, category_name, category_description, creator, creation_date)
		values (nextval('seq_blog_post_category_id'), p_category_name, p_category_description, p_creator, now());
	select currval('seq_blog_post_category_id') into o_category_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Blog Post Category.
--
create or replace function sp_blog_post_category_update(in p_category_id int, in p_category_name varchar(100), in p_category_description text, in p_modifier int)
RETURNS void AS $$
begin
	update blog_post_category 
	set category_name = p_category_name, 
		category_description = p_category_description, 
		modifier = p_modifier,
		modification_date = now()
	where category_id = p_category_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Blog Post Comment.
--
create or replace function sp_blog_post_comment_add(out o_comment_id int, in p_comment_description text, p_comment_ip varchar(100), p_post_id int, in p_creator int)
RETURNS integer AS $$
begin
	insert into blog_post_comment (comment_id, comment_description, comment_ip, post_id, creator, creation_date)
		values (nextval('seq_blog_post_comment_id'), p_comment_description, p_comment_ip, p_post_id, p_creator, now());

	update blog_post set count_comment = (select count(comment_id) from blog_post_comment where post_id = p_post_id) where post_id = p_post_id;
	
	select currval('seq_blog_post_comment_id') into o_comment_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding Portal Site.
--
create or replace function sp_site_add(out o_site_id int, in p_site_name varchar(100), in p_site_path varchar(225), in p_site_description text, in p_site_placement int, in p_site_support_iframe int, in p_creator int)
RETURNS integer AS $$
begin
	insert into portal_site (site_id, site_name, site_path, site_description, site_placement, site_support_iframe, creator, creation_date)
		values (nextval('seq_portal_site_id'), p_site_name, p_site_path, p_site_description, p_site_placement, p_site_support_iframe, p_creator, now());
		
	select currval('seq_portal_site_id') into o_site_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating Portal Site.
--
create or replace function sp_site_update(in p_site_id int, in p_site_name varchar(100), in p_site_path varchar(225), in p_site_description text, in p_site_placement int, in p_site_support_iframe int, in p_modifier int)
RETURNS void AS $$
begin
	update portal_site set site_name = p_site_name, site_path = p_site_path, site_description = p_site_description, site_placement = p_site_placement, site_support_iframe = p_site_support_iframe, modifier = p_modifier, modification_date=now()
	where site_id = p_site_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting Portal Site.
--
create or replace function sp_site_delete(in p_site_id int)
RETURNS void AS $$
begin
	delete from portal_site where site_id = p_site_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding RSS feed.
--
create or replace function sp_rss_feed_add(out o_feed_id int, in p_feed_url text, in p_feed_name varchar(100), in p_feed_item_count int, in p_feed_cache text, in p_creator int)
RETURNS integer AS $$
begin
	insert into rss_feed (feed_id, feed_url, feed_name, feed_item_count, feed_cache, creator, creation_date)
		values (nextval('seq_rss_feed_id'), p_feed_url, p_feed_name, p_feed_item_count, p_feed_cache, p_creator, now());
	
	select currval('seq_rss_feed_id') into o_feed_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for updating RSS feed.
--
create or replace function sp_rss_feed_update(in p_feed_id int, in p_feed_url text, in p_feed_name varchar(100), in p_modifier int)
RETURNS void AS $$
begin
	update rss_feed set feed_url = p_feed_url, feed_name = p_feed_name, feed_item_count = 0, feed_cache = '', modifier = p_modifier, modification_date=now()
	where feed_id = p_feed_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for adding RSS feed cache (xml).
--
create or replace function sp_rss_feed_cache_update(in p_feed_id int, in p_feed_item_count int, in p_feed_cache text)
RETURNS void AS $$
begin
	update rss_feed set feed_item_count = p_feed_item_count, feed_cache = p_feed_cache, feed_cache_date=now()
	where feed_id = p_feed_id;
end;
$$ LANGUAGE 'plpgsql';

--
-- This is for deleting RSS feed.
--
create or replace function sp_rss_feed_delete(in p_feed_id int)
RETURNS void AS $$
begin
	delete from rss_feed where feed_id = p_feed_id;
end;
$$ LANGUAGE 'plpgsql';








