--
-- Upgrading to 2.6.4
--
update system_config set config_value = '2.6.4' where config_key = 'schema.version';

drop view if exists attribute_view;
drop view if exists blog_post_category_view;
drop view if exists portal_site_view;

DROP FUNCTION if exists sp_blog_post_category_update(p_category_id integer, p_category_name character varying, p_category_description text, p_modifier integer);
DROP FUNCTION if exists sp_blog_post_category_add(OUT o_category_id integer, IN p_category_name character varying, IN p_category_description text, IN p_creator integer);
DROP FUNCTION if exists sp_site_update(p_site_id integer, p_site_name character varying, p_site_path character varying, p_site_description text, p_site_placement integer, p_site_support_iframe integer, p_modifier integer);
DROP FUNCTION if exists sp_site_add(OUT o_site_id integer, IN p_site_name character varying, IN p_site_path character varying, IN p_site_description text, IN p_site_placement integer, IN p_site_support_iframe integer, IN p_creator integer);

insert into system_object (object_type_id, object_key) values (10, 'company_main_contact');
insert into system_object (object_type_id, object_key) values (11, 'company_emp_contact');
insert into system_object (object_type_id, object_key) values (12, 'blog_post');
insert into system_object (object_type_id, object_key) values (13, 'portal_site');

-- This column has never been used
alter table attribute drop column "type";

-- Renaming constraint
ALTER TABLE issue_comment drop CONSTRAINT issue_comment_issue_id_fk;
ALTER TABLE issue_comment ADD CONSTRAINT fk_issue_comment_issue_id FOREIGN KEY (issue_id) REFERENCES issue(issue_id);

alter table blog_post_category rename to category;

alter table category add column object_type_id integer;
update category set object_type_id=12;
alter table category alter column object_type_id set NOT NULL;
alter table category add CONSTRAINT fk_category_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object (object_type_id);

INSERT INTO category (category_id, category_name, category_description, object_type_id, count_post, creator, creation_date, modifier, modification_date) 
VALUES (nextval('seq_blog_post_category_id'), 'Uncategorized', '', 13, 0, 1, now(), NULL, NULL);

alter table portal_site add column category_id integer;
update portal_site set category_id=currval('seq_blog_post_category_id');
alter table portal_site alter column category_id set NOT NULL;

ALTER TABLE portal_site ADD CONSTRAINT fk_portal_site_category_id FOREIGN KEY (category_id) REFERENCES category(category_id);

insert into access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (25, 'portal_admin', '', 1, 43);

insert into access_page (page_id, page_name, page_description) values (211, '/portal/site-category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 211);
insert into access_page (page_id, page_name, page_description) values (212, '/portal/site-category-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 212);
insert into access_page (page_id, page_name, page_description) values (213, '/portal/site-category-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 213);
insert into access_page (page_id, page_name, page_description) values (214, '/portal/site-category-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 214);
insert into access_page (page_id, page_name, page_description) values (215, '/portal/site-category-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 215);

update access_perm_page_map set perm_id = 25 where page_id in (127, 120, 122, 121, 126, 125, 124, 123);
update access_page set page_name = '/portal/site-list-index.dll' where page_id = 132;
update access_page set page_name = replace(page_name, 'admin/portal-', 'portal/') where page_id in (127, 120, 122, 121, 126, 125, 124, 123);

update system_config set config_value = 'en_US,es_ES,it_IT,sr,zh_CN' where config_key='locale.options';

