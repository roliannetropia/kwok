--
-- Upgrading to 2.6.6
--
update system_config set config_value = '2.6.6' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

insert into attribute (attribute_id, object_type_id, attribute_key, is_optional, is_editable, is_custom_attr) values (-17, 2, 'hardware_component_type', 1, 1, 0);

insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Hard Disk');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'CD/DVD Drive');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Network Card');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Memory');

-- list, add, add-2, edit, edit-2, delete-2
insert into access_page (page_id, page_name, page_description) values (225, '/IT/hardware-comp.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (6, 225);

insert into access_page (page_id, page_name, page_description) values (226, '/IT/hardware-comp-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 226);

insert into access_page (page_id, page_name, page_description) values (227, '/IT/hardware-comp-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 227);

insert into access_page (page_id, page_name, page_description) values (228, '/IT/hardware-comp-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 228);

insert into access_page (page_id, page_name, page_description) values (229, '/IT/hardware-comp-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 229);

insert into access_page (page_id, page_name, page_description) values (230, '/IT/hardware-comp-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 230);

CREATE TABLE asset_hardware_component (
  comp_id integer NOT NULL,
  comp_description text,
  hardware_id integer NOT NULL,
  hardware_component_type integer,
  creator integer,
  creation_date timestamp(1) without time zone,
  modifier integer,
  modification_date timestamp(1) without time zone,
  CONSTRAINT pk_asset_hardware_comp_id PRIMARY KEY (comp_id),
  CONSTRAINT fk_asset_hardware_comp_hardware_id FOREIGN KEY (hardware_id)
      REFERENCES asset_hardware (hardware_id) 
);

CREATE SEQUENCE seq_asset_hardware_comp_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

-- Remove hardware index page from software read permission.
delete from access_perm_page_map where perm_id=8 and page_id=17;

alter table asset_hardware add count_component integer DEFAULT 0;

drop view if exists asset_hardware_view; 

-- Add date format for UK users
update system_config set config_value='M/d/yyyy,MM/dd/yyyy,d/M/yyyy,dd/MM/yyyy,yyyy-MM-dd' where config_key='datetime.shortDateFormat.options';

-- Re-purpose contract_hardware_map table for object linking
CREATE TABLE object_map (
  object_id integer NOT NULL,
  object_type_id integer NOT NULL,
  linked_object_id integer NOT NULL,
  linked_object_type_id integer NOT NULL,
  creator integer,
  creation_date timestamp(1) without time zone,
  CONSTRAINT fk_object_map_object_type_id FOREIGN KEY (object_type_id)
      REFERENCES system_object (object_type_id),
  CONSTRAINT fk_object_map_linked_object_type_id FOREIGN KEY (linked_object_type_id)
      REFERENCES system_object (object_type_id),
  CONSTRAINT uk_object_map UNIQUE (object_id, object_type_id, linked_object_id, linked_object_type_id)
);

insert into object_map (object_id, object_type_id, linked_object_id, linked_object_type_id, creator, creation_date) select contract_id, 9, hardware_id, 2, creator, creation_date from contract_hardware_map;

drop table contract_hardware_map;

DROP FUNCTION if exists sp_contract_hardware_delete(p_contract_id integer, p_hardware_id integer);
DROP FUNCTION if exists sp_contract_hardware_add(in p_contract_id int, in p_hardware_id int, in p_creator int);
DROP FUNCTION if exists sp_contract_delete(p_contract_id integer);
DROP FUNCTION if exists sp_attribute_value_delete(p_object_type_id int, p_object_id int);

insert into access_page (page_id, page_name, page_description) values (231, '/IT/hardware-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (6, 231);

insert into access_page (page_id, page_name, page_description) values (232, '/IT/hardware-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 232);

insert into access_page (page_id, page_name, page_description) values (233, '/IT/hardware-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 233);

insert into access_page (page_id, page_name, page_description) values (234, '/IT/hardware-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 234);

-- Software Issues pages
insert into access_page (page_id, page_name, page_description) values (235, '/IT/software-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (8, 235);

insert into access_page (page_id, page_name, page_description) values (236, '/IT/software-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 236);

insert into access_page (page_id, page_name, page_description) values (237, '/IT/software-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 237);

insert into access_page (page_id, page_name, page_description) values (238, '/IT/software-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 238);

-- For cleaning up orphan data, contract deletion wasn't deleting file_map records before
delete from file_map where object_type_id=9 and object_id not in (select contract_id from contract);
delete from file where file_id not in (select file_id from file_map);

-- Company Issues pages
insert into access_page (page_id, page_name, page_description) values (239, '/contact-mgmt/company-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (10, 239);

insert into access_page (page_id, page_name, page_description) values (240, '/contact-mgmt/company-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 240);

insert into access_page (page_id, page_name, page_description) values (241, '/contact-mgmt/company-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 241);

insert into access_page (page_id, page_name, page_description) values (242, '/contact-mgmt/company-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 242);

-- drop /portal/rss-feed-list-description
delete from access_perm_page_map where page_id=188;
delete from access_page where page_id=188;

-- Add new Hungarian localization
update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,sr_YU,zh_CN' where config_key='locale.options';
update system_config set config_value = 'sr_YU' where config_key='locale' and config_value='sr';
