--
-- Upgrading to 2.6.7
--
update system_config set config_value = '2.6.7' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

-- Added new Dutch locale
update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,nl_NL,sr_YU,zh_CN' where config_key='locale.options';

CREATE TABLE kb_article (
  article_id bigint NOT NULL,
  article_name character varying(100) NOT NULL,
  article_text text,
  category_id integer NOT NULL,
  creator integer,
  creation_date timestamp(1) without time zone,
  modifier integer,
  modification_date timestamp(1) without time zone,
  CONSTRAINT pk_kb_article_id PRIMARY KEY (article_id),
  CONSTRAINT fk_kb_article_category_id FOREIGN KEY (category_id) REFERENCES category (category_id) 
);

insert into system_object (object_type_id, object_key) values (14, 'kb_article');

-- Bump up some order numbers
update access_permission set order_num = order_num+100 where order_num>40;

-- New permissions for KB module
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (26, 'kb_read', 1, 80);
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (27, 'kb_write', 1, 81);
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (28, 'kb_admin', 1, 82);

insert into access_page (page_id, page_name, page_description) values (243, '/kb/index.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 243);
insert into access_page (page_id, page_name, page_description) values (244, '/kb/article-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 244);
insert into access_page (page_id, page_name, page_description) values (245, '/kb/article-detail.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 245);

insert into access_page (page_id, page_name, page_description) values (246, '/kb/article-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 246);
insert into access_page (page_id, page_name, page_description) values (247, '/kb/article-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 247);
insert into access_page (page_id, page_name, page_description) values (248, '/kb/article-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 248);
insert into access_page (page_id, page_name, page_description) values (249, '/kb/article-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 249);

insert into access_page (page_id, page_name, page_description) values (250, '/kb/category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 250);
insert into access_page (page_id, page_name, page_description) values (251, '/kb/category-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 251);
insert into access_page (page_id, page_name, page_description) values (252, '/kb/category-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 252);
insert into access_page (page_id, page_name, page_description) values (253, '/kb/category-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 253);
insert into access_page (page_id, page_name, page_description) values (254, '/kb/category-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 254);

insert into access_page (page_id, page_name, page_description) values (255, '/kb/article-delete.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 255);
insert into access_page (page_id, page_name, page_description) values (256, '/kb/article-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 256);

update system_config set config_value='13,1,2,4,14,5,3,6,8,7' where config_key='template.moduleTabs';

insert into category (category_id, category_name, category_description, count_post, creator, creation_date, object_type_id)
	values (nextval('seq_blog_post_category_id'), 'Uncategorized', '', 0, 1, now(), 14);

CREATE TABLE kb_article_archive (
  article_id bigint NOT NULL,
  article_name character varying(100) NOT NULL,
  article_text text,
  category_id integer NOT NULL,
  archiver integer,
  archive_date timestamp(1) without time zone,
  CONSTRAINT fk_kb_article_archive_article_id FOREIGN KEY (article_id) REFERENCES kb_article (article_id),
  CONSTRAINT fk_kb_article_archive_category_id FOREIGN KEY (category_id) REFERENCES category (category_id) 
);

CREATE SEQUENCE seq_kb_article_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;
