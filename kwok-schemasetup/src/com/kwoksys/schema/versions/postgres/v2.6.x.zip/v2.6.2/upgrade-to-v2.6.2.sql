--
-- Upgrading to 2.6.2
--
update system_config set config_value = '2.6.2' where config_key = 'schema.version';

DROP FUNCTION if exists sp_software_license_delete(p_software_id integer, p_license_id integer);

insert into access_page (page_id, page_name, page_description) values (206, '/IT/contract-hardware.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (12, 206);

insert into access_page (page_id, page_name, page_description) values (207, '/IT/contract-hardware-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 207);

insert into access_page (page_id, page_name, page_description) values (208, '/IT/contract-hardware-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 208);

insert into access_page (page_id, page_name, page_description) values (209, '/IT/contract-hardware-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 209);

CREATE TABLE contract_hardware_map (
    contract_id integer NOT NULL,
    hardware_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);

ALTER TABLE ONLY contract_hardware_map
    ADD CONSTRAINT fk_contract_id FOREIGN KEY (contract_id) REFERENCES contract(contract_id);

ALTER TABLE ONLY contract_hardware_map
    ADD CONSTRAINT fk_contract_hardware_id FOREIGN KEY (hardware_id) REFERENCES asset_hardware(hardware_id);

alter table contract_hardware_map add CONSTRAINT uk_contract_hardware_id unique (contract_id, hardware_id);
alter table user_session add CONSTRAINT uk_user_session_user_id unique (user_id);
alter table access_group_perm_map add CONSTRAINT uk_group_perm_id unique (group_id, perm_id);
alter table access_group_user_map add CONSTRAINT uk_group_user_id unique (group_id, user_id);
alter table access_perm_page_map add CONSTRAINT uk_perm_page_id unique (perm_id, page_id);
alter table access_user_perm_map add CONSTRAINT uk_user_perm_id unique (user_id, perm_id);

update access_page set page_name = '/portal/blog-category-add.dll' where page_name = '/portal/blog-post-category-add.dll';
update access_page set page_name = '/portal/blog-category-add-2.dll' where page_name = '/portal/blog-post-category-add-2.dll';
update access_page set page_name = '/portal/blog-category-edit.dll' where page_name = '/portal/blog-post-category-edit.dll';
update access_page set page_name = '/portal/blog-category-edit-2.dll' where page_name = '/portal/blog-post-category-edit-2.dll';

insert into access_page (page_id, page_name, page_description) values (210, '/portal/blog-category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (19, 210);
