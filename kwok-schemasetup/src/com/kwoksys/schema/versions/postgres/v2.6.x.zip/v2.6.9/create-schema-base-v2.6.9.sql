--
-- PostgreSQL database dump
--

SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1511 (class 1259 OID 48475)
-- Dependencies: 4
-- Name: access_group; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_group (
    group_id integer NOT NULL,
    group_name character varying(100) NOT NULL,
    group_description text,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1513 (class 1259 OID 48494)
-- Dependencies: 4
-- Name: access_group_perm_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_group_perm_map (
    group_id integer NOT NULL,
    perm_id integer NOT NULL
);


--
-- TOC entry 1512 (class 1259 OID 48482)
-- Dependencies: 4
-- Name: access_group_user_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_group_user_map (
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1433 (class 1259 OID 47877)
-- Dependencies: 4
-- Name: access_page; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_page (
    page_id integer NOT NULL,
    page_name character varying(100) NOT NULL,
    page_description text
);


--
-- TOC entry 1510 (class 1259 OID 48453)
-- Dependencies: 4
-- Name: access_perm_page_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_perm_page_map (
    perm_id integer NOT NULL,
    page_id integer NOT NULL
);


--
-- TOC entry 1509 (class 1259 OID 48445)
-- Dependencies: 1910 4
-- Name: access_permission; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_permission (
    perm_id integer NOT NULL,
    perm_name character varying(100) NOT NULL,
    perm_description text,
    perm_is_enabled integer,
    order_num integer DEFAULT 0
);


--
-- TOC entry 1461 (class 1259 OID 48219)
-- Dependencies: 1905 1906 1907 1908 4
-- Name: access_user; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_user (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    "password" character varying(32) NOT NULL,
    display_name character varying(50) NOT NULL,
    status character(1) DEFAULT '1'::bpchar NOT NULL,
    first_name character varying(50) DEFAULT ''::character varying,
    last_name character varying(50) DEFAULT ''::character varying,
    email character varying(255) DEFAULT ''::character varying,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1434 (class 1259 OID 47900)
-- Dependencies: 4
-- Name: access_user_perm_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE access_user_perm_map (
    user_id integer NOT NULL,
    perm_id integer NOT NULL
);


--
-- TOC entry 1435 (class 1259 OID 47907)
-- Dependencies: 1861 1862 1863 1864 4
-- Name: asset_hardware; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_hardware (
    hardware_id integer NOT NULL,
    hardware_name character varying(100) NOT NULL,
    hardware_number character varying(100),
    hardware_description text,
    hardware_type integer,
    hardware_owner integer,
    hardware_serial_number character varying(50) NOT NULL,
    hardware_model_name character varying(50) DEFAULT ''::character varying,
    hardware_model_number character varying(50) DEFAULT ''::character varying,
    hardware_last_service_date timestamp(1) without time zone,
    hardware_cost double precision,
    hardware_location integer,
    manufacturer_company_id integer,
    vendor_company_id integer,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    hardware_status integer,
    count_software integer DEFAULT 0,
    count_file integer DEFAULT 0,
    hardware_purchase_date timestamp(1) without time zone,
    hardware_warranty_expire_date timestamp(1) without time zone
);

--
-- TOC entry 1437 (class 1259 OID 47927)
-- Dependencies: 1867 4
-- Name: asset_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_map (
    map_id integer NOT NULL,
    hardware_id integer NOT NULL,
    software_id integer NOT NULL,
    license_id integer NOT NULL,
    license_entitlement integer DEFAULT 1
);


--
-- TOC entry 1436 (class 1259 OID 47918)
-- Dependencies: 1865 1866 4
-- Name: asset_software; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_software (
    software_id integer NOT NULL,
    software_name character varying(100) NOT NULL,
    software_description text,
    software_type integer,
    manufacturer_company_id integer,
    vendor_company_id integer,
    quoted_retail_price character varying(50) DEFAULT ''::character varying,
    quoted_oem_price character varying(50) DEFAULT ''::character varying,
    operating_system integer,
    count_license integer,
    count_bookmark integer,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    count_file integer
);


--
-- TOC entry 1438 (class 1259 OID 47942)
-- Dependencies: 1868 4
-- Name: asset_software_licenses; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_software_licenses (
    license_id integer NOT NULL,
    software_id integer NOT NULL,
    license_key character varying(100) NOT NULL,
    license_is_oem character(1),
    license_entitlement integer,
    license_cost double precision,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    license_note character varying(50) DEFAULT ''::character varying
);


--
-- TOC entry 1440 (class 1259 OID 47956)
-- Dependencies: 1869 1870 4
-- Name: attribute; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE attribute (
    attribute_id integer NOT NULL,
    object_type_id integer NOT NULL,
    attribute_key character varying(50),
    "type" character varying(50) NOT NULL,
    is_optional smallint DEFAULT 1::smallint,
    is_editable smallint DEFAULT 1::smallint,
    default_attribute_field_id integer
);


--
-- TOC entry 1444 (class 1259 OID 47991)
-- Dependencies: 1873 4
-- Name: attribute_field; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE attribute_field (
    attribute_field_id integer NOT NULL,
    attribute_id integer NOT NULL,
    content_id integer NOT NULL,
    field_key character varying(50) DEFAULT ''::character varying,
    attribute_field_description text,
    field_key_id smallint,
    icon_id integer
);


--
-- TOC entry 1443 (class 1259 OID 47982)
-- Dependencies: 4
-- Name: content_local; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE content_local (
    content_id integer NOT NULL,
    content_local character varying(50) NOT NULL,
    locale_id character varying(50) NOT NULL
);


--
-- TOC entry 1439 (class 1259 OID 47952)
-- Dependencies: 4
-- Name: system_object; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE system_object (
    object_type_id integer NOT NULL,
    object_key character varying(50) NOT NULL
);


--
-- TOC entry 1446 (class 1259 OID 48022)
-- Dependencies: 1875 4
-- Name: blog_post; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE blog_post (
    post_id integer NOT NULL,
    post_name character varying(100) NOT NULL,
    post_description text,
    post_type integer,
    post_ip character varying(100),
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    post_allow_comment smallint DEFAULT 1::smallint,
    count_comment integer,
    category_id integer NOT NULL
);


--
-- TOC entry 1445 (class 1259 OID 48014)
-- Dependencies: 1874 4
-- Name: blog_post_category; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE blog_post_category (
    category_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    category_description text,
    count_post integer DEFAULT 0,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1447 (class 1259 OID 48035)
-- Dependencies: 4
-- Name: blog_post_comment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE blog_post_comment (
    comment_id integer NOT NULL,
    comment_name character varying(100),
    comment_description text NOT NULL,
    comment_ip character varying(100),
    creator integer,
    creation_date timestamp(1) without time zone,
    post_id integer NOT NULL
);


--
-- TOC entry 1448 (class 1259 OID 48047)
-- Dependencies: 4
-- Name: bookmark; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE bookmark (
    bookmark_id integer NOT NULL,
    bookmark_name character varying(100) NOT NULL,
    bookmark_description text,
    bookmark_path character varying(225) NOT NULL,
    is_public smallint,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1449 (class 1259 OID 48054)
-- Dependencies: 4
-- Name: bookmark_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE bookmark_map (
    bookmark_map_id integer NOT NULL,
    bookmark_id integer NOT NULL,
    object_type_id integer NOT NULL,
    object_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1450 (class 1259 OID 48068)
-- Dependencies: 1876 1877 1878 1879 1880 1881 4
-- Name: company; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company (
    company_id integer NOT NULL,
    company_name character varying(100) NOT NULL,
    company_description text,
    company_stock_symbol character varying(50) DEFAULT ''::character varying,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    count_main_contact integer DEFAULT 0,
    count_employee_contact integer DEFAULT 0,
    count_bookmark integer DEFAULT 0,
    count_file integer DEFAULT 0,
    count_note integer DEFAULT 0
);


--
-- TOC entry 1451 (class 1259 OID 48081)
-- Dependencies: 4
-- Name: company_note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_note (
    note_id integer NOT NULL,
    note_name character varying(100) NOT NULL,
    note_description text,
    note_type integer,
    company_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1452 (class 1259 OID 48093)
-- Dependencies: 4
-- Name: company_tag; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_tag (
    tag_id integer NOT NULL,
    tag_name character varying(50) NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1453 (class 1259 OID 48099)
-- Dependencies: 4
-- Name: company_tag_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_tag_map (
    company_id integer NOT NULL,
    tag_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1454 (class 1259 OID 48113)
-- Dependencies: 1882 1883 1884 1885 1886 1887 1888 1889 1890 1891 1892 1893 1894 1895 1896 1897 1898 1899 1900 1901 4
-- Name: contact; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE contact (
    contact_id integer NOT NULL,
    company_id integer,
    company_contact_type integer,
    contact_first_name character varying(50) NOT NULL,
    contact_last_name character varying(50) NOT NULL,
    contact_description text,
    contact_title character varying(100) DEFAULT ''::character varying,
    contact_phone_home character varying(50) DEFAULT ''::character varying,
    contact_phone_mobile character varying(50) DEFAULT ''::character varying,
    contact_phone_work character varying(50) DEFAULT ''::character varying,
    contact_fax character varying(50) DEFAULT ''::character varying,
    contact_email_primary character varying(50) DEFAULT ''::character varying,
    contact_email_secondary character varying(50) DEFAULT ''::character varying,
    contact_homepage_url character varying(50) DEFAULT ''::character varying,
    address_street_primary character varying(50) DEFAULT ''::character varying,
    address_city_primary character varying(50) DEFAULT ''::character varying,
    address_state_primary character varying(50) DEFAULT ''::character varying,
    address_zipcode_primary character varying(50) DEFAULT ''::character varying,
    address_country_primary character varying(50) DEFAULT ''::character varying,
    address_street_secondary character varying(50) DEFAULT ''::character varying,
    address_city_secondary character varying(50) DEFAULT ''::character varying,
    address_state_secondary character varying(50) DEFAULT ''::character varying,
    address_zipcode_secondary character varying(50) DEFAULT ''::character varying,
    address_country_secondary character varying(50) DEFAULT ''::character varying,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    user_id integer,
    messenger_1_type integer,
    messenger_1_id character varying(50) DEFAULT ''::character varying,
    messenger_2_type integer,
    messenger_2_id character varying(50) DEFAULT ''::character varying
);


--
-- TOC entry 1442 (class 1259 OID 47976)
-- Dependencies: 1871 1872 4
-- Name: content_locale; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE content_locale (
    locale_id character varying(50) NOT NULL,
    "language" character varying(50) DEFAULT ''::character varying,
    country character varying(50) DEFAULT ''::character varying
);


--
-- TOC entry 1455 (class 1259 OID 48145)
-- Dependencies: 4
-- Name: contract; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE contract (
    contract_id integer NOT NULL,
    contract_name character varying(100) NOT NULL,
    contract_description text,
    contract_type integer,
    contract_effective_date timestamp(1) without time zone,
    contract_expiration_date timestamp(1) without time zone,
    contract_renewal_type integer,
    contract_renewal_date timestamp(1) without time zone,
    company_id integer,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1456 (class 1259 OID 48152)
-- Dependencies: 1902 1903 1904 4
-- Name: file; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file (
    file_id integer NOT NULL,
    file_name character varying(100) NOT NULL,
    file_friendly_name character varying(100) DEFAULT ''::character varying,
    file_description text,
    file_mime_type character varying(100) DEFAULT ''::character varying,
    file_byte_size bigint,
    file_uploaded_file_name character varying(100) DEFAULT ''::character varying,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1457 (class 1259 OID 48162)
-- Dependencies: 4
-- Name: file_map; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_map (
    file_map_id integer NOT NULL,
    file_id integer NOT NULL,
    object_type_id integer NOT NULL,
    object_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1441 (class 1259 OID 47967)
-- Dependencies: 4
-- Name: icon; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE icon (
    icon_id integer NOT NULL,
    icon_path character varying(225) NOT NULL,
    is_system_icon smallint,
    attribute_id integer NOT NULL
);


--
-- TOC entry 1458 (class 1259 OID 48176)
-- Dependencies: 4
-- Name: issue; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE issue (
    issue_id integer NOT NULL,
    issue_name character varying(100) NOT NULL,
    issue_description text,
    issue_assignee integer,
    issue_url text,
    issue_type integer,
    issue_status integer,
    issue_priority integer,
    issue_resolution integer,
    duplicate_id integer,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    issue_due_date timestamp(1) without time zone,
    creator_ip character varying(15)
);


--
-- TOC entry 1460 (class 1259 OID 48200)
-- Dependencies: 4
-- Name: issue_change; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE issue_change (
    issue_change_id integer NOT NULL,
    issue_change_field character varying(20),
    issue_change_varchar_old character varying(100),
    issue_change_varchar_new character varying(100),
    issue_change_int_old integer,
    issue_change_int_new integer,
    issue_comment_id integer,
    file_id integer,
    issue_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);


--
-- TOC entry 1459 (class 1259 OID 48188)
-- Dependencies: 4
-- Name: issue_comment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE issue_comment (
    issue_comment_id integer NOT NULL,
    issue_comment_description text,
    issue_id integer NOT NULL
);


--
-- TOC entry 1462 (class 1259 OID 48233)
-- Dependencies: 4
-- Name: issue_subscription; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE issue_subscription (
    issue_id integer NOT NULL,
    user_id integer NOT NULL,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1463 (class 1259 OID 48247)
-- Dependencies: 4
-- Name: portal_site; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE portal_site (
    site_id integer NOT NULL,
    site_name character varying(100) NOT NULL,
    site_description text,
    site_path character varying(225) NOT NULL,
    site_is_public smallint,
    site_support_iframe smallint,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone
);


--
-- TOC entry 1464 (class 1259 OID 48254)
-- Dependencies: 4
-- Name: rss_feed; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE rss_feed (
    feed_id integer NOT NULL,
    feed_url text,
    creator integer,
    creation_date timestamp(1) without time zone,
    modifier integer,
    modification_date timestamp(1) without time zone,
    feed_cache text,
    feed_cache_date timestamp(1) without time zone,
    feed_name character varying(100) NOT NULL,
    feed_item_count integer
);


--
-- TOC entry 1468 (class 1259 OID 48274)
-- Dependencies: 4
-- Name: seq_asset_hardware_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_asset_hardware_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2066 (class 0 OID 0)
-- Dependencies: 1468
-- Name: seq_asset_hardware_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_asset_hardware_id', 1, false);


--
-- TOC entry 1470 (class 1259 OID 48278)
-- Dependencies: 4
-- Name: seq_asset_map_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_asset_map_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2067 (class 0 OID 0)
-- Dependencies: 1470
-- Name: seq_asset_map_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_asset_map_id', 1, false);


--
-- TOC entry 1469 (class 1259 OID 48276)
-- Dependencies: 4
-- Name: seq_asset_software_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_asset_software_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2068 (class 0 OID 0)
-- Dependencies: 1469
-- Name: seq_asset_software_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_asset_software_id', 1, false);


--
-- TOC entry 1471 (class 1259 OID 48280)
-- Dependencies: 4
-- Name: seq_asset_software_license_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_asset_software_license_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2069 (class 0 OID 0)
-- Dependencies: 1471
-- Name: seq_asset_software_license_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_asset_software_license_id', 1, false);


--
-- TOC entry 1474 (class 1259 OID 48286)
-- Dependencies: 4
-- Name: seq_attribute_field_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_attribute_field_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2070 (class 0 OID 0)
-- Dependencies: 1474
-- Name: seq_attribute_field_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_attribute_field_id', 68, true);


--
-- TOC entry 1475 (class 1259 OID 48288)
-- Dependencies: 4
-- Name: seq_blog_post_category_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_blog_post_category_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2071 (class 0 OID 0)
-- Dependencies: 1475
-- Name: seq_blog_post_category_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_blog_post_category_id', 2, true);


--
-- TOC entry 1477 (class 1259 OID 48292)
-- Dependencies: 4
-- Name: seq_blog_post_comment_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_blog_post_comment_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2072 (class 0 OID 0)
-- Dependencies: 1477
-- Name: seq_blog_post_comment_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_blog_post_comment_id', 1, false);


--
-- TOC entry 1476 (class 1259 OID 48290)
-- Dependencies: 4
-- Name: seq_blog_post_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_blog_post_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2073 (class 0 OID 0)
-- Dependencies: 1476
-- Name: seq_blog_post_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_blog_post_id', 2, true);


--
-- TOC entry 1478 (class 1259 OID 48294)
-- Dependencies: 4
-- Name: seq_bookmark_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_bookmark_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2074 (class 0 OID 0)
-- Dependencies: 1478
-- Name: seq_bookmark_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_bookmark_id', 1, false);


--
-- TOC entry 1479 (class 1259 OID 48296)
-- Dependencies: 4
-- Name: seq_bookmark_map_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_bookmark_map_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2075 (class 0 OID 0)
-- Dependencies: 1479
-- Name: seq_bookmark_map_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_bookmark_map_id', 1, false);


--
-- TOC entry 1480 (class 1259 OID 48298)
-- Dependencies: 4
-- Name: seq_company_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_company_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2076 (class 0 OID 0)
-- Dependencies: 1480
-- Name: seq_company_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_company_id', 1, false);


--
-- TOC entry 1481 (class 1259 OID 48300)
-- Dependencies: 4
-- Name: seq_company_note_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_company_note_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2077 (class 0 OID 0)
-- Dependencies: 1481
-- Name: seq_company_note_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_company_note_id', 1, false);


--
-- TOC entry 1482 (class 1259 OID 48302)
-- Dependencies: 4
-- Name: seq_company_tag_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_company_tag_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2078 (class 0 OID 0)
-- Dependencies: 1482
-- Name: seq_company_tag_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_company_tag_id', 1, false);


--
-- TOC entry 1483 (class 1259 OID 48304)
-- Dependencies: 4
-- Name: seq_contact_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_contact_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2079 (class 0 OID 0)
-- Dependencies: 1483
-- Name: seq_contact_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_contact_id', 3, true);


--
-- TOC entry 1473 (class 1259 OID 48284)
-- Dependencies: 4
-- Name: seq_content_local_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_content_local_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2080 (class 0 OID 0)
-- Dependencies: 1473
-- Name: seq_content_local_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_content_local_id', 84, true);


--
-- TOC entry 1484 (class 1259 OID 48306)
-- Dependencies: 4
-- Name: seq_contract_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_contract_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2081 (class 0 OID 0)
-- Dependencies: 1484
-- Name: seq_contract_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_contract_id', 1, false);


--
-- TOC entry 1485 (class 1259 OID 48308)
-- Dependencies: 4
-- Name: seq_file_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_file_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2082 (class 0 OID 0)
-- Dependencies: 1485
-- Name: seq_file_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_file_id', 1, false);


--
-- TOC entry 1486 (class 1259 OID 48310)
-- Dependencies: 4
-- Name: seq_file_map_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_file_map_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2083 (class 0 OID 0)
-- Dependencies: 1486
-- Name: seq_file_map_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_file_map_id', 1, false);


--
-- TOC entry 1514 (class 1259 OID 48506)
-- Dependencies: 4
-- Name: seq_group_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_group_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2084 (class 0 OID 0)
-- Dependencies: 1514
-- Name: seq_group_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_group_id', 1, true);


--
-- TOC entry 1472 (class 1259 OID 48282)
-- Dependencies: 4
-- Name: seq_icon_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_icon_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2085 (class 0 OID 0)
-- Dependencies: 1472
-- Name: seq_icon_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_icon_id', 5, true);


--
-- TOC entry 1489 (class 1259 OID 48316)
-- Dependencies: 4
-- Name: seq_issue_change_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_issue_change_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2086 (class 0 OID 0)
-- Dependencies: 1489
-- Name: seq_issue_change_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_issue_change_id', 1, false);


--
-- TOC entry 1488 (class 1259 OID 48314)
-- Dependencies: 4
-- Name: seq_issue_comment_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_issue_comment_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2087 (class 0 OID 0)
-- Dependencies: 1488
-- Name: seq_issue_comment_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_issue_comment_id', 1, false);


--
-- TOC entry 1487 (class 1259 OID 48312)
-- Dependencies: 4
-- Name: seq_issue_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_issue_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2088 (class 0 OID 0)
-- Dependencies: 1487
-- Name: seq_issue_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_issue_id', 1, false);


--
-- TOC entry 1491 (class 1259 OID 48320)
-- Dependencies: 4
-- Name: seq_portal_site_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_portal_site_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2089 (class 0 OID 0)
-- Dependencies: 1491
-- Name: seq_portal_site_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_portal_site_id', 1, false);


--
-- TOC entry 1492 (class 1259 OID 48322)
-- Dependencies: 4
-- Name: seq_rss_feed_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_rss_feed_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2090 (class 0 OID 0)
-- Dependencies: 1492
-- Name: seq_rss_feed_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_rss_feed_id', 1, false);


--
-- TOC entry 1490 (class 1259 OID 48318)
-- Dependencies: 4
-- Name: seq_user_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seq_user_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


--
-- TOC entry 2091 (class 0 OID 0)
-- Dependencies: 1490
-- Name: seq_user_id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seq_user_id', 2, true);


--
-- TOC entry 1465 (class 1259 OID 48261)
-- Dependencies: 4
-- Name: system_config; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE system_config (
    config_key character varying(50) NOT NULL,
    config_value text
);


--
-- TOC entry 1466 (class 1259 OID 48268)
-- Dependencies: 4
-- Name: user_login_history; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_login_history (
    user_id integer NOT NULL,
    login_date timestamp(1) without time zone
);


--
-- TOC entry 1467 (class 1259 OID 48270)
-- Dependencies: 1909 4
-- Name: user_session; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_session (
    user_id integer NOT NULL,
    last_logon timestamp(1) without time zone,
    last_visit timestamp(1) without time zone,
    session_key character varying(50) DEFAULT ''::character varying
);


--
-- TOC entry 2058 (class 0 OID 48475)
-- Dependencies: 1511
-- Data for Name: access_group; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2060 (class 0 OID 48494)
-- Dependencies: 1513
-- Data for Name: access_group_perm_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2059 (class 0 OID 48482)
-- Dependencies: 1512
-- Data for Name: access_group_user_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2021 (class 0 OID 47877)
-- Dependencies: 1433
-- Data for Name: access_page; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO access_page (page_id, page_name, page_description) VALUES (1, '/issue-tracker/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (2, '/issue-tracker/issue-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (3, '/issue-tracker/issue-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (4, '/admin/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (5, '/admin/user-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (6, '/admin/user-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (7, '/admin/user-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (8, '/admin/user-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (9, '/admin/user-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (10, '/admin/user-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (11, '/admin/config-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (12, '/issue-plugin/issue-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (13, '/issue-plugin/issue-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (14, '/issue-plugin/issue-add-3.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (15, '/issue-tracker/issue-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (16, '/issue-tracker/issue-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (17, '/IT/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (18, '/IT/hardware-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (19, '/IT/hardware-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (20, '/IT/hardware-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (21, '/IT/hardware-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (22, '/IT/hardware-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (23, '/IT/hardware-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (24, '/IT/hardware-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (25, '/IT/hardware-license-remove-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (26, '/IT/hardware-category-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (27, '/IT/hardware-license-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (28, '/IT/software-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (29, '/IT/software-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (30, '/IT/software-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (31, '/IT/software-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (32, '/IT/software-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (33, '/IT/software-license-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (34, '/IT/software-license-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (35, '/IT/software-license-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (36, '/IT/software-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (37, '/IT/software-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (38, '/IT/software-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (39, '/IT/software-license-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (40, '/IT/software-license-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (41, '/admin/user-access.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (42, '/admin/user-access-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (43, '/admin/user-access-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (44, '/IT/software-license-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (45, '/IT/hardware-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (46, '/IT/hardware-license-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (47, '/IT/hardware-license-remove.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (48, '/contact-mgmt/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (49, '/contact-mgmt/company-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (50, '/contact-mgmt/company-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (51, '/contact-mgmt/company-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (52, '/contact-mgmt/company-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (53, '/contact-mgmt/company-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (54, '/contact-mgmt/company-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (55, '/contact-mgmt/contact-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (56, '/contact-mgmt/contact-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (57, '/contact-mgmt/contact-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (58, '/contact-mgmt/contact-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (59, '/contact-mgmt/contact-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (60, '/contact-mgmt/contact-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (61, '/contact-mgmt/company-contact.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (62, '/contact-mgmt/company-contact-export.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (63, '/contact-mgmt/contact-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (64, '/contact-mgmt/contact-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (65, '/contact-mgmt/company-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (66, '/contact-mgmt/company-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (67, '/web-calendar/year.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (68, '/web-calendar/month.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (69, '/web-calendar/week.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (70, '/web-calendar/day.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (71, '/user-preference/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (72, '/user-preference/password-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (73, '/user-preference/password-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (74, '/contact-mgmt/contact-detail-vcard.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (75, '/contact-mgmt/company-contact-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (76, '/contact-mgmt/company-contact-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (77, '/contact-mgmt/company-contact-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (78, '/contact-mgmt/company-contact-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (79, '/contact-mgmt/company-contact-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (80, '/contact-mgmt/company-contact-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (85, '/admin/attribute-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (86, '/admin/attribute-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (87, '/admin/attribute-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (88, '/admin/attribute-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (89, '/admin/attribute-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (90, '/admin/attribute-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (91, '/issue-tracker/issue-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (92, '/issue-tracker/issue-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (93, '/IT/software-bookmark-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (94, '/IT/software-bookmark-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (95, '/IT/software-bookmark-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (96, '/IT/software-bookmark-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (97, '/IT/software-bookmark-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (98, '/IT/software-bookmark-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (99, '/IT/software-bookmark.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (102, '/contact-mgmt/company-bookmark.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (103, '/contact-mgmt/company-bookmark-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (104, '/contact-mgmt/company-bookmark-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (105, '/contact-mgmt/company-bookmark-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (106, '/contact-mgmt/company-bookmark-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (107, '/contact-mgmt/company-bookmark-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (108, '/contact-mgmt/company-bookmark-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (109, '/IT/software-file-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (110, '/IT/software-file-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (111, '/IT/software-file.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (112, '/IT/software-file-download.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (113, '/IT/software-file-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (114, '/IT/software-file-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (115, '/issue-tracker/issue-file-download.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (116, '/issue-tracker/issue-file-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (117, '/issue-tracker/issue-file-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (118, '/portal/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (119, '/portal/site-list-rss.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (120, '/admin/portal-site-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (121, '/admin/portal-site-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (122, '/admin/portal-site-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (123, '/admin/portal-site-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (124, '/admin/portal-site-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (125, '/admin/portal-site-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (126, '/admin/portal-site-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (127, '/admin/portal-site-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (129, '/IT/ajax-get-license-by-software.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (130, '/IT/ajax-get-software-by-maker.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (131, '/IT/ajax-get-hardware-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (132, '/portal/site-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (133, '/portal/blog-post-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (134, '/portal/blog-post-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (135, '/portal/blog-post-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (136, '/portal/blog-post-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (139, '/portal/blog-post-comment-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (140, '/portal/blog-post-list-rss.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (141, '/IT/hardware-file-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (142, '/IT/hardware-file-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (143, '/IT/hardware-file.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (144, '/IT/hardware-file-download.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (145, '/IT/hardware-file-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (146, '/IT/hardware-file-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (147, '/util-tool/graphic-draw.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (148, '/util-tool/index.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (149, '/contact-mgmt/company-file.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (150, '/contact-mgmt/company-file-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (151, '/contact-mgmt/company-file-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (152, '/contact-mgmt/company-file-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (153, '/contact-mgmt/company-file-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (154, '/contact-mgmt/company-file-download.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (156, '/IT/hardware-list-export.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (157, '/IT/software-list-export.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (158, '/admin/user-list-export.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (164, '/portal/blog-post-category-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (165, '/portal/blog-post-category-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (166, '/portal/blog-post-category-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (167, '/portal/blog-post-category-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (168, '/IT/contract-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (169, '/IT/contract-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (170, '/IT/contract-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (171, '/IT/contract-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (172, '/IT/contract-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (173, '/IT/contract-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (174, '/IT/contract-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (175, '/IT/contract-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (176, '/contact-mgmt/company-note.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (177, '/contact-mgmt/company-note-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (178, '/contact-mgmt/company-note-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (179, '/portal/rss-feed-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (180, '/portal/rss-feed-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (181, '/portal/rss-feed-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (182, '/portal/rss-feed-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (183, '/portal/rss-feed-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (184, '/portal/rss-feed-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (185, '/portal/rss-feed-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (186, '/portal/rss-feed-list-titles.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (187, '/portal/rss-feed-list-items.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (188, '/portal/rss-feed-list-description.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (189, '/admin/group-list.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (190, '/admin/group-detail.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (191, '/admin/group-access.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (192, '/admin/group-add.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (193, '/admin/group-add-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (194, '/admin/group-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (195, '/admin/group-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (196, '/admin/group-delete.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (197, '/admin/group-delete-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (198, '/admin/group-access-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (199, '/admin/group-access-edit-2.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (83, '/admin/config-edit.dll', '');
INSERT INTO access_page (page_id, page_name, page_description) VALUES (84, '/admin/config-edit-2.dll', '');


--
-- TOC entry 2057 (class 0 OID 48453)
-- Dependencies: 1510
-- Data for Name: access_perm_page_map; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (1, 1);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (1, 2);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (1, 3);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 15);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 16);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 4);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 11);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 6);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 5);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 8);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 7);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 10);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 9);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 19);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (5, 18);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (7, 28);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (5, 17);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 29);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 27);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 23);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 24);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 21);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 20);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 25);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 31);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 30);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 32);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 33);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 35);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 34);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 22);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (5, 26);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 36);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 37);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 38);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 39);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 40);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 41);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 42);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 43);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 44);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 45);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 46);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 47);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 48);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 49);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 50);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 51);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 52);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 53);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 54);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 26);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 18);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 17);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 17);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 28);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (7, 17);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 26);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 19);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 18);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 17);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 29);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 28);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 55);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 56);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 57);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 58);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 59);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 60);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 61);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 62);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 63);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 64);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 65);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 66);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (13, 67);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (13, 68);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (13, 69);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (13, 70);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (14, 71);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (14, 72);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (14, 73);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 74);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 75);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 76);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 77);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 78);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 79);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 80);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 83);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 84);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 85);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 86);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 87);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 88);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 89);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 90);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 91);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 92);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 93);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 94);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 95);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 96);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 97);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 98);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 99);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 99);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 102);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 103);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 104);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 105);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 106);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 107);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 108);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 109);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 110);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 111);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 111);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 112);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 112);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 113);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 114);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (1, 115);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 116);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (2, 117);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 118);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 119);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 120);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 121);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 122);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 123);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 124);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 125);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 126);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 127);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 129);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 129);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (7, 130);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 130);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 130);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 131);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 131);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 132);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 133);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 134);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (16, 135);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (16, 136);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (16, 139);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 140);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 141);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 142);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 143);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 143);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 144);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 144);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 145);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 146);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (17, 147);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (17, 148);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 149);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 150);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 151);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 152);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 153);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 154);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (5, 156);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (6, 156);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 156);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (7, 157);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (8, 157);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 157);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 158);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (19, 164);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (19, 165);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (19, 166);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (19, 167);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 168);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (12, 169);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 170);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 171);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 172);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 173);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 174);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (9, 175);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (10, 176);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 177);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (11, 178);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 179);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 180);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 181);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 182);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 183);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 184);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (18, 185);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 186);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 187);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (15, 188);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 189);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 190);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (3, 191);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 192);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 193);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 194);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 195);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 196);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 197);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 198);
INSERT INTO access_perm_page_map (perm_id, page_id) VALUES (4, 199);


--
-- TOC entry 2056 (class 0 OID 48445)
-- Dependencies: 1509
-- Data for Name: access_permission; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (1, 'issue_read', '', 1, 21);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (2, 'issue_write', '', 1, 22);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (3, 'admin_read', '', 1, 1);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (4, 'admin_write', '', 1, 2);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (5, 'asset_hardware_list_read', '', 1, 34);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (6, 'asset_hardware_all_read', '', 1, 33);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (7, 'asset_software_list_read', '', 1, 36);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (8, 'asset_software_all_read', '', 1, 35);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (9, 'asset_write', '', 1, 32);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (10, 'contact_read', '', 1, 11);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (11, 'contact_write', '', 1, 12);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (12, 'asset_read', '', 1, 31);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (13, 'calendar_read', '', 0, 0);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (14, 'user_preference', '', 1, 51);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (15, 'portal_read', NULL, 1, 41);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (16, 'portal_blog_write', '', 1, 42);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (17, 'util_read', '', 0, 0);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (18, 'portal_rss_write', '', 1, 43);
INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (19, 'portal_admin', '', 1, 40);


--
-- TOC entry 2049 (class 0 OID 48219)
-- Dependencies: 1461
-- Data for Name: access_user; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO access_user (user_id, username, "password", display_name, status, first_name, last_name, email, creator, creation_date, modifier, modification_date) VALUES (-1001, 'guest', '0DPiKuNIrrVmD8IUCuw1hQxNqZc=', 'Guest', '0', 'Guest', 'User', 'guest@localhost', 1, now(), NULL, NULL);
INSERT INTO access_user (user_id, username, "password", display_name, status, first_name, last_name, email, creator, creation_date, modifier, modification_date) VALUES (1, 'admin', '0DPiKuNIrrVmD8IUCuw1hQxNqZc=', 'System Admin', '1', 'System', 'Administrator', 'admin@localhost', 1, now(), NULL, NULL);


--
-- TOC entry 2022 (class 0 OID 47900)
-- Dependencies: 1434
-- Data for Name: access_user_perm_map; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 1);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 2);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 3);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 4);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 5);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 6);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 7);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 8);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 9);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 10);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 11);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 12);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 13);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 14);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 15);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 16);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 18);
INSERT INTO access_user_perm_map (user_id, perm_id) VALUES (1, 19);


--
-- TOC entry 2023 (class 0 OID 47907)
-- Dependencies: 1435
-- Data for Name: asset_hardware; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2025 (class 0 OID 47927)
-- Dependencies: 1437
-- Data for Name: asset_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2024 (class 0 OID 47918)
-- Dependencies: 1436
-- Data for Name: asset_software; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2026 (class 0 OID 47942)
-- Dependencies: 1438
-- Data for Name: asset_software_licenses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2028 (class 0 OID 47956)
-- Dependencies: 1440
-- Data for Name: attribute; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (1, 7, 'issue_type', 'selectbox', 1, 1, 2);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (2, 7, 'issue_status', 'selectbox', 1, 1, 7);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (3, 7, 'issue_priority', 'selectbox', 1, 1, 16);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (4, 7, 'issue_resolution', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (5, 5, 'company_status', 'selectbox', 1, 0, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (6, 2, 'hardware_location', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (7, 3, 'software_os', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (8, 3, 'software_type', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (10, 2, 'hardware_type', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (11, 6, 'contact_im', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (12, 2, 'hardware_status', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (13, 1, 'user_status', 'selectbox', 0, 0, 57);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (14, 9, 'contract_type', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (15, 9, 'contract_renewal_type', 'selectbox', 1, 1, NULL);
INSERT INTO attribute (attribute_id, object_type_id, attribute_key, "type", is_optional, is_editable, default_attribute_field_id) VALUES (16, 5, 'company_note_type', 'selectbox', 1, 1, NULL);


--
-- TOC entry 2032 (class 0 OID 47991)
-- Dependencies: 1444
-- Data for Name: attribute_field; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (1, 1, 2, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (2, 1, 3, 'question', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (3, 1, 4, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (4, 1, 5, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (5, 1, 6, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (6, 1, 7, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (7, 2, 9, 'new', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (8, 2, 10, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (9, 2, 11, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (10, 2, 12, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (11, 2, 13, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (12, 2, 14, 'reopened', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (13, 2, 15, 'closed', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (14, 3, 17, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (15, 3, 18, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (16, 3, 19, 'medium', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (17, 3, 20, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (18, 3, 21, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (19, 4, 23, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (20, 4, 24, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (21, 4, 25, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (22, 4, 26, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (23, 4, 27, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (24, 5, 29, 'approved', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (25, 5, 30, 'potential', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (26, 6, 32, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (27, 6, 33, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (28, 7, 35, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (29, 7, 36, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (30, 7, 37, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (31, 8, 39, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (32, 8, 40, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (47, 10, 57, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (48, 10, 58, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (49, 10, 59, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (51, 11, 62, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (52, 11, 63, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (53, 12, 65, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (54, 12, 66, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (55, 12, 67, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (56, 12, 68, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (57, 13, 70, 'enabled', NULL, 1, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (58, 13, 71, 'disabled', NULL, 0, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (61, 14, 75, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (62, 14, 76, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (63, 15, 78, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (64, 15, 79, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (65, 16, 81, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (66, 16, 82, '', NULL, NULL, NULL);
INSERT INTO attribute_field (attribute_field_id, attribute_id, content_id, field_key, attribute_field_description, field_key_id, icon_id) VALUES (67, 16, 83, '', NULL, NULL, NULL);


--
-- TOC entry 2033 (class 0 OID 48014)
-- Dependencies: 1445
-- Data for Name: blog_post_category; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO blog_post_category (category_id, category_name, category_description, count_post, creator, creation_date, modifier, modification_date) VALUES (1, 'Uncategorized', '', 0, 1, now(), NULL, NULL);


--
-- TOC entry 2035 (class 0 OID 48035)
-- Dependencies: 1447
-- Data for Name: blog_post_comment; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2036 (class 0 OID 48047)
-- Dependencies: 1448
-- Data for Name: bookmark; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2037 (class 0 OID 48054)
-- Dependencies: 1449
-- Data for Name: bookmark_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2038 (class 0 OID 48068)
-- Dependencies: 1450
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2039 (class 0 OID 48081)
-- Dependencies: 1451
-- Data for Name: company_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2040 (class 0 OID 48093)
-- Dependencies: 1452
-- Data for Name: company_tag; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2041 (class 0 OID 48099)
-- Dependencies: 1453
-- Data for Name: company_tag_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2042 (class 0 OID 48113)
-- Dependencies: 1454
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO contact (contact_id, company_id, company_contact_type, contact_first_name, contact_last_name, contact_description, contact_title, contact_phone_home, contact_phone_mobile, contact_phone_work, contact_fax, contact_email_primary, contact_email_secondary, contact_homepage_url, address_street_primary, address_city_primary, address_state_primary, address_zipcode_primary, address_country_primary, address_street_secondary, address_city_secondary, address_state_secondary, address_zipcode_secondary, address_country_secondary, creator, creation_date, modifier, modification_date, user_id, messenger_1_type, messenger_1_id, messenger_2_type, messenger_2_id) VALUES (1, NULL, 11, 'Guest', 'User', NULL, '', '', '', '', '', 'guest@localhost', '', '', '', '', '', '', '', '', '', '', '', '', 1, now(), NULL, NULL, -1001, NULL, '', NULL, '');
INSERT INTO contact (contact_id, company_id, company_contact_type, contact_first_name, contact_last_name, contact_description, contact_title, contact_phone_home, contact_phone_mobile, contact_phone_work, contact_fax, contact_email_primary, contact_email_secondary, contact_homepage_url, address_street_primary, address_city_primary, address_state_primary, address_zipcode_primary, address_country_primary, address_street_secondary, address_city_secondary, address_state_secondary, address_zipcode_secondary, address_country_secondary, creator, creation_date, modifier, modification_date, user_id, messenger_1_type, messenger_1_id, messenger_2_type, messenger_2_id) VALUES (2, NULL, 11, 'System', 'Administrator', NULL, '', '', '', '', '', 'admin@localhost', '', '', '', '', '', '', '', '', '', '', '', '', 1, now(), NULL, NULL, 1, NULL, '', NULL, '');


--
-- TOC entry 2031 (class 0 OID 47982)
-- Dependencies: 1443
-- Data for Name: content_local; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO content_local (content_id, content_local, locale_id) VALUES (2, 'Suggestion', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (3, 'Question', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (4, 'General Request', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (5, 'Software Installation', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (6, 'Hardware Installation', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (7, 'Specification', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (9, 'S1: New', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (10, 'S2: Assigned', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (11, 'S3: Resovled', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (12, 'S4: Deployed', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (13, 'S5: Verified', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (14, 'S6: Reopened', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (15, 'S7: Closed', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (17, 'P1: Very High', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (18, 'P2: High', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (19, 'P3: Medium', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (20, 'P4: Low', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (21, 'P5: Very Low', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (23, 'Fixed', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (24, 'Can''t Reproduce', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (25, 'Invalid', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (26, 'Duplicate', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (27, 'Deferred', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (29, 'Approved', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (30, 'Potential', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (32, 'Headquarter', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (33, 'Branch Office', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (35, 'Windows', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (36, 'Linux', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (37, 'Mac', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (39, 'Operating System', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (40, 'Application', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (57, 'Server', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (58, 'Laptop', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (59, 'Desktop', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (62, 'Yahoo Messenger', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (63, 'Windows Messenger', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (65, 'Available', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (66, 'In use', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (67, 'Checked-out', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (68, 'Lost or stolen', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (70, 'Enabled', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (71, 'Disabled', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (75, 'Purchase Contract', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (76, 'Service Contract', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (78, 'One-Time', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (79, 'Recurring', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (81, 'Call Log', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (82, 'Appointment Reminder', 'en_US');
INSERT INTO content_local (content_id, content_local, locale_id) VALUES (83, 'Other', 'en_US');


--
-- TOC entry 2030 (class 0 OID 47976)
-- Dependencies: 1442
-- Data for Name: content_locale; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO content_locale (locale_id, "language", country) VALUES ('ar_SA', 'Arabic', 'Saudia Arabia');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('de_DE', 'German', 'Germany');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('en_AU', 'English', 'Australia');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('en_CA', 'English', 'Canada');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('en_GB', 'English', 'United Kingdom');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('en_US', 'English', 'United States');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('es_ES', 'Spanish', 'Spain');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('fr_CA', 'French', 'Canada');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('fr_FR', 'French', 'France');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('hi_IN', 'Hindi', 'India');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('it_IT', 'Italian', 'Italy');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('iw_IL', 'Hebrew', 'Israel');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('ja_JP', 'Japanese', 'Japan');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('ko_KR', 'Korean', 'South Korea');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('nl_NL', 'Dutch', 'Netherlands');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('pt_BR', 'Portuguese', 'Brazil');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('sv_SE', 'Swedish', 'Sweden');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('th_TH', 'Thai (Western digits)', 'Thailand');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('th_TH_TH', 'Thai (Thai digits)', 'Thailand');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('tr_TR', 'Turkish', 'Turkey');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('zh_CN', 'Chinese (Simplified)', 'China');
INSERT INTO content_locale (locale_id, "language", country) VALUES ('zh_TW', 'Chinese (Traditional)', 'Taiwan');


--
-- TOC entry 2043 (class 0 OID 48145)
-- Dependencies: 1455
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2044 (class 0 OID 48152)
-- Dependencies: 1456
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2045 (class 0 OID 48162)
-- Dependencies: 1457
-- Data for Name: file_map; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2029 (class 0 OID 47967)
-- Dependencies: 1441
-- Data for Name: icon; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (1, '/common/default/images/icons/computer.png', 1, 10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (2, '/common/default/images/icons/printer.png', 1, 10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (3, '/common/default/images/icons/server.png', 1, 10);
INSERT INTO icon (icon_id, icon_path, is_system_icon, attribute_id) VALUES (5, '/common/default/images/icons/tux.png', 1, 7);


--
-- TOC entry 2046 (class 0 OID 48176)
-- Dependencies: 1458
-- Data for Name: issue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2048 (class 0 OID 48200)
-- Dependencies: 1460
-- Data for Name: issue_change; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2047 (class 0 OID 48188)
-- Dependencies: 1459
-- Data for Name: issue_comment; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2050 (class 0 OID 48233)
-- Dependencies: 1462
-- Data for Name: issue_subscription; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2051 (class 0 OID 48247)
-- Dependencies: 1463
-- Data for Name: portal_site; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2052 (class 0 OID 48254)
-- Dependencies: 1464
-- Data for Name: rss_feed; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2053 (class 0 OID 48261)
-- Dependencies: 1465
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO system_config (config_key, config_value) VALUES ('auth.authenticationMethod', 'app');
INSERT INTO system_config (config_key, config_value) VALUES ('auth.authenticationMethod.options', 'app,ldap');
INSERT INTO system_config (config_key, config_value) VALUES ('auth.domain', '');
INSERT INTO system_config (config_key, config_value) VALUES ('auth.ldapUrl', '');
INSERT INTO system_config (config_key, config_value) VALUES ('auth.sessionTimeoutSeconds', '10800');
INSERT INTO system_config (config_key, config_value) VALUES ('auth.sessionTimeoutSeconds.options', '3600,7200,10800,14400');
INSERT INTO system_config (config_key, config_value) VALUES ('calendar.maxYearPlus', '20');
INSERT INTO system_config (config_key, config_value) VALUES ('calendar.minYear', '1980');
INSERT INTO system_config (config_key, config_value) VALUES ('characterEncoding', 'UTF-8');
INSERT INTO system_config (config_key, config_value) VALUES ('companies.numberOfRowsToShow', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('companyLogoPath', '');
INSERT INTO system_config (config_key, config_value) VALUES ('companyName', '');
INSERT INTO system_config (config_key, config_value) VALUES ('companyPath', '');
INSERT INTO system_config (config_key, config_value) VALUES ('contacts.numberOfRowsToShow', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('currency.options', '');
INSERT INTO system_config (config_key, config_value) VALUES ('datetime.base', 'yyyy-MM-dd HH:mm:ss');
INSERT INTO system_config (config_key, config_value) VALUES ('datetime.shortDateFormat', 'yyyy-MM-dd');
INSERT INTO system_config (config_key, config_value) VALUES ('datetime.shortDateFormat.options', 'M/d/yyyy,MM/dd/yyyy,yyyy-MM-dd');
INSERT INTO system_config (config_key, config_value) VALUES ('datetime.timeFormat', 'HH:mm:ss');
INSERT INTO system_config (config_key, config_value) VALUES ('datetime.timeFormat.options', 'HH:mm:ss,H:mm:ss,h:mm a,h:mm:ss a');
INSERT INTO system_config (config_key, config_value) VALUES ('default.serviceName', 'DEMO');
INSERT INTO system_config (config_key, config_value) VALUES ('email.allowedDomains', 'localhost');
INSERT INTO system_config (config_key, config_value) VALUES ('email.domainFiltering', '1');
INSERT INTO system_config (config_key, config_value) VALUES ('email.domainFiltering.options', '1,2');
INSERT INTO system_config (config_key, config_value) VALUES ('email.notification', '1');
INSERT INTO system_config (config_key, config_value) VALUES ('email.notification.options', '1,2');
INSERT INTO system_config (config_key, config_value) VALUES ('file.company.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\company');
INSERT INTO system_config (config_key, config_value) VALUES ('file.company.uploadFilePrefix', 'COM-');
INSERT INTO system_config (config_key, config_value) VALUES ('file.hardware.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\hardware');
INSERT INTO system_config (config_key, config_value) VALUES ('file.hardware.uploadFilePrefix', 'HW-');
INSERT INTO system_config (config_key, config_value) VALUES ('file.issue.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\issue');
INSERT INTO system_config (config_key, config_value) VALUES ('file.issue.uploadFilePrefix', 'ISSUE-');
INSERT INTO system_config (config_key, config_value) VALUES ('file.software.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\software');
INSERT INTO system_config (config_key, config_value) VALUES ('file.software.uploadFilePrefix', 'SWLIC-');
INSERT INTO system_config (config_key, config_value) VALUES ('hardware.numberOfRowsToShow', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('issues.numberOfRowsToShow', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('license.key', '');
INSERT INTO system_config (config_key, config_value) VALUES ('locale', 'en_US');
INSERT INTO system_config (config_key, config_value) VALUES ('module.numberOfRowsToShow.options', '10,20,50');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostCharactersOnList', '300');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostCharactersOnMain', '0');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostCharactersOptions', '0,200,300,500,1000,2000');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostsOptions', '5,10,15,20,50');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostsToShowOnList', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('portal.numberOfBlogPostsToShowOnMain', '5');
INSERT INTO system_config (config_key, config_value) VALUES ('rp.authPackages', 'admin,contact-mgmt,issue-tracker,IT,user-preference,portal,util-tool');
INSERT INTO system_config (config_key, config_value) VALUES ('rp.packages', 'auth,issue-plugin,home');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.from', 'system@localhost');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.host', 'your.emailserver.hostname.local');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.password', 'your_password');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.port', '587');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.to', 'demo@localhost');
INSERT INTO system_config (config_key, config_value) VALUES ('smtp.username', 'system@localhost');
INSERT INTO system_config (config_key, config_value) VALUES ('theme.default', 'blue');
INSERT INTO system_config (config_key, config_value) VALUES ('theme.options', 'blue,green,red,orange,purple');
INSERT INTO system_config (config_key, config_value) VALUES ('timezone.base', 'GMT');
INSERT INTO system_config (config_key, config_value) VALUES ('timezone.local', 'PST');
INSERT INTO system_config (config_key, config_value) VALUES ('timezone.local.options', 'Etc/GMT+12,Etc/GMT+11,US/Hawaii,US/Alaska,PST,MST,US/Central,EST,Canada/Atlantic,America/Montevideo,Atlantic/South_Georgia,Atlantic/Cape_Verde,Etc/Greenwich,Europe/Amsterdam,Asia/Jerusalem,Europe/Moscow,Asia/Tehran,Asia/Baku,Asia/Kabul,Asia/Karachi,Asia/Dhaka,Asia/Bangkok,Asia/Hong_Kong,Asia/Seoul,Australia/Canberra,Asia/Magadan,Pacific/Auckland');
INSERT INTO system_config (config_key, config_value) VALUES ('url.application', 'http://localhost');
INSERT INTO system_config (config_key, config_value) VALUES ('users.numberOfRowsToShow', '10');
INSERT INTO system_config (config_key, config_value) VALUES ('locale.options', 'en_US,es_ES,zh_CN,sr');
INSERT INTO system_config (config_key, config_value) VALUES ('ui.stylesheet', '');
INSERT INTO system_config (config_key, config_value) VALUES ('schema.version', '2.5');
INSERT INTO system_config (config_key, config_value) VALUES ('template.showModules', 'contact-mgmt,issue-tracker,IT,portal');


--
-- TOC entry 2027 (class 0 OID 47952)
-- Dependencies: 1439
-- Data for Name: system_object; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO system_object (object_type_id, object_key) VALUES (1, 'user');
INSERT INTO system_object (object_type_id, object_key) VALUES (2, 'hardware');
INSERT INTO system_object (object_type_id, object_key) VALUES (3, 'software');
INSERT INTO system_object (object_type_id, object_key) VALUES (4, 'software_license');
INSERT INTO system_object (object_type_id, object_key) VALUES (5, 'company');
INSERT INTO system_object (object_type_id, object_key) VALUES (6, 'contact');
INSERT INTO system_object (object_type_id, object_key) VALUES (7, 'issue');
INSERT INTO system_object (object_type_id, object_key) VALUES (8, 'access');
INSERT INTO system_object (object_type_id, object_key) VALUES (9, 'it_contract');


--
-- TOC entry 2054 (class 0 OID 48268)
-- Dependencies: 1466
-- Data for Name: user_login_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 2055 (class 0 OID 48270)
-- Dependencies: 1467
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_session (user_id, last_logon, last_visit, session_key) VALUES (1, NULL, NULL, NULL);
INSERT INTO user_session (user_id, last_logon, last_visit, session_key) VALUES (-1001, NULL, NULL, NULL);


--
-- TOC entry 1986 (class 2606 OID 48481)
-- Dependencies: 1511 1511
-- Name: pk_access_group_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_group
    ADD CONSTRAINT pk_access_group_id PRIMARY KEY (group_id);


--
-- TOC entry 1912 (class 2606 OID 47883)
-- Dependencies: 1433 1433
-- Name: pk_access_page_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_page
    ADD CONSTRAINT pk_access_page_id PRIMARY KEY (page_id);


--
-- TOC entry 1984 (class 2606 OID 48452)
-- Dependencies: 1509 1509
-- Name: pk_access_perm_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_permission
    ADD CONSTRAINT pk_access_perm_id PRIMARY KEY (perm_id);


--
-- TOC entry 1916 (class 2606 OID 47917)
-- Dependencies: 1435 1435
-- Name: pk_asset_hardware_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_hardware
    ADD CONSTRAINT pk_asset_hardware_id PRIMARY KEY (hardware_id);


--
-- TOC entry 1920 (class 2606 OID 47931)
-- Dependencies: 1437 1437
-- Name: pk_asset_map_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_map
    ADD CONSTRAINT pk_asset_map_id PRIMARY KEY (map_id);


--
-- TOC entry 1918 (class 2606 OID 47926)
-- Dependencies: 1436 1436
-- Name: pk_asset_software_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_software
    ADD CONSTRAINT pk_asset_software_id PRIMARY KEY (software_id);


--
-- TOC entry 1922 (class 2606 OID 47946)
-- Dependencies: 1438 1438
-- Name: pk_asset_software_license_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_software_licenses
    ADD CONSTRAINT pk_asset_software_license_id PRIMARY KEY (license_id);


--
-- TOC entry 1934 (class 2606 OID 47998)
-- Dependencies: 1444 1444
-- Name: pk_attribute_field_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY attribute_field
    ADD CONSTRAINT pk_attribute_field_id PRIMARY KEY (attribute_field_id);


--
-- TOC entry 1926 (class 2606 OID 47961)
-- Dependencies: 1440 1440
-- Name: pk_attribute_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY attribute
    ADD CONSTRAINT pk_attribute_id PRIMARY KEY (attribute_id);


--
-- TOC entry 1936 (class 2606 OID 48021)
-- Dependencies: 1445 1445
-- Name: pk_blog_post_category_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY blog_post_category
    ADD CONSTRAINT pk_blog_post_category_id PRIMARY KEY (category_id);


--
-- TOC entry 1940 (class 2606 OID 48041)
-- Dependencies: 1447 1447
-- Name: pk_blog_post_comment_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY blog_post_comment
    ADD CONSTRAINT pk_blog_post_comment_id PRIMARY KEY (comment_id);


--
-- TOC entry 1938 (class 2606 OID 48029)
-- Dependencies: 1446 1446
-- Name: pk_blog_post_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY blog_post
    ADD CONSTRAINT pk_blog_post_id PRIMARY KEY (post_id);


--
-- TOC entry 1942 (class 2606 OID 48053)
-- Dependencies: 1448 1448
-- Name: pk_bookmark_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bookmark
    ADD CONSTRAINT pk_bookmark_id PRIMARY KEY (bookmark_id);


--
-- TOC entry 1944 (class 2606 OID 48057)
-- Dependencies: 1449 1449
-- Name: pk_bookmark_map_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY bookmark_map
    ADD CONSTRAINT pk_bookmark_map_id PRIMARY KEY (bookmark_map_id);


--
-- TOC entry 1946 (class 2606 OID 48080)
-- Dependencies: 1450 1450
-- Name: pk_company_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT pk_company_id PRIMARY KEY (company_id);


--
-- TOC entry 1948 (class 2606 OID 48087)
-- Dependencies: 1451 1451
-- Name: pk_company_note_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_note
    ADD CONSTRAINT pk_company_note_id PRIMARY KEY (note_id);


--
-- TOC entry 1950 (class 2606 OID 48096)
-- Dependencies: 1452 1452
-- Name: pk_company_tag_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_tag
    ADD CONSTRAINT pk_company_tag_id PRIMARY KEY (tag_id);


--
-- TOC entry 1956 (class 2606 OID 48139)
-- Dependencies: 1454 1454
-- Name: pk_contact_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY contact
    ADD CONSTRAINT pk_contact_id PRIMARY KEY (contact_id);


--
-- TOC entry 1932 (class 2606 OID 47985)
-- Dependencies: 1443 1443
-- Name: pk_content_local_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY content_local
    ADD CONSTRAINT pk_content_local_id PRIMARY KEY (content_id);


--
-- TOC entry 1930 (class 2606 OID 47981)
-- Dependencies: 1442 1442
-- Name: pk_content_locale_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY content_locale
    ADD CONSTRAINT pk_content_locale_id PRIMARY KEY (locale_id);


--
-- TOC entry 1958 (class 2606 OID 48151)
-- Dependencies: 1455 1455
-- Name: pk_contract_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY contract
    ADD CONSTRAINT pk_contract_id PRIMARY KEY (contract_id);


--
-- TOC entry 1960 (class 2606 OID 48161)
-- Dependencies: 1456 1456
-- Name: pk_file_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file
    ADD CONSTRAINT pk_file_id PRIMARY KEY (file_id);


--
-- TOC entry 1962 (class 2606 OID 48165)
-- Dependencies: 1457 1457
-- Name: pk_file_map_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_map
    ADD CONSTRAINT pk_file_map_id PRIMARY KEY (file_map_id);


--
-- TOC entry 1928 (class 2606 OID 47970)
-- Dependencies: 1441 1441
-- Name: pk_icon_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY icon
    ADD CONSTRAINT pk_icon_id PRIMARY KEY (icon_id);


--
-- TOC entry 1968 (class 2606 OID 48203)
-- Dependencies: 1460 1460
-- Name: pk_issue_change_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY issue_change
    ADD CONSTRAINT pk_issue_change_id PRIMARY KEY (issue_change_id);


--
-- TOC entry 1966 (class 2606 OID 48194)
-- Dependencies: 1459 1459
-- Name: pk_issue_comment_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY issue_comment
    ADD CONSTRAINT pk_issue_comment_id PRIMARY KEY (issue_comment_id);


--
-- TOC entry 1964 (class 2606 OID 48182)
-- Dependencies: 1458 1458
-- Name: pk_issue_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY issue
    ADD CONSTRAINT pk_issue_id PRIMARY KEY (issue_id);


--
-- TOC entry 1977 (class 2606 OID 48253)
-- Dependencies: 1463 1463
-- Name: pk_portal_site_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY portal_site
    ADD CONSTRAINT pk_portal_site_id PRIMARY KEY (site_id);


--
-- TOC entry 1979 (class 2606 OID 48260)
-- Dependencies: 1464 1464
-- Name: pk_rss_feed_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY rss_feed
    ADD CONSTRAINT pk_rss_feed_id PRIMARY KEY (feed_id);


--
-- TOC entry 1981 (class 2606 OID 48267)
-- Dependencies: 1465 1465
-- Name: pk_system_config_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY system_config
    ADD CONSTRAINT pk_system_config_key PRIMARY KEY (config_key);


--
-- TOC entry 1924 (class 2606 OID 47955)
-- Dependencies: 1439 1439
-- Name: pk_system_object_type_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY system_object
    ADD CONSTRAINT pk_system_object_type_id PRIMARY KEY (object_type_id);


--
-- TOC entry 1971 (class 2606 OID 48229)
-- Dependencies: 1461 1461
-- Name: pk_user_id; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_user
    ADD CONSTRAINT pk_user_id PRIMARY KEY (user_id);


--
-- TOC entry 1914 (class 2606 OID 47885)
-- Dependencies: 1433 1433
-- Name: uk_access_page_page_name; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_page
    ADD CONSTRAINT uk_access_page_page_name UNIQUE (page_name);


--
-- TOC entry 1954 (class 2606 OID 48102)
-- Dependencies: 1453 1453 1453
-- Name: uk_company_tag; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_tag_map
    ADD CONSTRAINT uk_company_tag UNIQUE (company_id, tag_id);


--
-- TOC entry 1952 (class 2606 OID 48098)
-- Dependencies: 1452 1452
-- Name: uk_company_tag_name; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_tag
    ADD CONSTRAINT uk_company_tag_name UNIQUE (tag_name);


--
-- TOC entry 1975 (class 2606 OID 48236)
-- Dependencies: 1462 1462 1462
-- Name: uk_issue_subscription_user; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY issue_subscription
    ADD CONSTRAINT uk_issue_subscription_user UNIQUE (issue_id, user_id);


--
-- TOC entry 1973 (class 2606 OID 48231)
-- Dependencies: 1461 1461
-- Name: uk_user_username; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY access_user
    ADD CONSTRAINT uk_user_username UNIQUE (username);


--
-- TOC entry 1969 (class 1259 OID 48232)
-- Dependencies: 1461
-- Name: idx_access_user_password; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_access_user_password ON access_user USING btree ("password");


--
-- TOC entry 1982 (class 1259 OID 48273)
-- Dependencies: 1467
-- Name: idx_user_session_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_user_session_user_id ON user_session USING btree (user_id);


--
-- TOC entry 2019 (class 2606 OID 48496)
-- Dependencies: 1983 1513 1509
-- Name: fk_access_group_perm_perm_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_group_perm_map
    ADD CONSTRAINT fk_access_group_perm_perm_id FOREIGN KEY (perm_id) REFERENCES access_permission(perm_id);


--
-- TOC entry 2020 (class 2606 OID 48501)
-- Dependencies: 1511 1985 1513
-- Name: fk_access_group_perm_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_group_perm_map
    ADD CONSTRAINT fk_access_group_perm_user_id FOREIGN KEY (group_id) REFERENCES access_group(group_id);


--
-- TOC entry 2017 (class 2606 OID 48484)
-- Dependencies: 1512 1985 1511
-- Name: fk_access_group_user_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_group_user_map
    ADD CONSTRAINT fk_access_group_user_group_id FOREIGN KEY (group_id) REFERENCES access_group(group_id);


--
-- TOC entry 2018 (class 2606 OID 48489)
-- Dependencies: 1461 1970 1512
-- Name: fk_access_group_user_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_group_user_map
    ADD CONSTRAINT fk_access_group_user_user_id FOREIGN KEY (user_id) REFERENCES access_user(user_id);


--
-- TOC entry 2016 (class 2606 OID 48460)
-- Dependencies: 1510 1433 1911
-- Name: fk_access_perm_page_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_perm_page_map
    ADD CONSTRAINT fk_access_perm_page_page_id FOREIGN KEY (page_id) REFERENCES access_page(page_id);


--
-- TOC entry 2015 (class 2606 OID 48455)
-- Dependencies: 1510 1509 1983
-- Name: fk_access_perm_page_perm_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_perm_page_map
    ADD CONSTRAINT fk_access_perm_page_perm_id FOREIGN KEY (perm_id) REFERENCES access_permission(perm_id);


--
-- TOC entry 1987 (class 2606 OID 48465)
-- Dependencies: 1983 1434 1509
-- Name: fk_access_user_perm_perm_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_user_perm_map
    ADD CONSTRAINT fk_access_user_perm_perm_id FOREIGN KEY (perm_id) REFERENCES access_permission(perm_id);


--
-- TOC entry 1988 (class 2606 OID 48470)
-- Dependencies: 1434 1970 1461
-- Name: fk_access_user_perm_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY access_user_perm_map
    ADD CONSTRAINT fk_access_user_perm_user_id FOREIGN KEY (user_id) REFERENCES access_user(user_id);


--
-- TOC entry 1989 (class 2606 OID 47932)
-- Dependencies: 1915 1435 1437
-- Name: fk_asset_map_hardware_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_map
    ADD CONSTRAINT fk_asset_map_hardware_id FOREIGN KEY (hardware_id) REFERENCES asset_hardware(hardware_id);


--
-- TOC entry 1990 (class 2606 OID 47937)
-- Dependencies: 1436 1917 1437
-- Name: fk_asset_map_software_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_map
    ADD CONSTRAINT fk_asset_map_software_id FOREIGN KEY (software_id) REFERENCES asset_software(software_id);


--
-- TOC entry 1991 (class 2606 OID 47947)
-- Dependencies: 1436 1917 1438
-- Name: fk_asset_software_licenses_software_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_software_licenses
    ADD CONSTRAINT fk_asset_software_licenses_software_id FOREIGN KEY (software_id) REFERENCES asset_software(software_id);


--
-- TOC entry 1996 (class 2606 OID 48004)
-- Dependencies: 1444 1925 1440
-- Name: fk_attribute_field_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute_field
    ADD CONSTRAINT fk_attribute_field_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute(attribute_id);


--
-- TOC entry 1997 (class 2606 OID 48009)
-- Dependencies: 1443 1931 1444
-- Name: fk_attribute_field_content_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute_field
    ADD CONSTRAINT fk_attribute_field_content_id FOREIGN KEY (content_id) REFERENCES content_local(content_id);


--
-- TOC entry 1995 (class 2606 OID 47999)
-- Dependencies: 1441 1444 1927
-- Name: fk_attribute_field_icon_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute_field
    ADD CONSTRAINT fk_attribute_field_icon_id FOREIGN KEY (icon_id) REFERENCES icon(icon_id);


--
-- TOC entry 1992 (class 2606 OID 47962)
-- Dependencies: 1440 1923 1439
-- Name: fk_attribute_object_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY attribute
    ADD CONSTRAINT fk_attribute_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object(object_type_id);


--
-- TOC entry 1998 (class 2606 OID 48030)
-- Dependencies: 1445 1446 1935
-- Name: fk_blog_post_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY blog_post
    ADD CONSTRAINT fk_blog_post_category_id FOREIGN KEY (category_id) REFERENCES blog_post_category(category_id);


--
-- TOC entry 2000 (class 2606 OID 48058)
-- Dependencies: 1449 1448 1941
-- Name: fk_bookmark_map_bookmark_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bookmark_map
    ADD CONSTRAINT fk_bookmark_map_bookmark_id FOREIGN KEY (bookmark_id) REFERENCES bookmark(bookmark_id);


--
-- TOC entry 2001 (class 2606 OID 48063)
-- Dependencies: 1439 1449 1923
-- Name: fk_bookmark_map_object_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY bookmark_map
    ADD CONSTRAINT fk_bookmark_map_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object(object_type_id);


--
-- TOC entry 2002 (class 2606 OID 48088)
-- Dependencies: 1450 1451 1945
-- Name: fk_company_note_company_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_note
    ADD CONSTRAINT fk_company_note_company_id FOREIGN KEY (company_id) REFERENCES company(company_id);


--
-- TOC entry 2003 (class 2606 OID 48103)
-- Dependencies: 1450 1945 1453
-- Name: fk_company_tag_map_company_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tag_map
    ADD CONSTRAINT fk_company_tag_map_company_id FOREIGN KEY (company_id) REFERENCES company(company_id);


--
-- TOC entry 2004 (class 2606 OID 48108)
-- Dependencies: 1453 1452 1949
-- Name: fk_company_tag_map_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_tag_map
    ADD CONSTRAINT fk_company_tag_map_tag_id FOREIGN KEY (tag_id) REFERENCES company_tag(tag_id);


--
-- TOC entry 2005 (class 2606 OID 48140)
-- Dependencies: 1945 1450 1454
-- Name: fk_contact_company_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY contact
    ADD CONSTRAINT fk_contact_company_id FOREIGN KEY (company_id) REFERENCES company(company_id);


--
-- TOC entry 1994 (class 2606 OID 47986)
-- Dependencies: 1442 1929 1443
-- Name: fk_content_local_locale_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY content_local
    ADD CONSTRAINT fk_content_local_locale_id FOREIGN KEY (locale_id) REFERENCES content_locale(locale_id);


--
-- TOC entry 2006 (class 2606 OID 48166)
-- Dependencies: 1457 1456 1959
-- Name: fk_file_map_locale_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_map
    ADD CONSTRAINT fk_file_map_locale_id FOREIGN KEY (file_id) REFERENCES file(file_id);


--
-- TOC entry 2007 (class 2606 OID 48171)
-- Dependencies: 1923 1439 1457
-- Name: fk_file_map_object_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_map
    ADD CONSTRAINT fk_file_map_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object(object_type_id);


--
-- TOC entry 1993 (class 2606 OID 47971)
-- Dependencies: 1925 1440 1441
-- Name: fk_icon_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY icon
    ADD CONSTRAINT fk_icon_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute(attribute_id);


--
-- TOC entry 2011 (class 2606 OID 48209)
-- Dependencies: 1460 1456 1959
-- Name: fk_issue_change_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_change
    ADD CONSTRAINT fk_issue_change_file_id FOREIGN KEY (file_id) REFERENCES file(file_id);


--
-- TOC entry 2012 (class 2606 OID 48214)
-- Dependencies: 1965 1460 1459
-- Name: fk_issue_change_issue_comment_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_change
    ADD CONSTRAINT fk_issue_change_issue_comment_id FOREIGN KEY (issue_comment_id) REFERENCES issue_comment(issue_comment_id);


--
-- TOC entry 2010 (class 2606 OID 48204)
-- Dependencies: 1460 1458 1963
-- Name: fk_issue_change_issue_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_change
    ADD CONSTRAINT fk_issue_change_issue_id FOREIGN KEY (issue_id) REFERENCES issue(issue_id);


--
-- TOC entry 2008 (class 2606 OID 48183)
-- Dependencies: 1458 1458 1963
-- Name: fk_issue_duplicate_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue
    ADD CONSTRAINT fk_issue_duplicate_id FOREIGN KEY (duplicate_id) REFERENCES issue(issue_id);


--
-- TOC entry 2014 (class 2606 OID 48242)
-- Dependencies: 1458 1963 1462
-- Name: fk_issue_subscription_issue_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_subscription
    ADD CONSTRAINT fk_issue_subscription_issue_id FOREIGN KEY (issue_id) REFERENCES issue(issue_id);


--
-- TOC entry 2013 (class 2606 OID 48237)
-- Dependencies: 1461 1970 1462
-- Name: fk_issue_subscription_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_subscription
    ADD CONSTRAINT fk_issue_subscription_user_id FOREIGN KEY (user_id) REFERENCES access_user(user_id);


--
-- TOC entry 1999 (class 2606 OID 48042)
-- Dependencies: 1446 1447 1937
-- Name: fk_portal_blog_post_comment_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY blog_post_comment
    ADD CONSTRAINT fk_portal_blog_post_comment_post_id FOREIGN KEY (post_id) REFERENCES blog_post(post_id);


--
-- TOC entry 2009 (class 2606 OID 48195)
-- Dependencies: 1963 1459 1458
-- Name: issue_comment_issue_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY issue_comment
    ADD CONSTRAINT issue_comment_issue_id_fk FOREIGN KEY (issue_id) REFERENCES issue(issue_id);


--
-- Upgrading to 2.6.0
--

update system_config set config_value = '2.6.0' where config_key = 'schema.version';

delete from system_config where config_key = 'rp.authPackages';

delete from system_config where config_key = 'rp.packages';

update system_config set config_value = '13,1,2,4,5,3,6,8,7' where config_key = 'template.showModules';

update system_config set config_key = 'template.moduleTabs' where config_key = 'template.showModules';

drop function if exists sp_user_logout(in p_user_id int);

alter table attribute_field add attribute_field_name character varying(50);

update attribute_field set attribute_field_name = content_local from content_local where content_local.content_id=attribute_field.content_id;

drop view if exists attribute_field_view;

alter table attribute_field drop column content_id;

drop table content_local;

drop sequence seq_content_local_id;

update access_permission set perm_name='rss_write', order_num=47 where perm_id=18;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (20, 'rss_read', '', 1, 46);

insert into access_perm_page_map(perm_id, page_id) values (20, 188);
insert into access_perm_page_map(perm_id, page_id) values (20, 187);
insert into access_perm_page_map(perm_id, page_id) values (20, 186);
insert into access_perm_page_map(perm_id, page_id) values (20, 179);

update access_permission set perm_name='blog_write', order_num=44 where perm_id=16;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (21, 'blog_read', '', 1, 43);

insert into access_perm_page_map(perm_id, page_id) values (21, 134);
insert into access_perm_page_map(perm_id, page_id) values (21, 140);
insert into access_perm_page_map(perm_id, page_id) values (21, 133);
insert into access_perm_page_map(perm_id, page_id) values (21, 118);

update access_permission set perm_name='blog_admin', order_num=45 where perm_id=19;

delete from access_perm_page_map where perm_id=15;
insert into access_perm_page_map(perm_id, page_id) values (15, 119);
insert into access_perm_page_map(perm_id, page_id) values (15, 132);

delete from access_perm_page_map where perm_id=5;
delete from access_user_perm_map where perm_id=5;
delete from access_permission where perm_id=5;

delete from access_perm_page_map where perm_id=7;
delete from access_user_perm_map where perm_id=7;
delete from access_permission where perm_id=7;

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (22, 'hardware_write', '', 1, 34);
insert into access_perm_page_map(perm_id, page_id) values (22, 20);
insert into access_perm_page_map(perm_id, page_id) values (22, 21);
insert into access_perm_page_map(perm_id, page_id) values (22, 22);
insert into access_perm_page_map(perm_id, page_id) values (22, 23);
insert into access_perm_page_map(perm_id, page_id) values (22, 24);
insert into access_perm_page_map(perm_id, page_id) values (22, 25);
insert into access_perm_page_map(perm_id, page_id) values (22, 27);

insert into access_perm_page_map(perm_id, page_id) values (22, 45);
insert into access_perm_page_map(perm_id, page_id) values (22, 46);
insert into access_perm_page_map(perm_id, page_id) values (22, 47);
insert into access_perm_page_map(perm_id, page_id) values (22, 141);
insert into access_perm_page_map(perm_id, page_id) values (22, 142);
insert into access_perm_page_map(perm_id, page_id) values (22, 145);
insert into access_perm_page_map(perm_id, page_id) values (22, 146);

INSERT INTO access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (23, 'software_write', '', 1, 36);

insert into access_perm_page_map(perm_id, page_id) values (23, 31);
insert into access_perm_page_map(perm_id, page_id) values (23, 30);
insert into access_perm_page_map(perm_id, page_id) values (23, 94);
insert into access_perm_page_map(perm_id, page_id) values (23, 93);
insert into access_perm_page_map(perm_id, page_id) values (23, 98);
insert into access_perm_page_map(perm_id, page_id) values (23, 97);
insert into access_perm_page_map(perm_id, page_id) values (23, 96);
insert into access_perm_page_map(perm_id, page_id) values (23, 95);
insert into access_perm_page_map(perm_id, page_id) values (23, 32);
insert into access_perm_page_map(perm_id, page_id) values (23, 38);
insert into access_perm_page_map(perm_id, page_id) values (23, 37);
insert into access_perm_page_map(perm_id, page_id) values (23, 36);
insert into access_perm_page_map(perm_id, page_id) values (23, 110);
insert into access_perm_page_map(perm_id, page_id) values (23, 109);
insert into access_perm_page_map(perm_id, page_id) values (23, 114);
insert into access_perm_page_map(perm_id, page_id) values (23, 113);
insert into access_perm_page_map(perm_id, page_id) values (23, 33);
insert into access_perm_page_map(perm_id, page_id) values (23, 39);
insert into access_perm_page_map(perm_id, page_id) values (23, 35);
insert into access_perm_page_map(perm_id, page_id) values (23, 44);
insert into access_perm_page_map(perm_id, page_id) values (23, 34);
insert into access_perm_page_map(perm_id, page_id) values (23, 40);

update access_permission set perm_name='hardware_read' where perm_id=6;
update access_permission set perm_name='software_read' where perm_id=8;

insert into access_page (page_id, page_name, page_description) values (200, '/IT/software-index.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (8, 200);

delete from access_perm_page_map where perm_id=9 and page_id not in (170,171,172,173,174,175);
delete from access_perm_page_map where perm_id=12 and page_id not in(168,169);

update access_permission set perm_name='contract_read', order_num=37 where perm_id=12;
update access_permission set perm_name='contract_write', order_num=38 where perm_id=9;

update access_page set page_name = '/IT/hardware-index.dll' where page_id=17;

insert into system_config (config_key, config_value) values ('company.footerNotes', '');

update system_config set config_key='blogs.numberOfPostCharsToShow' where config_key='portal.numberOfBlogPostCharactersOnList';
update system_config set config_key='blogs.numberOfPostsToShow' where config_key='portal.numberOfBlogPostsToShowOnList';
delete from system_config where config_key='portal.numberOfBlogPostCharactersOnMain';
delete from system_config where config_key='portal.numberOfBlogPostsToShowOnMain';

insert into system_config (config_key, config_value) values ('home.customDescription', '');

--
-- Upgrading to 2.6.1
--
update system_config set config_value = '2.6.1' where config_key = 'schema.version';

drop view if exists portal_site_view;

DROP FUNCTION if exists sp_site_add(out o_site_id int, in p_site_name varchar(100), in p_site_path varchar(225), in p_site_description text, in p_site_is_public int, in p_site_support_iframe int, in p_creator int);
DROP FUNCTION if exists sp_site_update(p_site_id integer, p_site_name character varying, p_site_path character varying, p_site_description text, p_site_is_public integer, p_site_support_iframe integer, p_modifier integer);

ALTER TABLE portal_site rename COLUMN site_is_public to site_placement;

insert into access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (24, 'blog_comment', '', 1, 45);

insert into access_perm_page_map(perm_id, page_id) values (24, 139);

INSERT INTO system_config (config_key, config_value) VALUES ('file.contract.repositoryPath', 'C:\\Kwok\\Server\\FileRepo\\contract');
INSERT INTO system_config (config_key, config_value) VALUES ('file.contract.uploadFilePrefix', 'CONTRACT-');

insert into access_page values (201, '/IT/contract-file-download.dll', '');
insert into access_page values (202, '/IT/contract-file-add.dll', '');
insert into access_page values (203, '/IT/contract-file-add-2.dll', '');
insert into access_page values (204, '/IT/contract-file-delete.dll', '');
insert into access_page values (205, '/IT/contract-file-delete-2.dll', '');

insert into access_perm_page_map(perm_id, page_id) values (12, 201);
insert into access_perm_page_map(perm_id, page_id) values (9, 202);
insert into access_perm_page_map(perm_id, page_id) values (9, 203);
insert into access_perm_page_map(perm_id, page_id) values (9, 204);
insert into access_perm_page_map(perm_id, page_id) values (9, 205);

--
-- Upgrading to 2.6.2
--
update system_config set config_value = '2.6.2' where config_key = 'schema.version';

DROP FUNCTION if exists sp_software_license_delete(p_software_id integer, p_license_id integer);

insert into access_page (page_id, page_name, page_description) values (206, '/IT/contract-hardware.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (12, 206);

insert into access_page (page_id, page_name, page_description) values (207, '/IT/contract-hardware-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 207);

insert into access_page (page_id, page_name, page_description) values (208, '/IT/contract-hardware-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 208);

insert into access_page (page_id, page_name, page_description) values (209, '/IT/contract-hardware-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (9, 209);

CREATE TABLE contract_hardware_map (
    contract_id integer NOT NULL,
    hardware_id integer NOT NULL,
    creator integer,
    creation_date timestamp(1) without time zone
);

ALTER TABLE ONLY contract_hardware_map
    ADD CONSTRAINT fk_contract_id FOREIGN KEY (contract_id) REFERENCES contract(contract_id);

ALTER TABLE ONLY contract_hardware_map
    ADD CONSTRAINT fk_contract_hardware_id FOREIGN KEY (hardware_id) REFERENCES asset_hardware(hardware_id);

alter table contract_hardware_map add CONSTRAINT uk_contract_hardware_id unique (contract_id, hardware_id);
alter table user_session add CONSTRAINT uk_user_session_user_id unique (user_id);
alter table access_group_perm_map add CONSTRAINT uk_group_perm_id unique (group_id, perm_id);
alter table access_group_user_map add CONSTRAINT uk_group_user_id unique (group_id, user_id);
alter table access_perm_page_map add CONSTRAINT uk_perm_page_id unique (perm_id, page_id);
alter table access_user_perm_map add CONSTRAINT uk_user_perm_id unique (user_id, perm_id);

update access_page set page_name = '/portal/blog-category-add.dll' where page_name = '/portal/blog-post-category-add.dll';
update access_page set page_name = '/portal/blog-category-add-2.dll' where page_name = '/portal/blog-post-category-add-2.dll';
update access_page set page_name = '/portal/blog-category-edit.dll' where page_name = '/portal/blog-post-category-edit.dll';
update access_page set page_name = '/portal/blog-category-edit-2.dll' where page_name = '/portal/blog-post-category-edit-2.dll';

insert into access_page (page_id, page_name, page_description) values (210, '/portal/blog-category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (19, 210);

--
-- Upgrading to 2.6.3
--
update system_config set config_value = '2.6.3' where config_key = 'schema.version';

insert into system_config (config_key, config_value) values ('datetime.numberOfPastYears',4);
insert into system_config (config_key, config_value) values ('datetime.numberOfUpcomingYears',4);

insert into system_config (config_key, config_value) values ('portal.columnList','site_name,site_path,site_placement,site_support_iframe');
insert into system_config (config_key, config_value) values ('contacts.companyColumnList','company_name');
insert into system_config (config_key, config_value) values ('contacts.columnList','contact_first_name,contact_last_name,contact_title,company_name');
insert into system_config (config_key, config_value) values ('issues.columnList','issue_id,issue_name,issue_status,issue_priority,assignee_name,creation_date');
insert into system_config (config_key, config_value) values ('hardware.columnList','hardware_name,hardware_model_name,hardware_last_service_date,hardware_owner_name');
insert into system_config (config_key, config_value) values ('software.columnList','software_name,software_manufacturer');
insert into system_config (config_key, config_value) values ('contracts.columnList','contract_name,contract_expiration_date,contract_effective_date');

alter table attribute_field add column is_disabled smallint;

drop view if exists attribute_field_view;

DROP FUNCTION if exists sp_attribute_field_add(OUT o_attribute_field_id integer, IN p_attribute_id integer, IN p_attribute_field_name character varying, IN p_attribute_field_description text, IN p_icon_id integer);
DROP FUNCTION if exists sp_attribute_field_update(p_attribute_id integer, p_attribute_field_id integer, p_attribute_field_name character varying, p_attribute_field_description text, p_icon_id integer);

--
-- Upgrading to 2.6.4
--
update system_config set config_value = '2.6.4' where config_key = 'schema.version';

drop view if exists attribute_view;
drop view if exists blog_post_category_view;
drop view if exists portal_site_view;

DROP FUNCTION if exists sp_blog_post_category_update(p_category_id integer, p_category_name character varying, p_category_description text, p_modifier integer);
DROP FUNCTION if exists sp_blog_post_category_add(OUT o_category_id integer, IN p_category_name character varying, IN p_category_description text, IN p_creator integer);
DROP FUNCTION if exists sp_site_update(p_site_id integer, p_site_name character varying, p_site_path character varying, p_site_description text, p_site_placement integer, p_site_support_iframe integer, p_modifier integer);
DROP FUNCTION if exists sp_site_add(OUT o_site_id integer, IN p_site_name character varying, IN p_site_path character varying, IN p_site_description text, IN p_site_placement integer, IN p_site_support_iframe integer, IN p_creator integer);

insert into system_object (object_type_id, object_key) values (10, 'company_main_contact');
insert into system_object (object_type_id, object_key) values (11, 'company_emp_contact');
insert into system_object (object_type_id, object_key) values (12, 'blog_post');
insert into system_object (object_type_id, object_key) values (13, 'portal_site');

-- This column has never been used
alter table attribute drop column "type";

-- Renaming constraint
ALTER TABLE issue_comment drop CONSTRAINT issue_comment_issue_id_fk;
ALTER TABLE issue_comment ADD CONSTRAINT fk_issue_comment_issue_id FOREIGN KEY (issue_id) REFERENCES issue(issue_id);

alter table blog_post_category rename to category;

alter table portal_site add column category_id integer NOT NULL;

ALTER TABLE portal_site ADD CONSTRAINT fk_portal_site_category_id FOREIGN KEY (category_id) REFERENCES category(category_id);

alter table category add column object_type_id integer;
update category set object_type_id=12;
alter table category alter column object_type_id set NOT NULL;
alter table category add CONSTRAINT fk_category_object_type_id FOREIGN KEY (object_type_id) REFERENCES system_object (object_type_id);

INSERT INTO category (category_id, category_name, category_description, object_type_id, count_post, creator, creation_date, modifier, modification_date) 
VALUES (nextval('seq_blog_post_category_id'), 'Uncategorized', '', 13, 0, 1, now(), NULL, NULL);

update portal_site set category_id=currval('seq_blog_post_category_id');

insert into access_permission (perm_id, perm_name, perm_description, perm_is_enabled, order_num) VALUES (25, 'portal_admin', '', 1, 43);

insert into access_page (page_id, page_name, page_description) values (211, '/portal/site-category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 211);
insert into access_page (page_id, page_name, page_description) values (212, '/portal/site-category-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 212);
insert into access_page (page_id, page_name, page_description) values (213, '/portal/site-category-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 213);
insert into access_page (page_id, page_name, page_description) values (214, '/portal/site-category-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 214);
insert into access_page (page_id, page_name, page_description) values (215, '/portal/site-category-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (25, 215);

update access_perm_page_map set perm_id = 25 where page_id in (127, 120, 122, 121, 126, 125, 124, 123);
update access_page set page_name = '/portal/site-list-index.dll' where page_id = 132;
update access_page set page_name = replace(page_name, 'admin/portal-', 'portal/') where page_id in (127, 120, 122, 121, 126, 125, 124, 123);

update system_config set config_value = 'en_US,es_ES,it_IT,sr,zh_CN' where config_key='locale.options';

--
-- Upgrading to 2.6.5
--
-- Chnage access_user column type to make it work for Postgres 8.3.0
alter table access_user add column new_status smallint DEFAULT 1::smallint;
update access_user set new_status=to_number(status, text(99999999));
alter table access_user drop column status;

alter table access_user add column status smallint DEFAULT 1::smallint;
update access_user set status=new_status;
alter table access_user drop column new_status;

update system_config set config_value = '2.6.5' where config_key = 'schema.version';

drop view if exists user_view;
drop view if exists attribute_view;

-- 1 means custom attribute, 0 means non custom attribute.
alter table attribute add column is_custom_attr smallint DEFAULT 1::smallint;
update attribute set is_custom_attr=0;

CREATE TABLE attribute_value (
    attribute_id integer NOT NULL,
	attr_value text NOT NULL,
    object_id integer NOT NULL
);

ALTER TABLE attribute_value ADD CONSTRAINT fk_attr_value_attr_id FOREIGN KEY (attribute_id) REFERENCES attribute(attribute_id);

-- Updating system attribute_id to negative numbers
alter table icon drop CONSTRAINT fk_icon_attribute_id;
alter table attribute_field drop CONSTRAINT fk_attribute_field_attribute_id;

update attribute set attribute_id=-1 where attribute_id=1;
update attribute set attribute_id=-2 where attribute_id=2;
update attribute set attribute_id=-3 where attribute_id=3;
update attribute set attribute_id=-4 where attribute_id=4;
update attribute set attribute_id=-5 where attribute_id=5;
update attribute set attribute_id=-6 where attribute_id=6;
update attribute set attribute_id=-7 where attribute_id=7;
update attribute set attribute_id=-8 where attribute_id=8;
update attribute set attribute_id=-10 where attribute_id=10;
update attribute set attribute_id=-11 where attribute_id=11;
update attribute set attribute_id=-12 where attribute_id=12;
update attribute set attribute_id=-13 where attribute_id=13;
update attribute set attribute_id=-14 where attribute_id=14;
update attribute set attribute_id=-15 where attribute_id=15;
update attribute set attribute_id=-16 where attribute_id=16;

update attribute_field set attribute_id=-1 where attribute_id=1;
update attribute_field set attribute_id=-2 where attribute_id=2;
update attribute_field set attribute_id=-3 where attribute_id=3;
update attribute_field set attribute_id=-4 where attribute_id=4;
update attribute_field set attribute_id=-5 where attribute_id=5;
update attribute_field set attribute_id=-6 where attribute_id=6;
update attribute_field set attribute_id=-7 where attribute_id=7;
update attribute_field set attribute_id=-8 where attribute_id=8;
update attribute_field set attribute_id=-10 where attribute_id=10;
update attribute_field set attribute_id=-11 where attribute_id=11;
update attribute_field set attribute_id=-12 where attribute_id=12;
update attribute_field set attribute_id=-13 where attribute_id=13;
update attribute_field set attribute_id=-14 where attribute_id=14;
update attribute_field set attribute_id=-15 where attribute_id=15;
update attribute_field set attribute_id=-16 where attribute_id=16;

update icon set attribute_id=-1 where attribute_id=1;
update icon set attribute_id=-2 where attribute_id=2;
update icon set attribute_id=-3 where attribute_id=3;
update icon set attribute_id=-4 where attribute_id=4;
update icon set attribute_id=-5 where attribute_id=5;
update icon set attribute_id=-6 where attribute_id=6;
update icon set attribute_id=-7 where attribute_id=7;
update icon set attribute_id=-8 where attribute_id=8;
update icon set attribute_id=-10 where attribute_id=10;
update icon set attribute_id=-11 where attribute_id=11;
update icon set attribute_id=-12 where attribute_id=12;
update icon set attribute_id=-13 where attribute_id=13;
update icon set attribute_id=-14 where attribute_id=14;
update icon set attribute_id=-15 where attribute_id=15;
update icon set attribute_id=-16 where attribute_id=16;

alter table icon add CONSTRAINT fk_icon_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute (attribute_id);
alter table attribute_field add CONSTRAINT fk_attribute_field_attribute_id FOREIGN KEY (attribute_id) REFERENCES attribute (attribute_id);

insert into access_page (page_id, page_name, page_description) values (216, '/admin/usage-survey.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 216);

-- Add unique constraint to attribute_value table
alter table attribute_value add CONSTRAINT uk_attribute_value_attr_obj_id UNIQUE (attribute_id, object_id);

-- For custom fields
insert into access_page (page_id, page_name, page_description) values (217, '/admin/cust-attr.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (3, 217);

insert into access_page (page_id, page_name, page_description) values (218, '/admin/cust-attr-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 218);

insert into access_page (page_id, page_name, page_description) values (219, '/admin/cust-attr-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 219);

insert into access_page (page_id, page_name, page_description) values (220, '/admin/cust-attr-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 220);

insert into access_page (page_id, page_name, page_description) values (221, '/admin/cust-attr-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 221);

insert into access_page (page_id, page_name, page_description) values (222, '/admin/cust-attr-delete.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 222);

insert into access_page (page_id, page_name, page_description) values (223, '/admin/cust-attr-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (4, 223);

insert into access_page (page_id, page_name, page_description) values (224, '/admin/cust-attr-detail.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (3, 224);

CREATE SEQUENCE seq_attribute_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

delete from system_config where config_key='default.serviceName';
insert into system_config (config_key, config_value) values ('usage.survey', 0);

--
-- Upgrading to 2.6.6
--
update system_config set config_value = '2.6.6' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

insert into attribute (attribute_id, object_type_id, attribute_key, is_optional, is_editable, is_custom_attr) values (-17, 2, 'hardware_component_type', 1, 1, 0);

insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Hard Disk');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'CD/DVD Drive');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Network Card');
insert into attribute_field (attribute_field_id, attribute_id, field_key, attribute_field_name) values (nextval('seq_attribute_field_id'), -17, '', 'Memory');

-- list, add, add-2, edit, edit-2, delete-2
insert into access_page (page_id, page_name, page_description) values (225, '/IT/hardware-comp.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (6, 225);

insert into access_page (page_id, page_name, page_description) values (226, '/IT/hardware-comp-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 226);

insert into access_page (page_id, page_name, page_description) values (227, '/IT/hardware-comp-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 227);

insert into access_page (page_id, page_name, page_description) values (228, '/IT/hardware-comp-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 228);

insert into access_page (page_id, page_name, page_description) values (229, '/IT/hardware-comp-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 229);

insert into access_page (page_id, page_name, page_description) values (230, '/IT/hardware-comp-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 230);

CREATE TABLE asset_hardware_component (
  comp_id integer NOT NULL,
  comp_description text,
  hardware_id integer NOT NULL,
  hardware_component_type integer,
  creator integer,
  creation_date timestamp(1) without time zone,
  modifier integer,
  modification_date timestamp(1) without time zone,
  CONSTRAINT pk_asset_hardware_comp_id PRIMARY KEY (comp_id),
  CONSTRAINT fk_asset_hardware_comp_hardware_id FOREIGN KEY (hardware_id)
      REFERENCES asset_hardware (hardware_id) 
);

CREATE SEQUENCE seq_asset_hardware_comp_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

-- Remove hardware index page from software read permission.
delete from access_perm_page_map where perm_id=8 and page_id=17;

alter table asset_hardware add count_component integer DEFAULT 0;

drop view if exists asset_hardware_view; 

-- Add date format for UK users
update system_config set config_value='M/d/yyyy,MM/dd/yyyy,d/M/yyyy,dd/MM/yyyy,yyyy-MM-dd' where config_key='datetime.shortDateFormat.options';

-- Re-purpose contract_hardware_map table for object linking
CREATE TABLE object_map (
  object_id integer NOT NULL,
  object_type_id integer NOT NULL,
  linked_object_id integer NOT NULL,
  linked_object_type_id integer NOT NULL,
  creator integer,
  creation_date timestamp(1) without time zone,
  CONSTRAINT fk_object_map_object_type_id FOREIGN KEY (object_type_id)
      REFERENCES system_object (object_type_id),
  CONSTRAINT fk_object_map_linked_object_type_id FOREIGN KEY (linked_object_type_id)
      REFERENCES system_object (object_type_id),
  CONSTRAINT uk_object_map UNIQUE (object_id, object_type_id, linked_object_id, linked_object_type_id)
);

insert into object_map (object_id, object_type_id, linked_object_id, linked_object_type_id, creator, creation_date) select contract_id, 9, hardware_id, 2, creator, creation_date from contract_hardware_map;

drop table contract_hardware_map;

DROP FUNCTION if exists sp_contract_hardware_delete(p_contract_id integer, p_hardware_id integer);
DROP FUNCTION if exists sp_contract_hardware_add(in p_contract_id int, in p_hardware_id int, in p_creator int);
DROP FUNCTION if exists sp_contract_delete(p_contract_id integer);
DROP FUNCTION if exists sp_attribute_value_delete(p_object_type_id int, p_object_id int);

insert into access_page (page_id, page_name, page_description) values (231, '/IT/hardware-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (6, 231);

insert into access_page (page_id, page_name, page_description) values (232, '/IT/hardware-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 232);

insert into access_page (page_id, page_name, page_description) values (233, '/IT/hardware-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 233);

insert into access_page (page_id, page_name, page_description) values (234, '/IT/hardware-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (22, 234);

-- Software Issues pages
insert into access_page (page_id, page_name, page_description) values (235, '/IT/software-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (8, 235);

insert into access_page (page_id, page_name, page_description) values (236, '/IT/software-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 236);

insert into access_page (page_id, page_name, page_description) values (237, '/IT/software-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 237);

insert into access_page (page_id, page_name, page_description) values (238, '/IT/software-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (23, 238);

-- For cleaning up orphan data, contract deletion wasn't deleting file_map records before
delete from file_map where object_type_id=9 and object_id not in (select contract_id from contract);
delete from file where file_id not in (select file_id from file_map);

-- Company Issues pages
insert into access_page (page_id, page_name, page_description) values (239, '/contact-mgmt/company-issue.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (10, 239);

insert into access_page (page_id, page_name, page_description) values (240, '/contact-mgmt/company-issue-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 240);

insert into access_page (page_id, page_name, page_description) values (241, '/contact-mgmt/company-issue-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 241);

insert into access_page (page_id, page_name, page_description) values (242, '/contact-mgmt/company-issue-remove-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (11, 242);

-- drop /portal/rss-feed-list-description
delete from access_perm_page_map where page_id=188;
delete from access_page where page_id=188;

-- Add new Hungarian localization
update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,sr_YU,zh_CN' where config_key='locale.options';
update system_config set config_value = 'sr_YU' where config_key='locale' and config_value='sr';

--
-- Upgrading to 2.6.7
--
update system_config set config_value = '2.6.7' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

-- Added new Dutch locale
update system_config set config_value = 'en_US,es_ES,hu_HU,it_IT,nl_NL,sr_YU,zh_CN' where config_key='locale.options';

CREATE TABLE kb_article (
  article_id bigint NOT NULL,
  article_name character varying(100) NOT NULL,
  article_text text,
  category_id integer NOT NULL,
  creator integer,
  creation_date timestamp(1) without time zone,
  modifier integer,
  modification_date timestamp(1) without time zone,
  CONSTRAINT pk_kb_article_id PRIMARY KEY (article_id),
  CONSTRAINT fk_kb_article_category_id FOREIGN KEY (category_id) REFERENCES category (category_id) 
);

insert into system_object (object_type_id, object_key) values (14, 'kb_article');

-- Bump up some order numbers
update access_permission set order_num = order_num+100 where order_num>40;

-- New permissions for KB module
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (26, 'kb_read', 1, 80);
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (27, 'kb_write', 1, 81);
insert into access_permission (perm_id, perm_name, perm_is_enabled, order_num) values (28, 'kb_admin', 1, 82);

insert into access_page (page_id, page_name, page_description) values (243, '/kb/index.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 243);
insert into access_page (page_id, page_name, page_description) values (244, '/kb/article-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 244);
insert into access_page (page_id, page_name, page_description) values (245, '/kb/article-detail.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (26, 245);

insert into access_page (page_id, page_name, page_description) values (246, '/kb/article-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 246);
insert into access_page (page_id, page_name, page_description) values (247, '/kb/article-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 247);
insert into access_page (page_id, page_name, page_description) values (248, '/kb/article-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 248);
insert into access_page (page_id, page_name, page_description) values (249, '/kb/article-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 249);

insert into access_page (page_id, page_name, page_description) values (250, '/kb/category-list.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 250);
insert into access_page (page_id, page_name, page_description) values (251, '/kb/category-add.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 251);
insert into access_page (page_id, page_name, page_description) values (252, '/kb/category-add-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 252);
insert into access_page (page_id, page_name, page_description) values (253, '/kb/category-edit.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 253);
insert into access_page (page_id, page_name, page_description) values (254, '/kb/category-edit-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (28, 254);

insert into access_page (page_id, page_name, page_description) values (255, '/kb/article-delete.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 255);
insert into access_page (page_id, page_name, page_description) values (256, '/kb/article-delete-2.dll', '');
insert into access_perm_page_map(perm_id, page_id) values (27, 256);

update system_config set config_value='13,1,2,4,14,5,3,6,8,7' where config_key='template.moduleTabs';

insert into category (category_id, category_name, category_description, count_post, creator, creation_date, object_type_id)
	values (nextval('seq_blog_post_category_id'), 'Uncategorized', '', 0, 1, now(), 14);

CREATE TABLE kb_article_archive (
  article_id bigint NOT NULL,
  article_name character varying(100) NOT NULL,
  article_text text,
  category_id integer NOT NULL,
  archiver integer,
  archive_date timestamp(1) without time zone,
  CONSTRAINT fk_kb_article_archive_article_id FOREIGN KEY (article_id) REFERENCES kb_article (article_id),
  CONSTRAINT fk_kb_article_archive_category_id FOREIGN KEY (category_id) REFERENCES category (category_id) 
);

CREATE SEQUENCE seq_kb_article_id
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

--
-- Upgrading to 2.6.8
--
update system_config set config_value = '2.6.8' where config_key = 'schema.version';

update system_config set config_value=0 where config_key='usage.survey';

drop view if exists asset_hardware_view;
drop view if exists asset_software_view;
drop view if exists company_view;
drop view if exists category_view;
drop view if exists blog_post_view;
drop view if exists contract_view;

DROP FUNCTION if exists sp_contract_add(OUT o_contract_id integer, IN p_contract_name character varying, IN p_contract_description text, IN p_contract_type integer, IN p_contract_effective_date character varying, IN p_contract_expiration_date character varying, IN p_contract_renewal_date character varying, IN p_contract_renewal_type integer, IN p_creator integer);
DROP FUNCTION if exists sp_contract_update(p_contract_id integer, p_contract_name character varying, p_contract_description text, p_contract_type integer, p_contract_effective_date character varying, p_contract_expiration_date character varying, p_contract_renewal_date character varying, p_contract_renewal_type integer, p_modifier integer);

drop sequence if exists seq_blog_post_category_id;

-- Adding access_page.module_id column
ALTER TABLE access_page ADD COLUMN module_id integer;

-- Populating module_id value
update access_page set module_id=10 where page_id in (select page_id from access_perm_page_map where perm_id in (3,4));
update access_page set module_id=6 where page_id in (select page_id from access_perm_page_map where perm_id in (19,24,21,16));
update access_page set module_id=5 where page_id in (select page_id from access_perm_page_map where perm_id in (10,11));
update access_page set module_id=3 where page_id in (select page_id from access_perm_page_map where perm_id in (12,9));
update access_page set module_id=1 where page_id in (select page_id from access_perm_page_map where perm_id in (6,22));
update access_page set module_id=15 where page_id in (select page_id from access_perm_page_map where perm_id in (13));
update access_page set module_id=4 where page_id in (select page_id from access_perm_page_map where perm_id in (1,2));
update access_page set module_id=14 where page_id in (select page_id from access_perm_page_map where perm_id in (26,27,28));
update access_page set module_id=7 where page_id in (select page_id from access_perm_page_map where perm_id in (15,25));
update access_page set module_id=8 where page_id in (select page_id from access_perm_page_map where perm_id in (18,20));
update access_page set module_id=2 where page_id in (select page_id from access_perm_page_map where perm_id in (8,23));
update access_page set module_id=11 where page_id in (select page_id from access_perm_page_map where perm_id in (14));
update access_page set module_id=16 where page_id in (select page_id from access_perm_page_map where perm_id in (17));
update access_page set module_id=9 where page_id in (12,13,14);

insert into access_page (page_id, page_name, page_description, module_id) values (257, '/home/index.dll', '', 13);

insert into access_page (page_id, page_name, page_description, module_id) values (258, '/issue-tracker/issue-list-export.dll', '', 4);
insert into access_perm_page_map(perm_id, page_id) values (1, 258);

-- Description columns has never been used in the past
alter table access_page drop column page_description;
alter table access_permission drop column perm_description;

-- Rename category.count_post column
alter table category rename column count_post to object_count;

-- Renaming count_ columns
alter table asset_hardware rename column count_software to software_count;
alter table asset_hardware rename column count_file to file_count;
alter table asset_hardware rename column count_component to component_count;
alter table asset_software rename column count_file to file_count;
alter table asset_software rename column count_license to license_count;
alter table asset_software rename column count_bookmark to bookmark_count;
alter table company rename column count_file to file_count;
alter table company rename column count_bookmark to bookmark_count;
alter table company rename column count_main_contact to main_contact_count;
alter table company rename column count_employee_contact to employee_contact_count;
alter table company rename column count_note to note_count;
alter table blog_post rename column count_comment to comment_count;

-- Need reset password pages
insert into access_page (page_id, page_name, module_id) values (259, '/admin/user-pw-reset.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 259);

insert into access_page (page_id, page_name, module_id) values (260, '/admin/user-pw-reset-2.dll', 10);
insert into access_perm_page_map(perm_id, page_id) values (4, 260);

insert into system_config (config_key, config_value) values ('admin.allowBlankUserPassword', 0);

-- Need KB article print view page
insert into access_page (page_id, page_name, module_id) values (261, '/kb/article-print.dll', 14);
insert into access_perm_page_map(perm_id, page_id) values (26, 261);

-- Contract index page
insert into access_page (page_id, page_name, module_id) values (262, '/IT/contract-index.dll', 3);
insert into access_perm_page_map(perm_id, page_id) values (12, 262);

CREATE SEQUENCE seq_category_id
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

select setval('seq_category_id', max(category_id)) from category;

update system_config set config_value='Etc/GMT+12,Etc/GMT+11,US/Hawaii,US/Alaska,PST,MST,US/Central,EST,Canada/Atlantic,America/Montevideo,Atlantic/South_Georgia,Atlantic/Cape_Verde,Etc/Greenwich,Europe/Amsterdam,Asia/Jerusalem,Europe/Moscow,Asia/Tehran,Asia/Baku,Asia/Kabul,Asia/Karachi,Asia/Calcutta,Asia/Dhaka,Asia/Bangkok,Asia/Hong_Kong,Asia/Seoul,Australia/Canberra,Asia/Magadan,Pacific/Auckland' where config_key='timezone.local.options';
